# 快速上手

## 最简单的用法

把 Word、Excel、PDF、PPT、Markdown、TXT、CSV 或图片资料放在当前目录：

```bash
python scripts/quick_start.py
```

也可以直接指定文件：

```bash
python scripts/quick_start.py 项目方案.docx 经营数据.xlsx --title "年度经营复盘"
```

## 选择视觉风格

默认 `--style auto` 会自动判断。也可以直接指定，例如：

```bash
python scripts/quick_start.py 项目方案.docx \
  --title "品牌年度提案" \
  --style editorial-magazine
```

常用值：`clean-professional`、`executive-consulting`、`editorial-magazine`、`data-dashboard`、`training-friendly`、`brand-pop`、`minimal-keynote`、`dark-tech`、`premium-luxury`。

## 完整流程

```bash
python scripts/run_pipeline.py \
  --inputs 项目方案.docx 经营数据.xlsx \
  --outdir output \
  --title "年度经营复盘" \
  --audience "管理层" \
  --purpose "汇报决策" \
  --style executive-consulting \
  --target-pages 12 \
  --presentation-minutes 15 \
  --filename "年度经营复盘.pptx"
```

输出目录同时包含可编辑 PPT、资料分析、内容审校、版式检查和运行摘要。正式使用前请核对数字、时间范围、来源与业务结论。

## 自动配图

先规划配图：

```bash
python scripts/run_pipeline.py \
  --inputs 资料.docx 数据.xlsx \
  --outdir output \
  --visual-mode plan \
  --max-visuals 4
```

读取 `output/image_plan.json`，使用宿主图片生成能力生成对应文件并保存到 `output/visual_assets/`，然后重新运行：

```bash
python scripts/run_pipeline.py \
  --inputs 资料.docx 数据.xlsx \
  --outdir output \
  --visual-mode assets \
  --visual-assets-dir output/visual_assets
```
