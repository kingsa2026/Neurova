# 嵌入式技能

本目录保存随 `adaptive-presentation-studio` 一起分发、可被主技能复用的辅助技能。

## presentations

`presentations/` 是完整的 `Presentations` 技能副本，包含：

- PowerPoint / Google Slides 工作流规则
- 参考 PPT 模板跟随规范
- 风格与版式指南
- Artifact Tool 文档与内置模板支持
- 模板检查、渲染、图片处理和溢出验证工具

主技能负责资料解析、业务图表、能源指标和 Dify 模板风格转译；需要更严格的 PPT 版式与视觉审校时，运行环境可读取：

```text
${CODEBUDDY_SKILL_DIR}/embedded_skills/presentations
```

该目录只携带技能资源，不携带 Node.js、Office、系统字体或其他宿主运行时依赖。
