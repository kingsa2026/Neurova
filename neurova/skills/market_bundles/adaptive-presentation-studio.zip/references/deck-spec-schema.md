# deck_spec.json 结构

`deck_spec.json` 是内容规划和 PPT 渲染之间的可编辑中间文件。

## 顶层结构

```json
{
  "title": "演示文稿标题",
  "subtitle": "副标题",
  "author": "部门或作者",
  "audience": "管理层",
  "purpose": "汇报决策",
  "date": "2026-08-03",
  "mode": "proposal",
  "planning": {
    "target_pages": 12,
    "actual_pages": 11,
    "presentation_minutes": 15,
    "content_complexity": "medium",
    "manual_review_required": false,
    "style_id": "executive-consulting",
    "style_name": "高管咨询风",
    "style_reason": "根据 proposal 内容、受众与演示目的自动匹配"
  },
  "provenance": {
    "analysis_status": "pass",
    "source_files": ["项目方案.docx", "经营数据.xlsx"],
    "source_coverage": {
      "source_file_count": 2,
      "represented_source_count": 2,
      "unrepresented_sources": [],
      "coverage_ratio": 1.0
    },
    "capability_boundaries": []
  },
  "theme": {
    "name": "consulting-light",
    "visual_style": "executive-consulting",
    "style_name": "高管咨询风",
    "density": "balanced",
    "header_variant": "consulting",
    "footer_mode": "source-page",
    "decorative_mode": "grid",
    "custom_colors": {
      "primary": "2457A6",
      "accent": "F2A900",
      "background": "F7F9FC",
      "text": "172033"
    },
    "font_cn": "Microsoft YaHei",
    "font_en": "Aptos",
    "template_style": {
      "source_pptx": "参考模板.pptx",
      "name": "Dify工作流入门培训课件",
      "reference_images": [],
      "notes": []
    }
  },
  "slides": []
}
```

## 规划字段

- `audience`：给谁看，影响措辞、信息密度和决策深度。
- `purpose`：希望演示达成什么，影响结尾页和行动请求。
- `target_pages`：建议或用户指定的页数。
- `actual_pages`：实际规划页数。
- `content_complexity`：`normal`、`medium` 或 `high`。
- `manual_review_required`：是否需要重点人工核对。
- `style_id`：本次使用的视觉系统 ID。
- `style_reason`：用户指定或自动匹配的简要原因。
- `source_coverage`：来源文件是否明确体现在页面中。

## 支持的页面类型

`cover`、`agenda`、`section`、`statement`、`content`、`cards`、`process`、`timeline`、`comparison`、`matrix`、`chart`、`table`、`image_feature`、`image_grid`、`quote`、`summary`、`closing`。

## 常用页面示例

### 观点页

```json
{
  "type": "statement",
  "layout": "auto",
  "title": "核心渠道贡献了主要增长",
  "key_message": "线上渠道是本期增量的主要来源",
  "body": "后续页面将展开趋势和结构证据。",
  "source": "经营数据.xlsx / 渠道Sheet"
}
```

### 卡片页

```json
{
  "type": "cards",
  "layout": "auto",
  "title": "三项关键策略共同支撑目标",
  "items": [
    {"title": "策略一", "body": "说明", "value": "01"},
    {"title": "策略二", "body": "说明", "value": "02"},
    {"title": "策略三", "body": "说明", "value": "03"}
  ],
  "source": "项目方案.docx"
}
```

### 图表页

```json
{
  "type": "chart",
  "layout": "auto",
  "title": "销售额连续四个月增长",
  "key_message": "末期较首期提升 75%",
  "image": "analysis/charts/sales_trend.png",
  "chart_data": {
    "kind": "line",
    "categories": ["2026-01", "2026-02", "2026-03"],
    "series": [{"name": "销售额", "values": [120, 150, 210]}],
    "x_axis": "月份",
    "y_axis": "销售额"
  },
  "insights": ["增长持续", "需核对渠道驱动"],
  "source": "经营数据.xlsx / 销售Sheet / 2026年1-4月 / 单位：万元"
}
```

### 行动页

```json
{
  "type": "closing",
  "layout": "auto",
  "title": "下一步需要完成三项动作",
  "items": [
    {"title": "确认范围", "body": "锁定首批渠道", "owner": "渠道组", "timing": "本周"},
    {"title": "完成资产", "body": "交付主视觉", "owner": "品牌组", "timing": "下周"}
  ]
}
```

## theme / visual_style

`theme.visual_style` 推荐使用以下值之一：`dify-workflow-template`、`clean-professional`、`executive-consulting`、`editorial-magazine`、`data-dashboard`、`academic-research`、`training-friendly`、`brand-pop`、`minimal-keynote`、`dark-tech`、`warm-storytelling`、`premium-luxury`、`china-red`。

视觉风格控制统一识别系统，但不固定每页结构。用户提供品牌规范或参考 PPT 时，可用 `custom_colors`、字体字段、`template_style` 和页面级 `layout` 进一步覆盖。参考模板提取结果可包含 `palette`、`font_colors`、`background_colors`、`fill_colors`、`layout_signals` 和 `reference_images`。

## chart_data

图表页可同时提供 `image` 和 `chart_data`：

- `chart_data` 存在时，渲染器优先创建 PowerPoint 原生可编辑图表。
- `image` 是兼容兜底，也可作为审校参考。
- 支持 `kind=line`、`bar`、`column`、`pie`、`donut`、`scatter`；直方图可转换为 `bar`。
- 不得为了生成图表编造 `categories` 或 `values`；必须来自用户资料或明确计算结果。

## layout

- 使用 `auto` 时由渲染器根据视觉风格、内容数量、文字长度、图片比例和最近页面历史选择。
- 不建议在所有页面显式指定同一个布局。
- 渲染失败时 `repair_spec.py` 会将异常页面切换为 `auto` 和兼容结构。

## 来源要求

- 含数字、表格、图表或精确结论的页面必须填写 `source`。
- `source` 至少包含文件名。
- 数据页尽量包含 Sheet、时间范围、单位和统计口径。
- `analysis_status=partial` 时，文稿必须包含资料限制说明或在运行摘要中明确提示。

## 内容长度建议

- 标题不超过 36 个中文字符。
- `key_message` 不超过 70 个字符。
- 正文建议不超过 180 个字符。
- 单页要点建议 3–6 条。
- 表格建议不超过 8 行 × 6 列。
- 内容过多时拆页，不继续缩小字号。
