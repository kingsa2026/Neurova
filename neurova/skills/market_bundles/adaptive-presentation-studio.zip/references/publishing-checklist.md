# SkillHub / WorkBuddy 发布检查清单

## 包结构

- [ ] ZIP 根目录直接包含 `SKILL.md`、`manifest.yaml`
- [ ] 包含 `README.md`、`QUICKSTART.md`、`PUBLISHING.md`、`CHANGELOG.md`
- [ ] 包含 `scripts/`、`references/`、`assets/`、`examples/`
- [ ] 不包含 `.env`、密钥、账号、缓存、用户资料、测试输出或字体文件

## 元数据

- [ ] Skill 标识：`adaptive-presentation-studio`
- [ ] 显示名称：`智能演示文稿生成器`
- [ ] 版本：`3.0.0`
- [ ] 分类：`办公效率`
- [ ] 描述不局限于数据分析
- [ ] 触发描述覆盖明确和模糊表达

## 能力边界

- [ ] README 和 SKILL.md 前置说明扫描 PDF 不执行 OCR
- [ ] 明确旧版 `.xls` 限制
- [ ] 明确超长/超大资料可能截断
- [ ] 明确输出为专业初稿，需要人工核对
- [ ] 明确损坏和加密文件不能保证恢复

## 自动测试

```bash
python scripts/preflight.py
python scripts/self_test.py --outdir self-test-output
python scripts/package_check.py --root . --report package-check.json
```

- [ ] 综合回归测试通过率 100%
- [ ] UTF-8 BOM、GB18030 和异常 CSV 测试通过
- [ ] 扫描 PDF 边界提示通过
- [ ] 损坏 Office 文件诊断通过
- [ ] 完整 PPT 生成与验证通过
- [ ] 第二次运行断点续跑通过
- [ ] 零参数快速启动通过
- [ ] 自动修复脚本通过
- [ ] 发布包检查无错误

## 用户体验

- [ ] 终端显示中文阶段进度
- [ ] 错误提示包含问题、原因和可执行步骤
- [ ] 用户不查看技术日志也能处理常见异常
- [ ] 输出 `运行摘要.md`
- [ ] 输出 `资料读取说明.md`
- [ ] 输出 `内容审校说明.md`
- [ ] 输出 `版式检查说明.md`

## 功能验收

- [ ] 纯文字资料不会强行生成数据看板
- [ ] 数值资料生成合适图表并标注来源
- [ ] 8 页以上至少 5 种页面类型和 5 种布局
- [ ] 不连续 3 页重复同一结构
- [ ] 单页失败不会拖垮整份 PPT
- [ ] 复杂资料报告来源覆盖率和人工复核要求
- [ ] 扫描、旧版和截断资料在结果中明确提示


## 配套本地服务（仅适用时）

- [ ] 若交付包含需要持续运行的本地预览/Web 服务，一键启动/停止脚本成对交付。
- [ ] Windows 至少同时存在 `start_windows.bat` 与 `stop_windows.bat`；macOS 如支持则同时存在启动/停止 `.command`。
- [ ] 停止脚本仅停止当前项目服务，不全局结束 Python 进程。
- [ ] 纯 PPT 文件或一次性生成流程不强制生成无意义的启停脚本。
