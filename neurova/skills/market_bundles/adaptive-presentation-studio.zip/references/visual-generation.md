# 自动配图工作流

## 目标

把资料中的观点转换成适合 PPT 的主视觉，同时保持参考模板的背景、配色、留白、图片比例和版式节奏。位图只负责照片、场景、关系和空间感；标题、标签、箭头和来源使用 PowerPoint 原生元素，避免中文错字并保持可编辑。

## 标准流程

1. 运行 `visual_planner.py` 生成 `image_plan.json`。
2. 读取每个 `items[].prompt`、`aspect_ratio` 和 `expected_filename`。
3. 使用宿主 `imagegen`、GPT-Image 或兼容图片生成能力逐项生成。
4. 将文件保存到 `visual_assets/`，文件名必须与 `expected_filename` 一致。
5. 重新运行流水线并传入 `--visual-assets-dir visual_assets`。
6. 检查最终 PPT 的裁切、清晰度、重复图片、中文标签和模板一致性。

## 命令

仅规划：

```bash
python scripts/visual_planner.py \
  --spec output/deck_spec.json \
  --analysis output/analysis/analysis.json \
  --output output/image_plan.json \
  --output-spec output/deck_spec.json \
  --assets-dir output/visual_assets \
  --mode plan \
  --max-images 4
```

绑定已生成图片：

```bash
python scripts/run_pipeline.py \
  --inputs 资料.docx 数据.xlsx \
  --outdir output \
  --visual-mode assets \
  --visual-assets-dir output/visual_assets
```

## 配图类型

- `conceptual_illustration`：观点、总结和抽象概念。
- `editorial_explainer`：文章内容、培训知识和方案说明。
- `process_diagram`：流程、阶段和工作路径。
- `timeline_illustration`：里程碑和实施节奏。
- `comparison_explainer`：方案对比、前后变化和差异说明。
- `system_relationship`：系统、角色、模块和上下游关系。
- `industrial_operations_scene`：能源、制造和运营现场。
- `product_scenario`：产品、用户和使用场景。
- `teaching_explainer`：培训课件中的知识解释。

## 中文标签

- 默认禁止图片模型在位图中生成中文或英文标签。
- `image_plan.json` 的 `editable_labels` 由渲染器叠加为原生 PowerPoint 文本框。
- 标签继承参考模板字体、主色和强调色。
- 单页最多 4 个标签，每个标签控制在 14 个中文字符以内。

## 质量要求

- 主体完整，四周保留裁切安全区。
- 同一张图片默认只使用一次。
- 16:9 页面优先使用 16:9 或 16:10 图片；封面横幅可使用 21:9。
- 禁止在图片中画入 PPT 标题、页眉、页脚、页码、水印和装饰边框。
- 参考模板存在时，提示词必须包含模板配色、背景和视觉区域。
- 图片不足、模型不可用或生成失败时，渲染器用蓝调场景填充器填满视觉区（保证不留白），并可使用原生图表、用户图片或兼容文字页，不得阻断整份 PPT。
