# 自适应视觉设计系统

## 一致性与变化

- 一致性来自字体、色板、线宽、圆角、页脚和对齐规则。
- 变化来自页面结构、留白比例、图文关系、视觉焦点和内容密度。
- 8 页以上至少使用 5 种布局；不得连续 3 页同布局。

## 页面层级

- 封面标题：30–44pt
- 章节标题：32–42pt
- 页标题：26–32pt
- 核心数字/观点：28–52pt
- 正文：16–20pt
- 图表标签：11–14pt
- 来源/注释：9.5–11pt

## 内容密度

- 稀疏：1 个观点或 1 张主图，使用大留白和大字号。
- 中等：2–4 个要点、卡片或图文组合。
- 密集：表格、图表、矩阵；需增加结构线和分组，不缩小正文。

## 视觉焦点

每页只选择一个主焦点：

- 核心句
- 关键数字
- 主图
- 主图表
- 流程/时间线

其余内容均作为解释层，不与主焦点竞争。


## Style is a system, not a repeated layout

A consistent deck repeats visual rules, not page geometry. Keep palette, typography hierarchy, spacing logic, decorative language and source treatment stable; vary the composition according to the slide role.

Recommended rhythm checks:

- 8+ slides: >=5 effective layouts.
- Never repeat one layout three times consecutively.
- Avoid using the same card grid for narrative, evidence and action pages.
- Let whitespace, scale, image proportion and alignment create variation before adding decoration.
- When a user supplies a reference deck, imitate its visible design grammar rather than only copying its color palette.
