# 智能演示文稿生成器

面向 WorkBuddy / CodeBuddy 的通用 PPT 制作技能。用户可以导入文字、表格、PDF、现有 PPT 和图片资料，技能会根据受众与目的动态规划内容、视觉风格与版式，而不是套用固定模板；同一套视觉识别下，页面结构会随内容角色变化。

## 30 秒开始

把资料放在当前目录，运行：

```bash
python scripts/quick_start.py
```

完成后优先打开：

1. `演示文稿.pptx`
2. `运行摘要.md`
3. `内容审校说明.md`

更多例子见 [QUICKSTART.md](QUICKSTART.md)。

## 能做什么

- 工作汇报、项目进展、年度总结、经营复盘
- 策略方案、品牌提案、活动策划、产品介绍
- 培训课件、制度宣导、研究报告、答辩材料
- 多份 Word、Excel、PDF、图片合成一份演示文稿
- 数据统计、趋势分析、结构对比和可视化图表
- 内置 13 套视觉系统，并根据受众、内容和用途自动匹配或按用户指定执行
- 可用参考 PPT 自动提取背景、字体颜色、配色、图片比例、版式节奏和页面气质
- 参考 PPT 模板会进入渲染器：封面、章节页、观点页、图表页、图片页都会使用模板式背景、容器和装饰语言
- 使用参考 PPT 时自动生成模板还原度评分，指出配色、背景、字体、版式和图表的贴合程度
- Excel/CSV 数据页优先生成可编辑 PowerPoint 原生图表，PNG 图表作为兼容兜底
- 数据型汇报自动预留图表页：8 页以上至少 3 个趋势/对比/效率图表，不能被文字页挤掉
- 自动识别能源运营数据中的产量、用水、用电、单位能耗、产线趋势和异常高耗日
- 重复类别长表可还原为多系列周期趋势图，适用于产线、门店、渠道和区域数据
- 根据内容自动选择观点、卡片、流程、时间线、对比、矩阵、图表和图文页面
- 同一套 PPT 保持风格统一，同时自动轮换多种布局，避免“每页长得一样”
- 生成后检查标题、来源、重复内容、越界、字号和布局重复
- 异常时自动重试、兼容恢复和断点续跑
- 完整内置 `Presentations` 演示文稿技能，包含模板跟随、版式规范、渲染与溢出检查资源
- 自动规划 PPT 配图：按页面内容生成提示词、比例、推荐分辨率和素材文件名
- 支持宿主 imagegen 生成后自动绑定图片，并叠加可编辑中文标签

## 模糊说法也可以触发

用户不需要使用专业术语。以下表达都属于本技能：

- 帮我整理一下这些附件
- 做个开会用的版本
- 把这些内容讲清楚
- 给领导做个简报
- 帮我排成好看的页
- 把 Word、表格和图片合成一份材料
- 把现有 PPT 改得更专业

## 必须知道的限制

| 情况 | 当前处理方式 |
|---|---|
| 扫描版 PDF | 不执行 OCR；需先转成可搜索 PDF |
| 旧版 `.xls` | 读取主要表格值；公式、图表和格式需核对 |
| 超长/超大资料 | 安全截断或分段取样，并提示覆盖风险 |
| 损坏 Office 文件 | 给出中文修复步骤，建议另存为新文件 |
| 图片中的业务文字 | 不凭空推断；需补充文字稿或人工确认 |
| 最终 PPT | 定位为专业初稿，正式发布前仍需核对 |

详细说明见 `references/capability-boundaries.md`。

## 支持格式

- 表格：`.xlsx`、`.xls`、`.csv`、`.tsv`
- 文档：`.docx`、`.pdf`、`.txt`、`.md`、`.json`
- 演示：`.pptx`
- 图片：`.png`、`.jpg`、`.jpeg`、`.webp`、`.gif`

## 完整命令

```bash
python scripts/run_pipeline.py \
  --inputs 项目方案.docx 经营数据.xlsx \
  --outdir output \
  --title "年度经营复盘" \
  --audience "管理层" \
  --purpose "汇报决策" \
  --target-pages 12 \
  --presentation-minutes 15 \
  --style executive-consulting \
  --template-pptx "参考模板.pptx" \
  --filename "年度经营复盘.pptx"
```

### 稳定性参数

- `--retries 2`：每阶段自动重试次数，默认 2。
- 默认开启断点续跑；使用 `--no-resume` 可强制重跑。
- 默认开启兼容布局自动修复；使用 `--no-auto-repair` 可关闭。
- `--max-file-mb` 与 `--max-rows` 可调整安全限制。
- `--visual-mode plan` 只输出配图规划，不调用外部图片生成服务。
- `--visual-mode assets --visual-assets-dir output/visual_assets` 使用已生成图片自动绑定页面。
- `--max-visuals 4` 控制单份 PPT 的配图数量上限。


## 参考 PPT 模板

当用户提供参考 PPT 时，优先使用：

```bash
python scripts/run_pipeline.py \
  --inputs 资料.docx 数据.xlsx \
  --outdir output \
  --title "培训课件" \
  --template-pptx "Dify工作流入门培训课件.pptx"
```

流水线会先生成 `output/template_style/template_style.json`，其中包含 `palette`、`font_colors`、`background_colors`、`fill_colors`、`layout_signals` 和压缩参考图。若已经提取过，也可以直接传入 `--template-style output/template_style/template_style.json`。

本包内置 `assets/reference_templates/dify_workflow/template_style.json`，来自 Dify 工作流入门培训课件，用于 AI 工作流、Dify、自动化培训等场景的蓝白教学风。

从 1.5.0 起，Dify 模板不只是配色参考。渲染器会生成工作流式封面、强蓝侧栏观点页、圆角图表容器、右侧关键解读栏、顶部进度胶囊和统一浅灰画布。图表和图片仍保持可编辑/可替换，不复制参考 PPT 的业务内容。

生成完成后还会输出：

- `template_match_report.json`：模板还原度结构化评分。
- `模板还原度报告.md`：普通用户可读的评分与优化建议。
- `image_plan.json`：逐页配图提示词、比例、预期文件名和素材状态。

评分维度包括配色匹配、背景匹配、字体匹配、版式节奏和可编辑图表。该报告不会阻断生成，但会提示后续应优先微调的方向。

## 自动配图

1. 先运行 `--visual-mode plan`，读取 `image_plan.json`。
2. 使用宿主 imagegen/GPT-Image 生成图片，按 `expected_filename` 保存到 `visual_assets`。
3. 再运行 `--visual-mode assets --visual-assets-dir visual_assets`。

默认生成无文字主视觉，中文标签由 PPT 原生文本框叠加，避免图片中文字错误。图片生成不可用时，仍使用用户图片、原生图表或兼容文字页完成交付。

## 内置 Presentations 技能

`embedded_skills/presentations/` 是随包分发的完整演示文稿能力目录，包含 `SKILL.md`、风格规范、模板跟随参考、Artifact Tool 文档、模板资产和渲染检查工具。主技能会继续负责资料理解、业务图表和参考 PPT 风格提取；在宿主具备对应运行时的情况下，可直接复用该目录完成更严格的 PPT 版式与视觉审校。

该目录不包含 Node.js、`@oai/artifact-tool`、Office 或系统字体等宿主运行时依赖；这些依赖应由运行环境提供。若运行环境不具备这些依赖，主技能会回退到包内现有 Python 渲染器。

## 视觉风格系统

`--style auto` 会综合内容模式、标题、受众、演示目的和参考模板自动判断，也可以直接指定：

| 参数 | 中文风格 | 更适合 |
|---|---|---|
| `clean-professional` | 清爽专业风 | 日常工作汇报、项目复盘 |
| `executive-consulting` | 高管咨询风 | 战略、经营、董事会、咨询分析 |
| `editorial-magazine` | 创意杂志风 | 品牌方案、传播提案、作品展示 |
| `data-dashboard` | 数据仪表盘风 | KPI、经营分析、BI 汇报 |
| `academic-research` | 科研答辩风 | 论文、研究、实验、课题评审 |
| `training-friendly` | 教学课件风 | 培训、制度宣导、课程 |
| `brand-pop` | 品牌活力风 | 营销、新品、活动、年轻化品牌 |
| `minimal-keynote` | 极简发布会风 | 演讲、产品发布、一页一观点 |
| `dark-tech` | 深色科技风 | AI、数字化、技术方案 |
| `warm-storytelling` | 温暖叙事风 | 文化、公益、酒店、生活方式 |
| `premium-luxury` | 高级质感风 | 高端品牌、酒店、地产、精品发布 |
| `china-red` | 庄重红色风 | 正式宣导、庆典、红色主题 |
| `dify-workflow-template` | Dify工作流课件风 | AI 工作流、Dify 培训、自动化课程 |

用户提供参考 PPT、品牌色、字体、比例或明确风格时，这些要求优先于内置预设。内置风格是“视觉系统”，不是固定母版：封面、章节页、观点页、数据页、图文页、流程页和结尾页会根据内容角色采用不同构图。

## 输出文件

```text
output/
├── analysis/
│   ├── analysis.json
│   ├── 资料读取说明.md
│   └── charts/
├── template_style/
│   ├── template_style.json
│   └── reference_images/
├── template_match_report.json
├── 模板还原度报告.md
├── deck_spec.json
├── content_review.json
├── 内容审校说明.md
├── 演示文稿.pptx
├── 演示文稿.render_report.json
├── validation.json
├── 版式检查说明.md
├── pipeline_report.json
└── 运行摘要.md
```

普通用户通常只需要看 PPT、运行摘要和内容审校说明。

## 自动恢复机制

1. 每个阶段失败后自动重试。
2. 已完成阶段写入 `.pipeline_state.json`。
3. 相同资料再次运行时自动复用已完成结果。
4. 单页渲染失败时改用兼容文字页，不让整份 PPT 崩溃。
5. 整体渲染失败时自动修复页面配置后重试。
6. 版式验证失败时按问题页码精简并重新生成一次。

## 数据型汇报质量门槛

- 5–7 页的数据型汇报至少 2 个图表页；8 页以上至少 3 个图表页。
- 趋势图、单位强度/效率图、分类对比图优先；相关散点和直方图作为补充。
- 类别记录数完全相同的饼图通常没有业务意义，默认不生成。
- 30 天/月度趋势保留完整周期，折线图最多支持 36 个类别。
- KPI 必须使用业务名称和单位，不直接展示 `elec_kwh`、`production_kg` 等技术列名。
- 数据页很多但无图表时，内容审校直接判定失败。

## 文档入口

- 快速上手：`QUICKSTART.md`
- 能力边界：`references/capability-boundaries.md`
- 完整案例：`references/case-library.md`
- 使用技巧：`references/best-practices.md`
- 故障排查：`references/troubleshooting.md`
- 页面结构：`references/content-planning.md`
- 视觉风格：`references/style-system.md`
- 数据规则：`references/analysis-rules.md`
- 能源运营规则：`references/domain-profile-energy.md`
- 发布检查：`references/publishing-checklist.md`

## 发布包结构

ZIP 第一层直接包含：

```text
SKILL.md
manifest.yaml
README.md
QUICKSTART.md
PUBLISHING.md
CHANGELOG.md
requirements.txt
scripts/
references/
assets/
examples/
```

发布前运行：

```bash
python scripts/preflight.py
python scripts/self_test.py --outdir self-test-output
python scripts/package_check.py --root . --report package-check.json
```
