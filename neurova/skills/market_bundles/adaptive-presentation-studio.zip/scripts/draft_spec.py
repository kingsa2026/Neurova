#!/usr/bin/env python3
"""Create a content-adaptive first-pass deck_spec.json from analysis.json.

This planner is intentionally general: text-heavy inputs produce narrative,
process, timeline, comparison and card slides; numeric datasets add charts only
when available. The WorkBuddy agent should still refine wording and storyline.
"""
from __future__ import annotations

import argparse
import json
import re
from datetime import date
from pathlib import Path
from typing import Any

from style_engine import choose_style, style_profile

MODE_HINTS = {
    "proposal": re.compile(r"方案|提案|策略|营销|活动|推广|规划|建议|proposal|strategy|campaign", re.I),
    "project": re.compile(r"项目|进度|里程碑|计划|交付|风险|任务|project|milestone|roadmap", re.I),
    "training": re.compile(r"培训|课程|学习|知识|方法|教程|操作|规范|training|lesson|guide", re.I),
    "product": re.compile(r"产品|品牌|卖点|用户|场景|功能|价值|product|brand|feature|customer", re.I),
    "research": re.compile(r"研究|调研|洞察|方法|样本|结论|发现|research|survey|insight", re.I),
    "report": re.compile(r"汇报|总结|复盘|年度|月度|工作|成果|问题|report|review|summary", re.I),
}
PROCESS_HINT = re.compile(r"流程|步骤|阶段|路径|方法|实施|执行|step|process|phase", re.I)
TIMELINE_HINT = re.compile(r"时间|里程碑|季度|月份|年度|计划|Q[1-4]|20\d{2}|timeline|milestone", re.I)
COMPARE_HINT = re.compile(r"对比|比较|现状|目标|之前|之后|优势|劣势|A/B|compare|versus", re.I)
MATRIX_HINT = re.compile(r"矩阵|象限|分类|优先级|风险.*机会|matrix|quadrant", re.I)
ACTION_HINT = re.compile(r"下一步|行动|建议|计划|责任|完成|复核|优化|降低|建立|跟踪|改善|确认|next|action|owner|optimi[sz]e|review|reduce|track", re.I)
SUM_HINT = re.compile(r"销售|销量|金额|收入|营收|订单|数量|产量|用电|电量|用水|水量|成本|费用|利润|revenue|sales|amount|count|qty|production|electricity|electric|water|kwh|cost|profit", re.I)
PERCENT_HINT = re.compile(r"率|占比|比例|百分比|强度|单耗|rate|ratio|percent|intensity|per[_ -]?unit|%", re.I)
GENERIC_SECTION_TITLES = {"资料要点", "背景", "现状", "问题", "核心内容", "主要内容", "总结", "结论", "分析"}
ENERGY_HINT = re.compile(r"能源|能耗|用电|耗电|电量|用水|耗水|产量|产线|单位.*(?:电|水)|kwh|kg|energy|electric|water|intensity", re.I)


def stronger_title(title: str, points: list[str]) -> str:
    cleaned = clean(title)
    if cleaned in GENERIC_SECTION_TITLES and points:
        return shorten(points[0], 34)
    return shorten(cleaned or (points[0] if points else "内容要点"), 34)


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def shorten(text: str, max_len: int = 44) -> str:
    text = clean(text).rstrip("。；; ")
    return text if len(text) <= max_len else text[: max_len - 1] + "…"


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[。！？!?；;])\s*|\n+", text)
    return [clean(x).lstrip("-•*0123456789.、 ") for x in parts if 8 <= len(clean(x)) <= 180]


def extract_sections(text: str) -> list[dict[str, Any]]:
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    sections: list[dict[str, Any]] = []
    current = {"title": "资料要点", "lines": []}
    heading_re = re.compile(r"^(?:#{1,4}\s+|第[一二三四五六七八九十0-9]+[章节部分]\s*|[一二三四五六七八九十0-9]+[、.．]\s*)?(.{2,32})$")
    for line in lines:
        stripped = re.sub(r"^#{1,4}\s+", "", line).strip()
        is_heading = bool(heading_re.match(line)) and len(stripped) <= 28 and not re.search(r"[。；;，,]", stripped)
        if is_heading and current["lines"]:
            sections.append(current)
            current = {"title": stripped, "lines": []}
        elif is_heading and not current["lines"] and current["title"] == "资料要点":
            current["title"] = stripped
        else:
            current["lines"].append(line)
    if current["lines"] or current["title"] != "资料要点":
        sections.append(current)
    result = []
    for section in sections:
        body = "\n".join(section["lines"])
        points = split_sentences(body)
        if not points and body:
            points = [shorten(body, 100)]
        result.append({"title": section["title"], "points": points[:8], "body": clean(body)})
    return result[:12]


def infer_mode(text: str, has_data: bool) -> str:
    scores = {mode: len(regex.findall(text)) for mode, regex in MODE_HINTS.items()}
    if has_data:
        scores["data"] = 2 + len(re.findall(r"数据|指标|趋势|同比|环比|统计|分析|data|metric|trend", text, re.I))
    else:
        scores["data"] = 0
    mode, score = max(scores.items(), key=lambda x: x[1])
    return mode if score > 0 else ("data" if has_data else "report")


def theme_for_mode(mode: str) -> str:
    return {
        "proposal": "editorial-red",
        "project": "modern-blue",
        "training": "warm-neutral",
        "product": "creative-purple",
        "research": "fresh-green",
        "data": "modern-blue",
        "report": "modern-blue",
    }.get(mode, "modern-blue")


def fmt(v: float, percent: bool = False) -> str:
    if percent:
        return f"{v:.1f}%"
    av = abs(v)
    if av >= 100_000_000: return f"{v/100_000_000:.2f}亿"
    if av >= 10_000: return f"{v/10_000:.1f}万"
    if av >= 1000: return f"{v:,.0f}"
    if av >= 10: return f"{v:.1f}"
    return f"{v:.2f}"


def build_kpis(dataset: dict[str, Any]) -> list[dict[str, str]]:
    candidates = []
    for name, info in (dataset.get("numeric_summary") or {}).items():
        if PERCENT_HINT.search(name):
            candidates.append((4, name, fmt(float(info.get("mean", 0)), True), "均值"))
        elif SUM_HINT.search(name):
            candidates.append((5, name, fmt(float(info.get("sum", 0))), "合计"))
        else:
            candidates.append((2, name, fmt(float(info.get("mean", 0))), "均值"))
    candidates.sort(key=lambda x: (-x[0], x[1]))
    return [{"title": name, "value": value, "body": note} for _, name, value, note in candidates[:4]]


def build_energy_kpis(dataset: dict[str, Any]) -> list[dict[str, str]]:
    columns = [str(c) for c in dataset.get("columns") or []]
    rows = dataset.get("preview") or []
    if not columns or not rows:
        return build_kpis(dataset)

    def find_col(pattern: str) -> str | None:
        regex = re.compile(pattern, re.I)
        return next((c for c in columns if regex.search(c)), None)

    production_col = find_col(r"产量|production")
    water_col = find_col(r"用水|水量|water_(?:ton|qty)|water$")
    electricity_col = find_col(r"用电|电量|elec_(?:kwh|qty)|electric")
    if not (production_col and water_col and electricity_col):
        return build_kpis(dataset)

    def total(col: str) -> float:
        values = []
        for row in rows:
            try:
                values.append(float(row.get(col) or 0))
            except Exception:
                pass
        return sum(values)

    production = total(production_col)
    water = total(water_col)
    electricity = total(electricity_col)
    water_intensity = water / production if production else 0.0
    electricity_intensity = electricity / production if production else 0.0
    return [
        {"title": "总产量", "value": fmt(production), "body": "KG"},
        {"title": "总用水", "value": fmt(water), "body": "吨"},
        {"title": "总用电", "value": fmt(electricity), "body": "kWh / 度"},
        {"title": "单位耗水", "value": f"{water_intensity:.4f}", "body": "吨 / KG"},
        {"title": "单位耗电", "value": f"{electricity_intensity:.4f}", "body": "kWh / KG"},
    ]


def infer_domain(text: str, datasets: list[dict[str, Any]]) -> str:
    dataset_text = " ".join(
        " ".join([str(d.get("name", "")), *[str(c) for c in d.get("columns") or []]])
        for d in datasets
    )
    return "energy-operations" if ENERGY_HINT.search(text + " " + dataset_text) else "general"


def dataset_score(dataset: dict[str, Any]) -> float:
    name = str(dataset.get("name", "")).lower()
    numeric = dataset.get("numeric_summary") or {}
    shape = dataset.get("shape") or {}
    rows = int(shape.get("rows") or 0)
    score = len(numeric) * 5 + min(rows, 50) / 10
    if re.search(r"summary|汇总|trend|趋势|daily|月度", name, re.I):
        score += 10
    score += sum(3 for col in numeric if SUM_HINT.search(str(col)))
    return score


def chart_priority(chart: dict[str, Any]) -> tuple[int, str]:
    kind = str(chart.get("type") or (chart.get("chart_data") or {}).get("kind") or "").lower()
    text = " ".join(str(chart.get(k, "")) for k in ("title", "description", "x", "y")).lower()
    score = {"line": 100, "bar": 82, "column": 82, "scatter": 48, "histogram": 28, "pie": 12}.get(kind, 35)
    if re.search(r"强度|单耗|单位|效率|intensity|rate", text):
        score += 16
    if re.search(r"趋势|日期|周期|日|月|trend", text):
        score += 12
    if re.search(r"产量|用电|用水|营收|成本|利润|production|electric|water|revenue", text):
        score += 8
    if re.search(r"用电|耗电|电量|electric|kwh", text):
        score += 7
    elif re.search(r"用水|耗水|水量|water", text):
        score += 3
    if kind == "pie" and not re.search(r"占比|构成|份额|share|mix", text):
        score -= 15
    return score, text


def select_charts(charts: list[dict[str, Any]], budget: int) -> list[dict[str, Any]]:
    ranked = sorted(charts, key=lambda c: (-chart_priority(c)[0], chart_priority(c)[1]))
    selected: list[dict[str, Any]] = []
    signatures: set[tuple[str, str, str]] = set()
    kind_counts: dict[str, int] = {}

    def add(chart: dict[str, Any]) -> bool:
        kind = str(chart.get("type") or (chart.get("chart_data") or {}).get("kind") or "")
        signature = (kind, str(chart.get("x") or ""), str(chart.get("y") or chart.get("title") or ""))
        if signature in signatures or kind_counts.get(kind, 0) >= (3 if kind == "line" else 2):
            return False
        signatures.add(signature)
        kind_counts[kind] = kind_counts.get(kind, 0) + 1
        selected.append(chart)
        return True

    if budget >= 3:
        intensity = next((c for c in ranked if re.search(r"强度|单耗|单位|intensity|per[_ -]?unit", chart_priority(c)[1], re.I)), None)
        if intensity:
            add(intensity)
    for chart in ranked:
        add(chart)
        if len(selected) >= budget:
            break
    return selected


def anomaly_slide_from_sections(sections: list[dict[str, Any]], source: str) -> dict[str, Any] | None:
    anomaly_hint = re.compile(r"异常|偏离|超过|高耗|低效|无产量|停产|未排产|数据未填|需确认|需复核", re.I)
    points: list[str] = []
    for section in sections:
        for point in section.get("points") or []:
            if anomaly_hint.search(point):
                points.append(point)
    if not points:
        return None
    unique = list(dict.fromkeys(points))
    unique.sort(key=lambda p: (
        0 if re.search(r"\d{1,2}月\d{1,2}日", p) else
        1 if re.search(r"(?:泡芙线|黑白配线|饼干线).*(?:无产量|停产|未排产)", p) else 2
    ))
    unique = unique[:4]

    def anomaly_title(point: str) -> str:
        date_match = re.search(r"\d{1,2}月\d{1,2}日", point)
        line_match = re.search(r"(泡芙线|黑白配线|饼干线)", point)
        metric = "电耗" if re.search(r"电耗|耗电|用电", point) else "水耗" if re.search(r"水耗|耗水|用水", point) else "数据"
        if date_match and line_match:
            return f"{date_match.group(0)} {line_match.group(1)}{metric}异常"
        if line_match and re.search(r"无产量|停产|未排产", point):
            return f"{line_match.group(1)}整月无产量"
        return shorten(re.split(r"[，,；;：:]", point)[0], 22)
    return {
        "type": "cards", "layout": "stripe", "title": "异常与重点关注项",
        "key_message": "优先复核高耗、停产和数据缺口，再判断设备或排产原因。",
        "items": [{"value": f"{i+1:02d}", "title": anomaly_title(p), "body": shorten(p, 76)} for i, p in enumerate(unique)],
        "source": source,
    }


def action_title(point: str) -> str:
    rules = [
        (r"泡芙线.*(?:用电|能效|单位耗电)", "优化泡芙线用电效率"),
        (r"饼干线.*(?:无产量|停产|未排产|状态)", "复核饼干线生产状态"),
        (r"(?:建立|跟踪).*(?:KPI|指标|单位.*(?:水|电))", "建立能耗强度KPI"),
        (r"(?:异常|偏离).*(?:复核|排产|设备)", "复核异常高耗日"),
    ]
    for pattern, title in rules:
        if re.search(pattern, point, re.I):
            return title
    return shorten(re.split(r"[，,；;：:]", point)[0], 20)


def finding_title(point: str) -> str:
    if re.search(r"单位耗电.*最高|耗电强度最高", point):
        return "单位耗电最高"
    if re.search(r"总用电.*最高", point):
        return "用电贡献最高"
    if re.search(r"产量.*最高", point):
        return "产量贡献最高"
    if re.search(r"低负荷", point):
        return "月底低负荷"
    if re.search(r"非零周期|峰值", point):
        return "生产节奏波动"
    if re.search(r"相关", point):
        return "产量与用电联动"
    return shorten(re.split(r"[，,；;：:]", point)[0], 18)


def table_slide_from_dataset(datasets: list[dict[str, Any]], source: str) -> dict[str, Any] | None:
    candidates = []
    for dataset in datasets:
        shape = dataset.get("shape") or {}
        rows, cols = int(shape.get("rows") or 0), int(shape.get("columns") or 0)
        preview = dataset.get("preview") or []
        columns = dataset.get("columns") or []
        if 1 <= rows <= 8 and 3 <= cols <= 7 and preview and columns:
            candidates.append((cols + len(dataset.get("numeric_summary") or {}), dataset))
    if not candidates:
        return None
    dataset = max(candidates, key=lambda x: x[0])[1]
    source_columns = [str(c) for c in dataset.get("columns") or []][:7]
    label_map = {
        "line": "产线", "active_days": "生产天数", "production_kg": "产量(KG)",
        "water_ton": "用水(吨)", "elec_kwh": "用电(kWh)",
        "water_intensity": "单位耗水", "elec_intensity": "单位耗电",
    }
    columns = [label_map.get(c.lower(), c) for c in source_columns]
    def display(value: Any) -> Any:
        if isinstance(value, float):
            if abs(value) >= 1000:
                return f"{value:,.0f}"
            if abs(value) >= 1:
                return f"{value:,.1f}"
            return f"{value:.4f}"
        return value
    rows = [[display(row.get(c, "")) for c in source_columns] for row in (dataset.get("preview") or [])[:8]]
    return {
        "type": "table", "layout": "table-notes", "title": "核心明细与分组对比",
        "columns": columns, "rows": rows,
        "insights": (dataset.get("findings") or [])[:3],
        "source": Path(str(dataset.get("source_file") or source)).name,
    }


def section_to_slide(section: dict[str, Any], index: int) -> dict[str, Any]:
    points = section.get("points") or []
    title = stronger_title(section.get("title") or f"重点 {index}", points)
    body = section.get("body", "")
    joined = title + " " + body
    clauses = [clean(x) for x in re.split(r"[，,；;]", body) if len(clean(x)) >= 5]
    if MATRIX_HINT.search(joined) and len(clauses) >= 3:
        return {"type": "matrix", "layout": "auto", "title": title,
                "items": [{"quadrant": (i % 4) + 1, "title": shorten(p, 28)} for i, p in enumerate(clauses[:8])]}
    process_points = points if len(points) >= 3 else clauses
    if PROCESS_HINT.search(joined) and 3 <= len(process_points) <= 7:
        return {"type": "process", "layout": "auto", "title": title,
                "items": [{"title": f"步骤{i+1}", "body": shorten(p, 75)} for i, p in enumerate(process_points[:6])]}
    timeline_points = points if len(points) >= 3 else clauses
    if TIMELINE_HINT.search(joined) and 3 <= len(timeline_points) <= 7:
        items = []
        for i, p in enumerate(timeline_points[:6]):
            m = re.search(r"(20\d{2}(?:年\d{1,2}月)?|Q[1-4]|\d{1,2}月)", p, re.I)
            items.append({"time": m.group(1) if m else f"阶段{i+1}", "title": shorten(re.sub(r"(20\d{2}(?:年\d{1,2}月)?|Q[1-4]|\d{1,2}月)", "", p), 22), "body": shorten(p, 58)})
        return {"type": "timeline", "layout": "auto", "title": title, "items": items}
    if ACTION_HINT.search(joined) and len(clauses) >= 3:
        return {"type": "cards", "layout": "auto", "title": title,
                "items": [{"title": shorten(p, 20), "body": shorten(p, 65), "value": f"{i+1:02d}"} for i, p in enumerate(clauses[:6])]}
    if COMPARE_HINT.search(joined) and len(points) >= 2:
        half = max(1, math_ceil(len(points) / 2))
        return {"type": "comparison", "layout": "auto", "title": title,
                "left": {"title": "现状 / 方案 A", "items": points[:half]},
                "right": {"title": "目标 / 方案 B", "items": points[half:] or points[:half]}}
    if 2 <= len(points) <= 6 and all(len(p) <= 90 for p in points):
        return {"type": "cards", "layout": "auto", "title": title,
                "items": [{"title": shorten(p, 22), "body": shorten(p, 72), "value": f"{i+1:02d}"} for i, p in enumerate(points)]}
    return {"type": "content", "layout": "auto", "title": title,
            "body": shorten(points[0], 120) if points else shorten(body, 120),
            "bullets": points[1:7] if len(points) > 1 else points[:6]}


def math_ceil(v: float) -> int:
    return int(v) if int(v) == v else int(v) + 1


def recommended_page_count(text_length: int, dataset_count: int, image_count: int, minutes: int = 0) -> int:
    base = 6 + min(10, text_length // 1800) + min(4, dataset_count) + min(3, image_count // 2)
    if minutes > 0:
        # Most business pages need around 45-90 seconds of explanation.
        base = max(base, round(minutes / 1.2))
    return max(5, min(24, int(base)))


def diversify_sequence(slides: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Reorder later slides to avoid three consecutive identical page types."""
    result = list(slides)
    i = 2
    while i < len(result):
        current = str(result[i].get("type", "content"))
        if current == str(result[i-1].get("type", "content")) == str(result[i-2].get("type", "content")) and current != "section":
            swap_index = next((j for j in range(i + 1, len(result) - 1) if str(result[j].get("type", "content")) != current), None)
            if swap_index is not None:
                result[i], result[swap_index] = result[swap_index], result[i]
                i = max(2, i - 1)
                continue
        i += 1
    return result


def source_coverage(slides: list[dict[str, Any]], source_names: list[str]) -> dict[str, Any]:
    represented = set()
    for slide in slides:
        src = str(slide.get("source", ""))
        for name in source_names:
            if name and (name in src or Path(name).stem in src):
                represented.add(name)
    missing = [x for x in source_names if x not in represented]
    return {
        "source_file_count": len(source_names),
        "represented_source_count": len(represented),
        "represented_sources": sorted(represented),
        "unrepresented_sources": missing,
        "coverage_ratio": round(len(represented) / max(1, len(source_names)), 3),
    }


def load_template_style(path: str) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path).expanduser().resolve()
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def merge_template_layout_bias(profile: dict[str, Any], template_style: dict[str, Any]) -> dict[str, Any]:
    merged = dict(profile.get("layout_bias") or {})
    preferred = (template_style.get("layout_signals") or {}).get("preferred_layouts") or {}
    if isinstance(preferred, dict):
        for slide_type, layouts in preferred.items():
            if isinstance(layouts, list):
                merged[str(slide_type)] = list(dict.fromkeys([*layouts, *merged.get(str(slide_type), [])]))
    return merged

def main() -> int:
    parser = argparse.ArgumentParser(description="Draft adaptive deck_spec.json from analysis.json")
    parser.add_argument("--analysis", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--title", default="智能演示文稿")
    parser.add_argument("--subtitle", default="")
    parser.add_argument("--author", default="")
    parser.add_argument("--mode", default="auto", choices=["auto", "report", "proposal", "project", "training", "product", "research", "data"])
    parser.add_argument("--theme", default="auto")
    parser.add_argument("--style", default="auto", help="视觉风格；auto 自动选择，也可填写 clean-professional / executive-consulting / editorial-magazine / data-dashboard / academic-research / training-friendly / brand-pop / minimal-keynote / dark-tech / warm-storytelling / premium-luxury / china-red")
    parser.add_argument("--template-style", default="", help="由 template_style.py 从参考 PPT 提取的风格 JSON")
    parser.add_argument("--audience", default="")
    parser.add_argument("--purpose", default="")
    parser.add_argument("--target-pages", type=int, default=0)
    parser.add_argument("--presentation-minutes", type=int, default=0)
    args = parser.parse_args()

    analysis_path = Path(args.analysis).expanduser().resolve()
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    datasets = [d for d in analysis.get("datasets", []) if d.get("status") != "error"]
    files = [f for f in analysis.get("input_files", []) if f.get("status") in ("ok", "partial")]
    source_names = [f.get("name", "") for f in files]
    source = "、".join(source_names[:5]) or "用户导入资料"

    text_parts = []
    for f in files:
        if f.get("text"): text_parts.append(str(f["text"]))
        if f.get("json_preview"): text_parts.append(json.dumps(f["json_preview"], ensure_ascii=False))
    combined_text = "\n".join(text_parts)
    sections = extract_sections(combined_text)
    image_files = [f for f in files if f.get("image")]
    target_pages = args.target_pages if args.target_pages > 0 else recommended_page_count(len(combined_text), len(datasets), len(image_files), args.presentation_minutes)
    mode = infer_mode(combined_text, bool(datasets)) if args.mode == "auto" else args.mode
    domain = infer_domain(combined_text, datasets)
    all_charts: list[dict[str, Any]] = []
    for dataset in datasets:
        all_charts.extend(dataset.get("charts") or [])
    if mode == "data" and all_charts:
        reserved_chart_budget = min(5, max(3 if target_pages >= 8 else 2, target_pages // 3))
    else:
        reserved_chart_budget = min(4, max(0, target_pages // 4)) if all_charts else 0
    table_slide = table_slide_from_dataset(datasets, source) if mode == "data" else None
    template_style = load_template_style(args.template_style)
    template_requested_style = str(template_style.get("style_id") or "") if template_style else ""
    requested_style = template_requested_style if str(args.style).lower() == "auto" and template_requested_style else args.style
    style_id = choose_style(requested_style, mode=mode, audience=args.audience, purpose=args.purpose, title=args.title, text=combined_text)
    profile = style_profile(style_id)
    theme = profile.get("theme_name", theme_for_mode(mode)) if args.theme == "auto" else args.theme
    template_palette = template_style.get("palette") or {}
    template_fonts = template_style.get("fonts") or {}
    template_hints = template_style.get("render_hints") or {}
    layout_bias = merge_template_layout_bias(profile, template_style) if template_style else profile.get("layout_bias", {})

    subtitle = args.subtitle or {
        "proposal": "从问题洞察到实施路径",
        "project": "目标、进展、风险与下一步",
        "training": "结构化知识与实践方法",
        "product": "用户价值、核心卖点与应用场景",
        "research": "研究发现、证据与启示",
        "data": "指标、趋势、结构与行动建议",
        "report": "重点成果、问题与后续计划",
    }.get(mode, "")

    cover_subtitle = subtitle
    if args.audience:
        cover_subtitle = f"{cover_subtitle}｜面向{args.audience}" if cover_subtitle else f"面向{args.audience}"
    slides: list[dict[str, Any]] = [{"type": "cover", "layout": "auto", "title": args.title, "subtitle": cover_subtitle}]

    agenda_items = []
    if mode == "data":
        agenda_items = [
            {"title": "指标总览", "body": "规模、消耗与效率的核心 KPI"},
            {"title": "趋势变化", "body": "按日、周期或阶段观察波动"},
            {"title": "结构对比", "body": "分组贡献、效率和差异"},
            {"title": "异常诊断", "body": "识别高耗、低效与数据缺口"},
            {"title": "行动建议", "body": "将发现转成负责人和复盘节奏"},
        ]
    else:
        for s in sections[:5]:
            agenda_items.append({"title": shorten(s["title"], 24), "body": shorten(s["points"][0], 42) if s.get("points") else ""})
        if datasets:
            agenda_items.append({"title": "数据与证据", "body": "关键指标、趋势和结构分析"})
    if not agenda_items:
        agenda_items = [{"title": "背景与目标"}, {"title": "核心内容"}, {"title": "结论与下一步"}]
    slides.append({"type": "agenda", "layout": "auto", "title": "内容导航", "items": agenda_items[:6]})

    # Opening statement derived from the first meaningful sentence.
    first_point = ""
    if mode == "data" and analysis.get("global_findings"):
        first_point = str((analysis.get("global_findings") or [""])[0])
    else:
        for s in sections:
            if s.get("points"):
                first_point = s["points"][0]
                break
    if first_point:
        slides.append({"type": "statement", "layout": "auto", "title": "本期核心经营判断" if mode == "data" else "资料指向的核心判断",
                       "key_message": shorten(first_point, 58),
                       "body": "本页用于建立整份演示的核心叙事，后续页面将展开证据和行动。",
                       "source": source})

    fixed_data_pages = 5 + reserved_chart_budget + (1 if table_slide else 0)
    if mode == "data":
        section_budget = 0
    else:
        section_budget = max(2, min(len(sections), target_pages - 5))
    for i, section in enumerate(sections[:section_budget], 1):
        section_text = f"{section.get('title', '')} {section.get('body', '')}"
        # Action-oriented source sections are consolidated into the final closing page
        # to avoid repeating the same “下一步” content twice.
        if ACTION_HINT.search(section_text):
            continue
        slide = section_to_slide(section, i)
        slide["source"] = source
        slides.append(slide)

    # Add image-led pages when image files are supplied.
    if len(image_files) == 1:
        slides.append({"type": "image_feature", "layout": "auto", "title": "重点素材",
                       "image": image_files[0].get("path"), "body": "围绕该素材呈现关键信息或使用场景。",
                       "bullets": ["保持原图比例", "结合资料补充准确说明"], "source": image_files[0].get("name", "")})
    elif len(image_files) >= 2:
        slides.append({"type": "image_grid", "layout": "auto", "title": "素材与案例展示",
                       "images": [f.get("path") for f in image_files[:6]],
                       "captions": [f.get("name", "") for f in image_files[:6]], "source": source})

    primary = max(datasets, key=dataset_score) if datasets else {}
    if datasets and target_pages >= 10 and len(slides) >= 5:
        slides.append({
            "type": "section", "layout": "auto", "number": "02",
            "title": "数据与证据", "subtitle": "用关键指标、趋势和结构验证前述判断"
        })
    kpis = build_energy_kpis(primary) if domain == "energy-operations" else build_kpis(primary)
    if kpis:
        slides.append({"type": "cards", "layout": "auto", "title": "关键指标概览", "items": kpis, "source": source})

    findings = analysis.get("global_findings") or []
    selected_charts = select_charts(all_charts, reserved_chart_budget)
    for ci, chart in enumerate(selected_charts, 1):
        desc = chart.get("description") or chart.get("title") or "数据变化"
        slides.append({
            "type": "chart", "layout": "auto", "title": shorten(chart.get("title") or desc, 34),
            "key_message": shorten(desc, 48), "image": chart.get("image"),
            "chart_data": chart.get("chart_data") or {},
            "insights": [desc, "结合业务背景解释变化原因，并核验指标口径。"],
            "source": " / ".join(x for x in [Path(chart.get("source_file", "")).name, chart.get("sheet") or ""] if x),
        })
        if ci == 2 and len(selected_charts) > 2:
            bridge_index = 1 if mode == "data" and len(findings) > 1 else 0
            bridge = findings[bridge_index] if findings else "关键变化需要结合业务动作、渠道和人群进一步解释。"
            slides.append({"type": "statement", "layout": "auto", "title": "阶段性数据判断",
                           "key_message": shorten(bridge, 58),
                           "body": "在进入下一组图表前，先明确当前证据所支持的主要判断。", "source": source})

    if table_slide:
        slides.append(table_slide)

    anomaly_slide = anomaly_slide_from_sections(sections, source) if mode == "data" else None
    if anomaly_slide:
        slides.append(anomaly_slide)

    if findings:
        slides.append({"type": "summary", "layout": "auto", "title": "关键发现",
                       "items": [{"title": finding_title(x), "body": shorten(x, 82), "value": f"{i+1:02d}"} for i, x in enumerate(findings[:6])],
                       "source": source})

    diagnostics = analysis.get("diagnostics") or []
    if diagnostics:
        limitation_items = []
        seen_codes = set()
        for diag in diagnostics:
            code = diag.get("code", "")
            if code in seen_codes:
                continue
            seen_codes.add(code)
            limitation_items.append({
                "title": shorten(diag.get("message") or code or "资料限制", 24),
                "body": shorten(diag.get("suggestion") or "正式使用前请核查原始资料。", 88),
                "value": str(len(limitation_items) + 1).zfill(2),
            })
            if len(limitation_items) >= 4:
                break
        slides.append({
            "type": "cards", "layout": "auto", "title": "资料限制与使用说明",
            "items": limitation_items,
            "source": "analysis.json 解析诊断",
        })

    action_points = []
    preferred_action_sections = [s for s in sections if re.search(r"建议行动|行动建议|下一步|改善措施", str(s.get("title", "")), re.I)]
    for s in preferred_action_sections or sections:
        for p in s.get("points", []):
            if ACTION_HINT.search(p): action_points.append(p)
    if not action_points:
        action_points = ["确认目标、受众和成功标准", "围绕关键内容完善证据与案例", "明确负责人、时间节点和复盘机制"]
    slides.append({"type": "closing", "layout": "auto", "title": "下一步行动",
                   "items": [{"title": action_title(p), "body": shorten(p, 72)} for p in list(dict.fromkeys(action_points))[:4]]})

    # Respect a requested upper page count without deleting cover, navigation or closing.
    if target_pages and len(slides) > target_pages:
        keep_first = slides[:2]
        keep_last = slides[-1:]
        middle = slides[2:-1]
        priority = {"statement": 1, "content": 1, "cards": 3, "process": 3, "timeline": 2, "comparison": 4, "matrix": 3, "chart": 7, "table": 6, "summary": 4, "image_feature": 2, "image_grid": 2, "section": 2}
        selected = sorted(enumerate(middle), key=lambda x: (-priority.get(x[1].get("type", "content"), 1), x[0]))[: max(0, target_pages - 3)]
        selected = [slide for _, slide in sorted(selected, key=lambda x: x[0])]
        slides = keep_first + selected + keep_last

    slides = diversify_sequence(slides)
    coverage = source_coverage(slides, source_names)
    complexity = "high" if len(combined_text) > 24000 or len(files) > 8 or len(datasets) > 6 else "medium" if len(combined_text) > 8000 or len(files) > 3 else "normal"
    deck = {
        "title": args.title, "subtitle": subtitle, "author": args.author,
        "audience": args.audience, "purpose": args.purpose,
        "date": date.today().isoformat(), "mode": mode,
        "planning": {
            "target_pages": target_pages,
            "actual_pages": len(slides),
            "presentation_minutes": args.presentation_minutes,
            "content_complexity": complexity,
            "manual_review_required": analysis.get("manual_review_required", False) or complexity == "high",
            "domain": domain,
            "reserved_chart_pages": reserved_chart_budget,
            "selected_chart_pages": len(selected_charts),
            "style_id": style_id,
            "style_name": template_style.get("style_name") or profile.get("display_name", style_id),
            "style_reason": "参考 PPT 模板驱动" if template_style else ("用户指定视觉方向" if str(args.style).lower() != "auto" else f"根据 {mode} 内容、受众与演示目的自动匹配"),
        },
        "theme": {
            "name": theme,
            "visual_style": style_id,
            "style_name": template_style.get("style_name") or profile.get("display_name", style_id),
            "density": template_hints.get("density") or profile.get("density", "balanced"),
            "header_variant": template_hints.get("header_variant") or profile.get("header_variant", "hairline"),
            "footer_mode": template_hints.get("footer_mode") or profile.get("footer_mode", "source-page"),
            "decorative_mode": template_hints.get("decorative_mode") or profile.get("decorative_mode", "quiet"),
            "layout_bias": layout_bias,
            "custom_colors": {k: v for k, v in template_palette.items() if isinstance(v, str)},
            "font_cn": template_fonts.get("font_cn") or "Microsoft YaHei",
            "font_en": template_fonts.get("font_en") or "Aptos",
            "template_style": {
                "source_pptx": template_style.get("source_pptx"),
                "name": template_style.get("name"),
                "reference_images": template_style.get("reference_images", [])[:6],
                "layout_recipes": template_style.get("layout_recipes", []),
                "color_zone_signals": template_style.get("color_zone_signals", {}),
                "render_hints": template_style.get("render_hints", {}),
                "notes": template_style.get("notes", []),
                "template_strength": "strong",
            } if template_style else {},
        },
        "provenance": {
            "analysis_status": analysis.get("status", "unknown"),
            "source_files": source_names,
            "source_coverage": coverage,
            "capability_boundaries": analysis.get("capability_boundaries", []),
        },
        "slides": slides,
    }
    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(deck, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
