#!/usr/bin/env python3
"""Validate PPTX structure, readability and layout diversity."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Inches


def shape_text(shape) -> str:
    return getattr(shape, "text", "").strip() if hasattr(shape, "text") else ""


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate adaptive PPTX layout and content")
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--spec", default="")
    parser.add_argument("--analysis", default="")
    parser.add_argument("--content-review", default="")
    parser.add_argument("--visual-plan", default="")
    args = parser.parse_args()

    pptx_path = Path(args.pptx).expanduser().resolve()
    prs = Presentation(str(pptx_path))
    sw, sh = prs.slide_width, prs.slide_height
    issues: list[dict] = []
    slide_reports = []

    for sidx, slide in enumerate(prs.slides, 1):
        sissues = []
        texts = []
        for shape in slide.shapes:
            if shape.left < 0 or shape.top < 0 or shape.left + shape.width > sw or shape.top + shape.height > sh:
                sissues.append({"type": "out_of_bounds", "severity": "error", "shape": shape.name})
            text = shape_text(shape)
            if text:
                texts.append(text)
                if len(text) > 460:
                    sissues.append({"type": "too_much_text", "severity": "warning", "shape": shape.name, "characters": len(text)})
                if hasattr(shape, "text_frame"):
                    for p in shape.text_frame.paragraphs:
                        for run in p.runs:
                            if run.font.size and run.font.size.pt < 9.5:
                                sissues.append({"type": "font_too_small", "severity": "warning", "shape": shape.name, "size_pt": run.font.size.pt})
                    # Conservative overflow heuristic: estimate capacity from box area and dominant font size.
                    sizes = [run.font.size.pt for p in shape.text_frame.paragraphs for run in p.runs if run.font.size]
                    avg_size = sum(sizes) / len(sizes) if sizes else 16.0
                    width_in = shape.width / 914400
                    height_in = shape.height / 914400
                    estimated_capacity = max(12, int(width_in * height_in * 52 * (16.0 / max(avg_size, 8.0))))
                    if len(text) > estimated_capacity * 1.35:
                        sissues.append({"type": "possible_text_overflow", "severity": "warning", "shape": shape.name, "characters": len(text), "estimated_capacity": estimated_capacity})
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE and (shape.width < Inches(0.5) or shape.height < Inches(0.5)):
                sissues.append({"type": "tiny_image", "severity": "warning", "shape": shape.name})
        if sidx > 1 and not texts:
            sissues.append({"type": "empty_slide", "severity": "error"})
        slide_reports.append({"slide": sidx, "text_characters": sum(len(t) for t in texts), "issues": sissues})
        issues.extend({"slide": sidx, **issue} for issue in sissues)

    layout_report = {}
    if args.spec:
        spec_path = Path(args.spec).expanduser().resolve()
        if spec_path.exists():
            spec = json.loads(spec_path.read_text(encoding="utf-8"))
            slides = spec.get("slides") or []
            theme_cfg = spec.get("theme") or {}
            style_id = theme_cfg.get("visual_style", "clean-professional") if isinstance(theme_cfg, dict) else "clean-professional"
            requested_layouts = [str(s.get("layout", "auto")) for s in slides]
            types = [str(s.get("type", "content")) for s in slides]
            # Resolve auto layouts with the same selector used by the renderer.
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            try:
                from build_deck import choose_layout  # type: ignore
                effective_layouts = []
                history = []
                for i, slide in enumerate(slides, 1):
                    stype = slide.get("type", "content")
                    if stype == "text": stype = "content"
                    if stype == "kpi": stype = "cards"
                    layout = choose_layout({**slide, "type": stype, "_style_id": style_id}, i, spec_path.parent, history)
                    history.append(layout)
                    effective_layouts.append(layout)
            except Exception:
                effective_layouts = requested_layouts
            unique_layouts = len(set(effective_layouts))
            unique_types = len(set(types))
            layout_report = {"style_id": style_id, "requested_layouts": requested_layouts, "effective_layouts": effective_layouts, "types": types, "unique_layouts": unique_layouts, "unique_types": unique_types}
            for i in range(2, len(slides)):
                if effective_layouts[i] == effective_layouts[i-1] == effective_layouts[i-2]:
                    issues.append({"slide": i + 1, "type": "three_repeated_layouts", "severity": "warning", "layout": effective_layouts[i]})
                if types[i] == types[i-1] == types[i-2] and types[i] not in ("section",):
                    issues.append({"slide": i + 1, "type": "three_repeated_slide_types", "severity": "warning", "slide_type": types[i]})
            if len(slides) >= 8 and unique_types < 5:
                issues.append({"slide": None, "type": "insufficient_slide_type_variety", "severity": "warning", "unique_types": unique_types})
            if len(slides) >= 8 and unique_layouts < 5:
                issues.append({"slide": None, "type": "insufficient_layout_variety", "severity": "warning", "unique_layouts": unique_layouts})
            try:
                from style_engine import STYLE_PRESETS  # type: ignore
                if style_id not in STYLE_PRESETS:
                    issues.append({"slide": None, "type": "unknown_visual_style", "severity": "warning", "style_id": style_id})
            except Exception:
                pass
            if effective_layouts:
                dominant = max((effective_layouts.count(x), x) for x in set(effective_layouts))
                if len(effective_layouts) >= 8 and dominant[0] / len(effective_layouts) > 0.45:
                    issues.append({"slide": None, "type": "dominant_layout_ratio_high", "severity": "warning", "layout": dominant[1], "ratio": round(dominant[0] / len(effective_layouts), 3)})

    analysis_report = {}
    if args.analysis:
        analysis_path = Path(args.analysis).expanduser().resolve()
        if analysis_path.exists():
            analysis_report = json.loads(analysis_path.read_text(encoding="utf-8"))
            if analysis_report.get("status") == "fail":
                issues.append({"slide": None, "type": "analysis_failed", "severity": "error"})
            elif analysis_report.get("status") == "partial":
                issues.append({"slide": None, "type": "analysis_partial", "severity": "warning", "diagnostic_count": len(analysis_report.get("diagnostics") or [])})

    content_review_report = {}
    if args.content_review:
        review_path = Path(args.content_review).expanduser().resolve()
        if review_path.exists():
            content_review_report = json.loads(review_path.read_text(encoding="utf-8"))
            for item in content_review_report.get("issues") or []:
                issues.append({
                    "slide": item.get("slide"),
                    "type": f"content_{item.get('code', 'review_issue').lower()}",
                    "severity": item.get("severity", "warning"),
                    "message": item.get("message", ""),
                })

    visual_report = {}
    if args.visual_plan:
        visual_path = Path(args.visual_plan).expanduser().resolve()
        if visual_path.exists():
            visual_plan = json.loads(visual_path.read_text(encoding="utf-8"))
            visual_report = {
                "status": visual_plan.get("status"),
                "planned_count": int(visual_plan.get("planned_count", 0) or 0),
                "applied_count": int(visual_plan.get("applied_count", 0) or 0),
                "pending_count": int(visual_plan.get("pending_count", 0) or 0),
                "native_label_overlay": True,
            }

    errors = [x for x in issues if x.get("severity") == "error"]
    report = {
        "file": str(pptx_path),
        "slide_count": len(prs.slides),
        "size": {"width_inches": sw / 914400, "height_inches": sh / 914400},
        "status": "fail" if errors else ("review" if issues else "pass"),
        "issue_count": len(issues),
        "error_count": len(errors),
        "issues": issues,
        "layout_report": layout_report,
        "analysis_summary": analysis_report.get("summary", {}) if analysis_report else {},
        "content_review_summary": content_review_report.get("summary", {}) if content_review_report else {},
        "visual_report": visual_report,
        "slides": slide_reports,
    }
    report_path = Path(args.report).expanduser().resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    user_lines = [
        "# PPT 版式检查结果", "",
        f"- 页数：{len(prs.slides)} 页",
        f"- 状态：**{'通过' if not errors else '需要修复'}**",
        f"- 问题数量：{len(issues)}",
        f"- 阻断问题：{len(errors)}",
    ]
    if issues:
        user_lines += ["", "## 问题与建议"]
        for item in issues[:15]:
            page = f"第 {item.get('slide')} 页" if item.get('slide') else "整份文稿"
            kind = item.get("type", "检查项")
            suggestions = {
                "out_of_bounds": "缩小或移动超出页面边界的元素。",
                "too_much_text": "拆页或精简为一页一个中心观点。",
                "possible_text_overflow": "缩短文字或改用双栏/卡片布局。",
                "font_too_small": "减少内容，不要继续缩小字号。",
                "empty_slide": "删除空页或补充必要内容。",
                "three_repeated_layouts": "更换其中一页的结构或视觉重点。",
                "three_repeated_slide_types": "穿插观点页、图表页、流程页或过渡页。",
            }
            user_lines.append(f"- **{page}**：{kind}。{suggestions.get(kind, item.get('message', '请按检查报告调整。'))}")
    else:
        user_lines += ["", "未发现明显越界、空页、字号或布局重复问题。"]
    (report_path.parent / "版式检查说明.md").write_text("\n".join(user_lines), encoding="utf-8")
    print(str(report_path))
    return 2 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
