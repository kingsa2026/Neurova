#!/usr/bin/env python3
"""Score how closely a generated PPT follows an extracted template style."""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from pptx import Presentation


def clean_hex(value: Any) -> str:
    raw = str(value or "").strip().lstrip("#").upper()
    return raw if len(raw) == 6 and all(c in "0123456789ABCDEF" for c in raw) else ""


def distance(a: str, b: str) -> float:
    return sum((int(a[i:i+2], 16) - int(b[i:i+2], 16)) ** 2 for i in (0, 2, 4)) ** 0.5


def color_score(expected: str, observed: list[str]) -> float:
    expected = clean_hex(expected)
    if not expected or not observed:
        return 0.0
    best = min(distance(expected, c) for c in observed if clean_hex(c))
    return max(0.0, 100.0 * (1.0 - min(best, 180.0) / 180.0))


def collect_ppt_signals(pptx_path: Path) -> dict[str, Any]:
    prs = Presentation(str(pptx_path))
    colors: Counter[str] = Counter()
    fonts: Counter[str] = Counter()
    chart_count = 0
    picture_count = 0
    background_colors: Counter[str] = Counter()
    for slide in prs.slides:
        try:
            bg = clean_hex(str(slide.background.fill.fore_color.rgb))
            if bg:
                colors[bg] += 4
                background_colors[bg] += 4
        except Exception:
            pass
        for shape in slide.shapes:
            if getattr(shape, "has_chart", False):
                chart_count += 1
            if getattr(shape, "shape_type", None) == 13:
                picture_count += 1
            try:
                if shape.fill and shape.fill.type == 1:
                    c = clean_hex(str(shape.fill.fore_color.rgb))
                    if c:
                        colors[c] += 2
            except Exception:
                pass
            if getattr(shape, "has_text_frame", False):
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.name:
                            fonts[run.font.name] += 1
                        try:
                            c = clean_hex(str(run.font.color.rgb))
                            if c:
                                colors[c] += 2
                        except Exception:
                            pass
    return {
        "slide_count": len(prs.slides),
        "colors": [{"color": k, "count": v} for k, v in colors.most_common(24)],
        "background_colors": [{"color": k, "count": v} for k, v in background_colors.most_common(12)],
        "fonts": [{"name": k, "count": v} for k, v in fonts.most_common(12)],
        "chart_count": chart_count,
        "picture_count": picture_count,
    }


def effective_layouts(spec: dict[str, Any], spec_path: Path) -> list[str]:
    slides = spec.get("slides") or []
    theme = spec.get("theme") or {}
    style_id = theme.get("visual_style", "clean-professional") if isinstance(theme, dict) else "clean-professional"
    script_dir = Path(__file__).resolve().parent
    sys.path.insert(0, str(script_dir))
    try:
        from build_deck import choose_layout  # type: ignore
    except Exception:
        return [str(s.get("layout", "auto")) for s in slides]
    history: list[str] = []
    result: list[str] = []
    for i, slide in enumerate(slides, 1):
        stype = slide.get("type", "content")
        if stype == "text":
            stype = "content"
        if stype == "kpi":
            stype = "cards"
        layout = choose_layout({**slide, "type": stype, "_style_id": style_id}, i, spec_path.parent, history)
        history.append(layout)
        result.append(layout)
    return result


def score_layouts(spec: dict[str, Any], layouts: list[str], template_style: dict[str, Any]) -> tuple[float, dict[str, Any]]:
    slides = spec.get("slides") or []
    preferred = ((template_style.get("layout_signals") or {}).get("preferred_layouts") or {})
    matched = 0
    checked = 0
    for slide, layout in zip(slides, layouts):
        stype = str(slide.get("type", "content"))
        options = preferred.get(stype) or []
        if options:
            checked += 1
            if layout in options:
                matched += 1
    variety = len(set(layouts)) / max(1, min(len(layouts), 8))
    preferred_score = 100.0 if checked == 0 else matched / checked * 100.0
    score = preferred_score * 0.65 + min(1.0, variety) * 100.0 * 0.35
    return score, {"checked": checked, "matched": matched, "unique_layouts": len(set(layouts)), "effective_layouts": layouts}


def write_markdown(path: Path, report: dict[str, Any]) -> None:
    lines = [
        "# 模板还原度报告",
        "",
        f"- 总体评分：**{report['overall_score']} / 100**",
        f"- 状态：{report['status']}",
        f"- 参考模板：{report.get('template_name') or '未命名模板'}",
        f"- 生成页数：{report['generated_signals'].get('slide_count', 0)}",
        f"- 原生图表对象：{report['generated_signals'].get('chart_count', 0)}",
        "",
        "## 分项评分",
    ]
    for item in report.get("scores", []):
        lines.append(f"- {item['name']}：{item['score']} / 100")
    if report.get("recommendations"):
        lines += ["", "## 优化建议"]
        lines.extend(f"- {x}" for x in report["recommendations"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate generated PPT template fidelity")
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--template-style", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    pptx_path = Path(args.pptx).expanduser().resolve()
    spec_path = Path(args.spec).expanduser().resolve()
    template_path = Path(args.template_style).expanduser().resolve()
    report_path = Path(args.report).expanduser().resolve()

    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    template_style = json.loads(template_path.read_text(encoding="utf-8"))
    generated = collect_ppt_signals(pptx_path)
    observed_colors = [x["color"] for x in generated["colors"]]
    palette = template_style.get("palette") or {}

    palette_parts = []
    for key in ("primary", "accent", "background", "text"):
        palette_parts.append({"key": key, "expected": palette.get(key), "score": round(color_score(palette.get(key, ""), observed_colors), 1)})
    palette_score = sum(x["score"] for x in palette_parts) / max(1, len(palette_parts))

    expected_font = ((template_style.get("fonts") or {}).get("font_cn") or "").lower()
    observed_fonts = [x["name"].lower() for x in generated["fonts"]]
    font_score = 100.0 if expected_font and any(expected_font in f or f in expected_font for f in observed_fonts) else 70.0 if observed_fonts else 50.0

    layouts = effective_layouts(spec, spec_path)
    layout_score, layout_detail = score_layouts(spec, layouts, template_style)
    chart_slides = [s for s in spec.get("slides", []) if s.get("type") == "chart"]
    chart_score = 100.0 if not chart_slides else min(100.0, generated["chart_count"] / max(1, len(chart_slides)) * 100.0)
    background_expected = [x.get("color") for x in template_style.get("background_colors", [])[:4] if x.get("color")]
    background_observed = [x["color"] for x in generated["background_colors"]] or observed_colors
    background_score = max([color_score(c, background_observed) for c in background_expected] or [color_score(palette.get("background", ""), background_observed)])

    scores = [
        {"name": "配色匹配", "score": round(palette_score, 1), "details": palette_parts},
        {"name": "背景匹配", "score": round(background_score, 1), "details": {"expected": background_expected, "observed": background_observed[:8]}},
        {"name": "字体匹配", "score": round(font_score, 1), "details": {"expected": expected_font, "observed": observed_fonts[:8]}},
        {"name": "版式节奏", "score": round(layout_score, 1), "details": layout_detail},
        {"name": "可编辑图表", "score": round(chart_score, 1), "details": {"chart_slides": len(chart_slides), "native_charts": generated["chart_count"]}},
    ]
    overall = round(sum(item["score"] * weight for item, weight in zip(scores, [0.28, 0.18, 0.14, 0.25, 0.15])), 1)
    recommendations = []
    if palette_score < 78:
        recommendations.append("配色还原度偏低：建议检查 theme.custom_colors，尤其是 primary、accent、background 和 text。")
    if background_score < 78:
        recommendations.append("背景还原度偏低：建议提升 template_style.background_colors 中高频背景色的优先级。")
    if layout_score < 78:
        recommendations.append("版式节奏偏离模板：建议增加 layout_recipes 或调整 layout_bias。")
    if chart_score < 100 and chart_slides:
        recommendations.append("部分图表未渲染为原生可编辑图表：建议检查 chart_data 是否完整。")
    status = "pass" if overall >= 82 else "review" if overall >= 65 else "low"
    report = {
        "status": status,
        "overall_score": overall,
        "template_name": template_style.get("name"),
        "template_source": template_style.get("source_pptx"),
        "scores": scores,
        "recommendations": recommendations,
        "generated_signals": generated,
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    write_markdown(report_path.with_name("模板还原度报告.md"), report)
    print(str(report_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
