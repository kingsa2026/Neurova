#!/usr/bin/env python3
"""Check runtime dependencies and Chinese desktop compatibility without installing."""
from __future__ import annotations

import importlib
import json
import locale
import platform
import sys
from pathlib import Path
from typing import Any

REQUIRED = {
    "pandas": "pandas>=2.0,<3.0",
    "numpy": "numpy>=1.24,<3.0",
    "pptx": "python-pptx>=0.6.23,<2.0",
    "openpyxl": "openpyxl>=3.1,<4.0",
    "matplotlib": "matplotlib>=3.7,<4.0",
    "docx": "python-docx>=1.1,<2.0",
    "pypdf": "pypdf>=4.0,<7.0",
    "yaml": "PyYAML>=6.0,<7.0",
    "PIL": "Pillow>=10.0,<13.0",
    "charset_normalizer": "charset-normalizer>=3.3,<4.0",
}
OPTIONAL = {"xlrd": "xlrd>=2.0.1,<3.0（读取旧版 .xls）"}
CJK_FONTS = ["Microsoft YaHei", "SimHei", "PingFang SC", "Noto Sans CJK SC", "Source Han Sans SC"]


def check(modules: dict[str, str]) -> tuple[list[dict[str, str]], list[str]]:
    ok, missing = [], []
    for module, package in modules.items():
        try:
            imported = importlib.import_module(module)
            version = str(getattr(imported, "__version__", "unknown"))
            ok.append({"module": module, "version": version})
        except Exception:
            missing.append(package)
    return ok, missing


def find_cjk_fonts() -> list[str]:
    try:
        from matplotlib import font_manager
        installed = {f.name for f in font_manager.fontManager.ttflist}
        return [x for x in CJK_FONTS if x in installed]
    except Exception:
        return []


def main() -> int:
    required_ok, required_missing = check(REQUIRED)
    optional_ok, optional_missing = check(OPTIONAL)
    fonts = find_cjk_fonts()
    python_ok = sys.version_info >= (3, 9)
    warnings: list[dict[str, Any]] = []
    if optional_missing:
        warnings.append({
            "title": "旧版 Excel 支持未启用",
            "message": "当前没有安装 xlrd；.xlsx 不受影响，.xls 建议先另存为 .xlsx。",
            "steps": ["优先转换为 .xlsx", "或安装 xlrd>=2.0.1,<3.0"],
        })
    if not fonts:
        warnings.append({
            "title": "未检测到常见中文字体",
            "message": "PPT 仍可生成，但在本机打开时可能发生字体替换。",
            "steps": ["Windows 优先使用微软雅黑", "macOS 优先使用苹方", "Linux 可安装 Noto Sans CJK"],
        })
    errors: list[dict[str, Any]] = []
    if not python_ok:
        errors.append({
            "title": "Python 版本过低",
            "message": f"当前版本为 {sys.version.split()[0]}，需要 Python 3.9 或更高版本。",
            "steps": ["升级 Python", "重新创建运行环境", "再次执行环境检查"],
        })
    if required_missing:
        errors.append({
            "title": "运行组件未安装完整",
            "message": "缺少生成 PPT 所需的核心依赖。",
            "steps": ["执行 pip install -r requirements.txt", "无法联网时使用平台预装环境或离线轮子包"],
            "missing": required_missing,
        })

    result = {
        "python": sys.version.split()[0],
        "python_ok": python_ok,
        "platform": platform.platform(),
        "system": platform.system(),
        "locale": locale.getpreferredencoding(False),
        "required_ok": required_ok,
        "required_missing": required_missing,
        "optional_ok": optional_ok,
        "optional_missing": optional_missing,
        "detected_cjk_fonts": fonts,
        "status": "pass" if not errors else "fail",
        "warnings": warnings,
        "errors": errors,
    }
    Path("preflight.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# 运行环境检查",
        "",
        f"- 状态：**{'通过' if not errors else '需要处理'}**",
        f"- Python：{result['python']}",
        f"- 系统：{result['system']}",
        f"- 默认编码：{result['locale']}",
        f"- 中文字体：{('、'.join(fonts) if fonts else '未检测到常见字体')}",
    ]
    if warnings:
        lines += ["", "## 提醒"]
        for item in warnings:
            lines.append(f"- **{item['title']}**：{item['message']}")
            for step in item.get("steps", []):
                lines.append(f"  - {step}")
    if errors:
        lines += ["", "## 需要处理"]
        for item in errors:
            lines.append(f"- **{item['title']}**：{item['message']}")
            for step in item.get("steps", []):
                lines.append(f"  - {step}")
    Path("运行环境检查.md").write_text("\n".join(lines), encoding="utf-8")
    print("环境检查完成：" + ("可以运行" if not errors else "需要先处理依赖或版本问题"))
    print(str(Path("运行环境检查.md").resolve()))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
