#!/usr/bin/env python3
"""Zero-configuration launcher for everyday users."""
from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SUPPORTED = {".xlsx", ".xls", ".csv", ".tsv", ".docx", ".pdf", ".pptx", ".txt", ".md", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif"}


def discover_current() -> list[Path]:
    ignored = {"output", "presentation_output", "demo", "__pycache__"}
    return [
        p for p in sorted(Path.cwd().iterdir())
        if p.is_file() and p.suffix.lower() in SUPPORTED and not p.name.startswith("~$")
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description="把当前资料快速整理成 PPT")
    parser.add_argument("inputs", nargs="*", help="资料文件；不填写时自动读取当前目录")
    parser.add_argument("--title", default="")
    parser.add_argument("--outdir", default="")
    parser.add_argument("--audience", default="")
    parser.add_argument("--purpose", default="")
    parser.add_argument("--pages", type=int, default=0)
    parser.add_argument("--style", default="auto", help="视觉风格；auto 为智能匹配")
    parser.add_argument("--theme", default="auto", help="可选：直接指定配色主题")
    parser.add_argument("--template-pptx", default="", help="参考 PPT 模板；自动提取背景、字体颜色、配色、布局和图片风格")
    parser.add_argument("--visual-mode", default="auto", choices=["off", "plan", "auto", "assets"], help="自动配图模式")
    parser.add_argument("--visual-assets-dir", default="", help="已生成配图所在目录")
    parser.add_argument("--max-visuals", type=int, default=12, help="最多规划的生成配图数量")
    args = parser.parse_args()

    paths = [Path(x).expanduser().resolve() for x in args.inputs] if args.inputs else discover_current()
    if not paths:
        print("当前目录没有找到可处理的办公文件。请把资料放到当前目录，或在命令后填写文件路径。", file=sys.stderr)
        return 2
    title = args.title or (paths[0].stem + "汇报")
    outdir = Path(args.outdir).expanduser().resolve() if args.outdir else Path.cwd() / "presentation_output" / datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{title}.pptx".replace("/", "-").replace("\\", "-")
    script_dir = Path(__file__).resolve().parent
    command = [
        sys.executable, str(script_dir / "run_pipeline.py"),
        "--inputs", *[str(x) for x in paths],
        "--outdir", str(outdir),
        "--title", title,
        "--filename", filename,
        "--audience", args.audience,
        "--purpose", args.purpose,
        "--target-pages", str(args.pages),
        "--style", args.style,
        "--theme", args.theme,
        "--visual-mode", args.visual_mode,
        "--max-visuals", str(args.max_visuals),
    ]
    if args.template_pptx:
        command += ["--template-pptx", str(Path(args.template_pptx).expanduser().resolve())]
    if args.visual_assets_dir:
        command += ["--visual-assets-dir", str(Path(args.visual_assets_dir).expanduser().resolve())]
    print(f"已找到 {len(paths)} 份资料，将自动生成：{title}")
    completed = subprocess.run(command, check=False)
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
