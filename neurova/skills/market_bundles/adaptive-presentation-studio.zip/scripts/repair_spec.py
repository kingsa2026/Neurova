#!/usr/bin/env python3
"""Conservatively repair a deck specification after render or validation failure."""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

SUPPORTED_TYPES = {
    "cover", "agenda", "section", "statement", "quote", "content", "text",
    "cards", "summary", "kpi", "process", "timeline", "comparison", "matrix",
    "chart", "table", "image_feature", "image_grid", "closing",
}


def clip(value: Any, limit: int) -> str:
    text = " ".join(str(value or "").split())
    return text if len(text) <= limit else text[: max(1, limit - 1)] + "…"


def existing_path(value: Any, base: Path) -> bool:
    if not value:
        return False
    p = Path(str(value)).expanduser()
    if not p.is_absolute():
        p = (base / p).resolve()
    return p.exists() and p.is_file()


def repair_slide(slide: dict[str, Any], base: Path, aggressive: bool = False) -> tuple[dict[str, Any], list[str]]:
    changes: list[str] = []
    s = dict(slide)
    stype = str(s.get("type", "content"))
    if stype not in SUPPORTED_TYPES:
        s["type"] = "content"
        changes.append(f"不支持的页面类型 {stype} 已改为 content")
    s["layout"] = "auto"
    s["title"] = clip(s.get("title") or "内容要点", 36)
    for key, limit in (("subtitle", 60), ("key_message", 70), ("body", 180), ("source", 120)):
        if key in s:
            s[key] = clip(s.get(key), limit)

    if isinstance(s.get("bullets"), list):
        s["bullets"] = [clip(x, 85) for x in s["bullets"][:5 if aggressive else 6] if clip(x, 85)]
    if isinstance(s.get("insights"), list):
        s["insights"] = [clip(x, 95) for x in s["insights"][:4] if clip(x, 95)]
    if isinstance(s.get("items"), list):
        max_items = 4 if aggressive else 6
        items = []
        for item in s["items"][:max_items]:
            if isinstance(item, dict):
                fixed = dict(item)
                fixed["title"] = clip(fixed.get("title") or fixed.get("time") or "要点", 24)
                if "body" in fixed:
                    fixed["body"] = clip(fixed.get("body"), 70)
                if "value" in fixed:
                    fixed["value"] = clip(fixed.get("value"), 18)
                items.append(fixed)
            else:
                items.append({"title": clip(item, 24), "body": clip(item, 70)})
        s["items"] = items

    for side in ("left", "right"):
        if isinstance(s.get(side), dict):
            block = dict(s[side])
            block["title"] = clip(block.get("title") or side, 24)
            if isinstance(block.get("items"), list):
                block["items"] = [clip(x, 75) for x in block["items"][:5]]
            s[side] = block

    # Remove broken image references instead of crashing the whole deck.
    if s.get("image") and not existing_path(s.get("image"), base):
        s.pop("image", None)
        if s.get("type") in {"chart", "image_feature"}:
            s["type"] = "content"
            s.setdefault("body", "原始图片未找到，本页已切换为兼容文字版。")
        changes.append("缺失图片已移除并切换到兼容布局")
    if isinstance(s.get("images"), list):
        kept = [x for x in s["images"] if existing_path(x, base)][:6]
        if len(kept) != len(s["images"]):
            changes.append("无效图片已从图片网格中移除")
        s["images"] = kept
        if not kept and s.get("type") == "image_grid":
            s["type"] = "content"
            s["body"] = "图片素材未能读取，请重新上传后替换本页。"

    if s.get("type") == "table":
        rows = s.get("rows") or s.get("data") or []
        if isinstance(rows, list):
            s["rows"] = rows[:8 if not aggressive else 6]
    return s, changes


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair a deck_spec.json conservatively")
    parser.add_argument("--spec", required=True)
    parser.add_argument("--output", default="")
    parser.add_argument("--validation", default="")
    parser.add_argument("--aggressive", action="store_true")
    args = parser.parse_args()

    spec_path = Path(args.spec).expanduser().resolve()
    out_path = Path(args.output).expanduser().resolve() if args.output else spec_path
    deck = json.loads(spec_path.read_text(encoding="utf-8"))
    backup = spec_path.with_suffix(spec_path.suffix + ".bak")
    if out_path == spec_path and not backup.exists():
        shutil.copy2(spec_path, backup)

    problematic: set[int] = set()
    if args.validation and Path(args.validation).exists():
        report = json.loads(Path(args.validation).read_text(encoding="utf-8"))
        for issue in report.get("issues") or []:
            if isinstance(issue.get("slide"), int):
                problematic.add(int(issue["slide"]))

    slides = []
    change_log = []
    for idx, slide in enumerate(deck.get("slides") or [], 1):
        aggressive = args.aggressive or idx in problematic
        repaired, changes = repair_slide(slide if isinstance(slide, dict) else {}, spec_path.parent, aggressive)
        slides.append(repaired)
        if changes:
            change_log.append({"slide": idx, "changes": changes})
    deck["slides"] = slides
    theme = deck.get("theme") if isinstance(deck.get("theme"), dict) else {}
    if not theme.get("name"):
        theme["name"] = "modern-blue"
    theme.setdefault("density", "balanced")
    theme.setdefault("visual_style", "clean-professional")
    deck["theme"] = theme
    deck.setdefault("repair_history", []).append({
        "mode": "aggressive" if args.aggressive else "conservative",
        "changed_slides": len(change_log),
        "changes": change_log,
    })
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(deck, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(out_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
