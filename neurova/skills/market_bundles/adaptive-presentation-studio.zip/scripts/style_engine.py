#!/usr/bin/env python3
"""Reusable visual-style selection for Adaptive Presentation Studio.

The goal is not to force one master template. A style controls the visual identity
(palette, typography mood, chrome and layout tendencies) while each slide still
chooses a composition that fits its semantic role.
"""
from __future__ import annotations

import re
from typing import Any

STYLE_PRESETS: dict[str, dict[str, Any]] = {
    "dify-workflow-template": {
        "display_name": "Dify工作流课件风",
        "theme_name": "dify-workflow",
        "density": "breathable",
        "header_variant": "friendly",
        "footer_mode": "source-page",
        "decorative_mode": "dify-blue",
        "best_for": "AI 工作流、Dify 培训、自动化课程、数字化工具入门",
        "layout_bias": {
            "cover": ["image-panel", "geometric", "minimal"],
            "agenda": ["roadmap", "numbered"],
            "section": ["solid", "split-number"],
            "statement": ["split-accent", "centered", "insight-rail"],
            "content": ["sidebar", "two-column", "insight-rail", "editorial"],
            "cards": ["three-column", "quad-grid", "staggered"],
            "process": ["chevron", "horizontal", "vertical"],
            "timeline": ["horizontal", "milestones"],
            "comparison": ["balanced", "asymmetric"],
            "matrix": ["quadrant", "grid"],
            "chart": ["chart-hero", "chart-left", "chart-right", "chart-full"],
            "image_feature": ["top-image", "image-left", "image-right"],
            "closing": ["action-cards", "minimal-next"],
        },
    },
    "clean-professional": {
        "display_name": "清爽专业风",
        "theme_name": "modern-blue",
        "density": "balanced",
        "header_variant": "hairline",
        "footer_mode": "source-page",
        "decorative_mode": "quiet",
        "best_for": "工作汇报、项目复盘、管理层简报、技术分享",
        "layout_bias": {
            "cover": ["minimal", "split", "image-panel"],
            "agenda": ["roadmap", "numbered"],
            "statement": ["editorial", "insight-rail", "centered"],
            "content": ["editorial", "two-column", "sidebar", "insight-rail"],
            "cards": ["three-column", "quad-grid", "staggered"],
            "chart": ["chart-left", "chart-hero", "chart-right"],
            "closing": ["decision", "minimal-next", "action-cards"],
        },
    },
    "executive-consulting": {
        "display_name": "高管咨询风",
        "theme_name": "consulting-light",
        "density": "balanced",
        "header_variant": "consulting",
        "footer_mode": "source-page",
        "decorative_mode": "grid",
        "best_for": "战略方案、董事会汇报、咨询分析、经营决策",
        "layout_bias": {
            "cover": ["consulting", "minimal", "typographic"],
            "agenda": ["numbered", "roadmap"],
            "section": ["split-number", "solid"],
            "statement": ["insight-rail", "editorial", "poster"],
            "content": ["insight-rail", "two-column", "editorial"],
            "cards": ["stripe", "quad-grid", "three-column"],
            "process": ["horizontal", "vertical"],
            "comparison": ["asymmetric", "balanced"],
            "matrix": ["quadrant", "grid"],
            "chart": ["chart-hero", "chart-left", "chart-full"],
            "closing": ["decision", "minimal-next"],
        },
    },
    "editorial-magazine": {
        "display_name": "创意杂志风",
        "theme_name": "magazine-mono",
        "density": "contrast",
        "header_variant": "editorial",
        "footer_mode": "source-page",
        "decorative_mode": "editorial",
        "best_for": "品牌提案、创意展示、传播方案、作品集",
        "layout_bias": {
            "cover": ["editorial-cover", "typographic", "image-panel"],
            "agenda": ["roadmap", "numbered"],
            "section": ["solid", "split-number"],
            "statement": ["poster", "editorial", "split-accent"],
            "content": ["editorial", "insight-rail", "two-column"],
            "cards": ["staggered", "mosaic", "stripe"],
            "comparison": ["asymmetric", "versus"],
            "image_feature": ["top-image", "image-left", "image-right"],
            "image_grid": ["featured-grid", "gallery"],
            "closing": ["minimal-next", "decision"],
        },
    },
    "data-dashboard": {
        "display_name": "数据仪表盘风",
        "theme_name": "dashboard-light",
        "density": "dense-structured",
        "header_variant": "dashboard",
        "footer_mode": "source-page",
        "decorative_mode": "dashboard",
        "best_for": "经营分析、KPI复盘、运营数据、商业智能",
        "layout_bias": {
            "cover": ["dashboard-cover", "minimal", "split"],
            "agenda": ["numbered", "roadmap"],
            "statement": ["metric", "insight-rail", "centered"],
            "content": ["two-column", "sidebar", "insight-rail"],
            "cards": ["quad-grid", "stripe", "mosaic"],
            "chart": ["chart-hero", "chart-left", "chart-right", "chart-full"],
            "table": ["table-notes", "full"],
            "closing": ["decision", "action-cards"],
        },
    },
    "academic-research": {
        "display_name": "科研答辩风",
        "theme_name": "academic-blue",
        "density": "evidence-led",
        "header_variant": "hairline",
        "footer_mode": "source-page",
        "decorative_mode": "academic",
        "best_for": "论文答辩、研究汇报、课题评审、实验结果",
        "layout_bias": {
            "cover": ["consulting", "minimal", "image-panel"],
            "statement": ["editorial", "centered"],
            "content": ["two-column", "editorial", "sidebar"],
            "process": ["horizontal", "vertical"],
            "timeline": ["milestones", "vertical"],
            "chart": ["chart-full", "chart-left", "chart-hero"],
            "image_feature": ["top-image", "image-left"],
            "closing": ["minimal-next", "decision"],
        },
    },
    "training-friendly": {
        "display_name": "教学课件风",
        "theme_name": "teaching-warm",
        "density": "breathable",
        "header_variant": "friendly",
        "footer_mode": "source-page",
        "decorative_mode": "friendly",
        "best_for": "培训课件、制度宣导、知识科普、课程讲解",
        "layout_bias": {
            "cover": ["geometric", "minimal", "split"],
            "agenda": ["roadmap", "numbered"],
            "statement": ["centered", "split-accent"],
            "content": ["sidebar", "two-column", "editorial"],
            "cards": ["three-column", "quad-grid", "staggered"],
            "process": ["chevron", "horizontal", "vertical"],
            "timeline": ["horizontal", "milestones"],
            "closing": ["action-cards", "minimal-next"],
        },
    },
    "brand-pop": {
        "display_name": "品牌活力风",
        "theme_name": "brand-pop",
        "density": "visual-first",
        "header_variant": "editorial",
        "footer_mode": "source-page",
        "decorative_mode": "pop",
        "best_for": "营销策划、品牌发布、新品提案、活动创意",
        "layout_bias": {
            "cover": ["typographic", "editorial-cover", "geometric"],
            "statement": ["poster", "split-accent", "editorial"],
            "content": ["insight-rail", "editorial", "two-column"],
            "cards": ["staggered", "mosaic", "three-column"],
            "comparison": ["versus", "asymmetric"],
            "image_feature": ["top-image", "image-left", "image-right"],
            "image_grid": ["featured-grid", "gallery"],
            "closing": ["decision", "minimal-next"],
        },
    },
    "minimal-keynote": {
        "display_name": "极简发布会风",
        "theme_name": "minimal-stone",
        "density": "sparse",
        "header_variant": "minimal",
        "footer_mode": "source-page",
        "decorative_mode": "minimal",
        "best_for": "发布会、产品介绍、领导演讲、极简观点表达",
        "layout_bias": {
            "cover": ["typographic", "minimal", "image-panel"],
            "agenda": ["roadmap", "numbered"],
            "section": ["solid", "split-number"],
            "statement": ["centered", "poster", "editorial"],
            "content": ["editorial", "insight-rail", "two-column"],
            "cards": ["duo", "three-column", "stripe"],
            "chart": ["chart-full", "chart-hero"],
            "closing": ["minimal-next", "decision"],
        },
    },
    "dark-tech": {
        "display_name": "深色科技风",
        "theme_name": "dark-tech",
        "density": "balanced",
        "header_variant": "dark",
        "footer_mode": "source-page",
        "decorative_mode": "tech",
        "best_for": "AI、互联网、技术架构、数字化、科技发布",
        "layout_bias": {
            "cover": ["dark-hero", "typographic", "split"],
            "statement": ["poster", "centered", "split-accent"],
            "content": ["sidebar", "two-column", "insight-rail"],
            "cards": ["stripe", "quad-grid", "mosaic"],
            "process": ["horizontal", "chevron"],
            "chart": ["chart-hero", "chart-left", "chart-full"],
            "closing": ["decision", "minimal-next"],
        },
    },
    "warm-storytelling": {
        "display_name": "温暖叙事风",
        "theme_name": "warm-neutral",
        "density": "breathable",
        "header_variant": "friendly",
        "footer_mode": "source-page",
        "decorative_mode": "warm",
        "best_for": "文化、公益、酒店、生活方式、人物与故事型汇报",
        "layout_bias": {
            "cover": ["image-panel", "minimal", "geometric"],
            "statement": ["centered", "editorial"],
            "content": ["editorial", "sidebar", "two-column"],
            "cards": ["staggered", "three-column", "duo"],
            "image_feature": ["top-image", "image-left", "image-right"],
            "closing": ["minimal-next", "action-cards"],
        },
    },
    "premium-luxury": {
        "display_name": "高级质感风",
        "theme_name": "luxury-ink",
        "density": "sparse",
        "header_variant": "minimal",
        "footer_mode": "source-page",
        "decorative_mode": "luxury",
        "best_for": "高端品牌、酒店、地产、精品发布、商务提案",
        "layout_bias": {
            "cover": ["typographic", "editorial-cover", "minimal"],
            "statement": ["editorial", "poster", "centered"],
            "content": ["editorial", "insight-rail", "two-column"],
            "cards": ["stripe", "duo", "staggered"],
            "image_feature": ["top-image", "image-left"],
            "closing": ["minimal-next", "decision"],
        },
    },
    "china-red": {
        "display_name": "庄重红色风",
        "theme_name": "china-red",
        "density": "balanced",
        "header_variant": "band",
        "footer_mode": "source-page",
        "decorative_mode": "formal-red",
        "best_for": "正式宣导、庆典总结、组织汇报、红色主题",
        "layout_bias": {
            "cover": ["split", "typographic", "minimal"],
            "agenda": ["numbered", "roadmap"],
            "statement": ["split-accent", "editorial"],
            "content": ["two-column", "sidebar", "editorial"],
            "cards": ["three-column", "quad-grid", "stripe"],
            "closing": ["decision", "action-cards"],
        },
    },
}

ALIASES = {
    "dify": "dify-workflow-template", "工作流课件": "dify-workflow-template", "dify工作流": "dify-workflow-template",
    "清爽专业": "clean-professional", "专业": "clean-professional", "商务": "clean-professional",
    "麦肯锡": "executive-consulting", "咨询": "executive-consulting", "高管": "executive-consulting", "咨询风": "executive-consulting",
    "创意杂志": "editorial-magazine", "杂志": "editorial-magazine", "editorial": "editorial-magazine",
    "数据仪表盘": "data-dashboard", "仪表盘": "data-dashboard", "dashboard": "data-dashboard", "bi": "data-dashboard",
    "科研答辩": "academic-research", "学术": "academic-research", "答辩": "academic-research", "research": "academic-research",
    "教学课件": "training-friendly", "培训": "training-friendly", "课件": "training-friendly",
    "品牌活力": "brand-pop", "品牌": "brand-pop", "营销": "brand-pop", "年轻": "brand-pop", "活泼": "brand-pop",
    "极简": "minimal-keynote", "发布会": "minimal-keynote", "keynote": "minimal-keynote",
    "深色科技": "dark-tech", "科技": "dark-tech", "深色": "dark-tech", "ai": "dark-tech", "tech": "dark-tech",
    "温暖": "warm-storytelling", "叙事": "warm-storytelling", "人文": "warm-storytelling",
    "高级": "premium-luxury", "高端": "premium-luxury", "奢华": "premium-luxury", "质感": "premium-luxury",
    "红色": "china-red", "庄重": "china-red", "党政": "china-red",
}


def normalize_style(requested: str) -> str | None:
    raw = str(requested or "").strip()
    if not raw or raw.lower() == "auto":
        return None
    key = raw.lower().replace("_", "-")
    if key in STYLE_PRESETS:
        return key
    for alias, style_id in sorted(ALIASES.items(), key=lambda x: -len(x[0])):
        if alias.lower() in key:
            return style_id
    return None


def choose_style(requested: str, *, mode: str, audience: str = "", purpose: str = "", title: str = "", text: str = "") -> str:
    explicit = normalize_style(requested)
    if explicit:
        return explicit
    context = " ".join([str(requested or ""), title, audience, purpose, text[:12000]]).lower()
    if re.search(r"党政|红色主题|庄重|庆典|党建", context):
        return "china-red"
    if re.search(r"暗黑|深色|科技|ai|人工智能|数字化|架构|算法|互联网|saas", context):
        return "dark-tech"
    if re.search(r"高端|高级感|精品|奢华|酒店|地产|珠宝|时尚", context):
        return "premium-luxury"
    if re.search(r"极简|发布会|keynote|一页一观点|大字", context):
        return "minimal-keynote"
    if mode == "data" or re.search(r"kpi|看板|仪表盘|经营数据|指标体系|数据分析", context):
        return "data-dashboard"
    if mode == "research" or re.search(r"论文|课题|答辩|实验|研究方法", context):
        return "academic-research"
    if mode == "training" or re.search(r"培训|课程|教学|课件|宣导", context):
        return "training-friendly"
    if mode == "product" or re.search(r"品牌|营销|活动|新品|传播|创意|社交媒体", context):
        return "brand-pop" if re.search(r"年轻|活泼|潮流|社交|新品|营销|品牌", context) else "editorial-magazine"
    if mode == "proposal" or re.search(r"董事会|管理层|决策|战略|咨询|经营", context):
        return "executive-consulting"
    if re.search(r"温暖|故事|人文|公益|文化|生活方式", context):
        return "warm-storytelling"
    return "clean-professional"


def style_profile(style_id: str) -> dict[str, Any]:
    return dict(STYLE_PRESETS.get(style_id, STYLE_PRESETS["clean-professional"]))


def style_choices_summary() -> list[dict[str, str]]:
    return [
        {"id": sid, "name": cfg["display_name"], "best_for": cfg["best_for"]}
        for sid, cfg in STYLE_PRESETS.items()
    ]
