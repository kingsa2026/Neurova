#!/usr/bin/env python3
"""On-brand visual fillers for Adaptive Presentation Studio.

These guarantee that every reserved visual zone is filled even when no
generated photograph is available. They are vector "scene" panels drawn in the
active theme's blue identity, with a contextual motif (energy / data / process /
compare) and a caption pill. They are the fallback that prevents blank space;
real generated images always take priority when present.
"""
from __future__ import annotations

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

WHITE = "FFFFFF"


def _rgb(value: str) -> RGBColor:
    v = value.strip().lstrip("#")
    return RGBColor(int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))


def _rect(slide, shape_type, x, y, w, h, fill, line, line_w=0.75, radius=None):
    shp = slide.shapes.add_shape(shape_type, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill:
        shp.fill.solid()
        shp.fill.fore_color.rgb = _rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = _rgb(line)
        shp.line.width = Pt(line_w)
    else:
        shp.line.fill.background()
    if radius is not None and shape_type == MSO_SHAPE.ROUNDED_RECTANGLE:
        try:
            shp.adjustments[0] = radius
        except Exception:
            pass
    return shp


def _text(slide, text, x, y, w, h, size, color, bold=False, align=PP_ALIGN.CENTER,
          valign=MSO_ANCHOR.MIDDLE, font="Microsoft YaHei"):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = valign
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = str(text)
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = _rgb(color)
    return box


def _motif_energy(slide, cx, cy, s, accent, white, primary=None):
    # Sun + rays inside a unit box around (cx,cy) with characteristic size s.
    _rect(slide, MSO_SHAPE.OVAL, cx - s * 0.28, cy - s * 0.30, s * 0.56, s * 0.56, accent, None)
    for k in range(8):
        ang = k * 45
        ray = _rect(slide, MSO_SHAPE.RECTANGLE, cx - s * 0.015, cy - s * 0.62, s * 0.03, s * 0.22, accent, None)
        ray.rotation = ang
    # ground bar
    _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, cx - s * 0.5, cy + s * 0.30, s, s * 0.10, white, None, radius=0.5)


def _motif_data(slide, cx, cy, s, accent, white, primary):
    heights = [0.42, 0.68, 0.52, 0.82, 0.60]
    n = len(heights)
    gap = s * 0.06
    bw = (s - gap * (n - 1)) / n
    base_y = cy + s * 0.42
    for i, hf in enumerate(heights):
        x = cx - s / 2 + i * (bw + gap)
        bh = s * 0.84 * hf
        col = white if i % 2 == 0 else accent
        _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, base_y - bh, bw, bh, col, None, radius=0.45)
    _rect(slide, MSO_SHAPE.RECTANGLE, cx - s / 2, base_y, s, s * 0.018, white, None)


def _motif_process(slide, cx, cy, s, accent, white, primary):
    n = 3
    r = s * 0.16
    gap = (s - r * 2 * n) / (n - 1)
    nodes = []
    for i in range(n):
        x = cx - s / 2 + r + i * (2 * r + gap)
        _rect(slide, MSO_SHAPE.OVAL, x - r, cy - r, 2 * r, 2 * r, white if i == 1 else accent, None)
        nodes.append(x)
    for i in range(n - 1):
        x = nodes[i] + r
        ln = _rect(slide, MSO_SHAPE.RECTANGLE, x, cy - s * 0.012, gap, s * 0.024, white, None)
    # chevrons between
    for i in range(n - 1):
        x = nodes[i] + r + gap / 2 - s * 0.05
        _rect(slide, MSO_SHAPE.CHEVRON, x, cy - s * 0.06, s * 0.10, s * 0.12, accent, None)


def _motif_compare(slide, cx, cy, s, accent, white, primary):
    h = s * 0.7
    w = s * 0.34
    _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, cx - s / 2, cy - h / 2, w, h, white, None, radius=0.12)
    _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, cx + s / 2 - w, cy - h / 2, w, h, accent, None, radius=0.12)
    # divider arrow
    _rect(slide, MSO_SHAPE.CHEVRON, cx - s * 0.07, cy - s * 0.07, s * 0.14, s * 0.14, white, None)


def _motif_nodes(slide, cx, cy, s, accent, white, primary):
    pts = [(0.0, 0.0), (0.7, 0.2), (0.3, 0.7), (1.0, 0.55), (0.6, 1.0)]
    cxs = [cx - s / 2 + px * s for px, py in pts]
    cys = [cy - s / 2 + py * s for px, py in pts]
    for i in range(len(pts) - 1):
        x0, y0 = cxs[i], cys[i]
        x1, y1 = cxs[i + 1], cys[i + 1]
        mx, my = (x0 + x1) / 2, (y0 + y1) / 2
        ln = _rect(slide, MSO_SHAPE.RECTANGLE, min(x0, x1), min(y0, y1), abs(x1 - x0) + 0.001, abs(y1 - y0) + 0.001, accent, None)
        ln.rotation = (i * 40)
    for i, (x, y) in enumerate(zip(cxs, cys)):
        _rect(slide, MSO_SHAPE.OVAL, x - s * 0.07, y - s * 0.07, s * 0.14, s * 0.14, white if i % 2 else accent, None)


def _pick_motif(keyword: str):
    kw = str(keyword or "").lower()
    if any(t in kw for t in ("energy", "能源", "工厂", "产线", "运营", "工业", "electric", "power", "water", "水")):
        return _motif_energy
    if any(t in kw for t in ("data", "数据", "指标", "chart", "图表", "kpi", "趋势", "对比", "compare")):
        return _motif_data
    if any(t in kw for t in ("process", "流程", "workflow", "步骤", "阶段", "时间", "timeline", "roadmap")):
        return _motif_process
    if any(t in kw for t in ("compare", "对比", "方案", "建议", "action", "行动")):
        return _motif_compare
    return _motif_nodes


def draw_filler(slide, x, y, w, h, theme, keyword="", caption="", font_name="Microsoft YaHei", radius=0.05):
    """Fill a visual zone with an on-brand blue scene panel (no blank space)."""
    primary = theme.get("primary", "0040C0")
    accent = theme.get("accent", "4D8CFF")
    # Base panel
    _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, primary, primary, radius=radius)
    # Depth accent oval (bottom-right, partially off-panel)
    ov = _rect(slide, MSO_SHAPE.OVAL, x + w * 0.42, y + h * 0.50, w * 0.95, h * 0.95, accent, None)
    ov.line.fill.background()
    # Faint dot grid (top-left cluster)
    for r in range(3):
        for c in range(4):
            dx = x + w * 0.06 + c * w * 0.07
            dy = y + h * 0.10 + r * h * 0.07
            _rect(slide, MSO_SHAPE.OVAL, dx, dy, w * 0.012, w * 0.012, WHITE, None)
    # Motif centered in upper-middle
    motif = _pick_motif(keyword)
    ms = min(w, h) * 0.62
    motif(slide, x + w * 0.5, y + h * 0.42, ms, accent, WHITE, primary)
    # Caption pill (bottom)
    if caption:
        pw = min(w * 0.9, 0.30 + 0.045 * len(caption))
        px = x + (w - pw) / 2
        py = y + h - h * 0.16
        _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, px, py, pw, h * 0.11, accent, None, radius=0.5)
        _text(slide, caption, px, py, pw, h * 0.11, max(9, min(13, int(150 / max(1, len(caption))))),
              WHITE, True, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE, font_name)
    return slide
