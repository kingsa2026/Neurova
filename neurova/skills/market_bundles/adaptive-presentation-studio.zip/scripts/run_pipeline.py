#!/usr/bin/env python3
"""Run the full materials-to-PPT pipeline with resume, retry and auto-repair."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from diagnostics import make_diagnostic, plain_summary

STAGE_LABELS = {
    "analysis": "读取和理解资料",
    "template_style": "提取参考 PPT 风格",
    "planning": "规划内容结构",
    "visual_planning": "规划并绑定配图",
    "content_review": "检查标题、来源和逻辑",
    "render": "生成可编辑 PPT",
    "validation": "检查版式和可读性",
    "template_match": "评估模板还原度",
}


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def inputs_fingerprint(paths: list[str], options: dict[str, Any]) -> str:
    records: list[dict[str, Any]] = []
    for raw in paths:
        p = Path(raw).expanduser().resolve()
        if p.is_dir():
            for child in sorted(x for x in p.rglob("*") if x.is_file()):
                stat = child.stat()
                records.append({"path": str(child), "size": stat.st_size, "mtime": stat.st_mtime_ns, "sha256": file_hash(child)})
        elif p.exists():
            stat = p.stat()
            records.append({"path": str(p), "size": stat.st_size, "mtime": stat.st_mtime_ns, "sha256": file_hash(p)})
        else:
            records.append({"path": str(p), "missing": True})
    payload = json.dumps({"files": records, "options": options}, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def output_ok(paths: list[Path]) -> bool:
    return all(p.exists() and p.is_file() and p.stat().st_size > 0 for p in paths)


def run_command(command: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )


def run_stage(name: str, command: list[str], timeout: int, retries: int = 1) -> dict[str, Any]:
    started = time.time()
    attempts: list[dict[str, Any]] = []
    for attempt in range(1, retries + 2):
        try:
            completed = run_command(command, timeout)
            attempts.append({
                "attempt": attempt,
                "return_code": completed.returncode,
                "stdout": completed.stdout.strip()[-4000:],
                "stderr": completed.stderr.strip()[-4000:],
            })
            if completed.returncode == 0:
                return {
                    "name": name,
                    "label": STAGE_LABELS[name],
                    "command": command,
                    "status": "pass",
                    "attempts": attempts,
                    "duration_seconds": round(time.time() - started, 2),
                }
            if attempt <= retries:
                print(f"  第 {attempt} 次未完成，正在自动重试……", flush=True)
                time.sleep(min(attempt, 2))
        except subprocess.TimeoutExpired as exc:
            attempts.append({
                "attempt": attempt,
                "return_code": None,
                "stdout": (exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "",
                "stderr": (exc.stderr or "")[-4000:] if isinstance(exc.stderr, str) else "",
                "timeout": timeout,
            })
            if attempt <= retries:
                print(f"  处理时间较长，正在从当前阶段重试……", flush=True)
                continue
            diag = make_diagnostic("PIPELINE_TIMEOUT", name, f"阶段超过 {timeout} 秒。", details={"timeout_seconds": timeout})
            return {
                "name": name, "label": STAGE_LABELS[name], "command": command, "status": "fail",
                "attempts": attempts, "duration_seconds": round(time.time() - started, 2), "diagnostic": diag,
            }

    last = attempts[-1] if attempts else {}
    code = "OUTPUT_VALIDATION_FAILED" if name in {"content_review", "validation"} else "RENDER_FAILED" if name == "render" else "INPUT_PARSE_FAILED"
    detail = last.get("stderr") or last.get("stdout") or f"阶段 {name} 未完成。"
    diag = make_diagnostic(code, name, str(detail), details={"return_code": last.get("return_code")})
    return {
        "name": name,
        "label": STAGE_LABELS[name],
        "command": command,
        "status": "fail",
        "attempts": attempts,
        "duration_seconds": round(time.time() - started, 2),
        "diagnostic": diag,
    }


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        return {}


def write_user_summary(
    path: Path,
    *,
    final_status: str,
    failed_stage: str | None,
    stages: list[dict[str, Any]],
    outputs: dict[str, str],
    analysis: dict[str, Any],
    review: dict[str, Any],
    validation: dict[str, Any],
    render_report: dict[str, Any],
    visual_plan: dict[str, Any],
    recovery: list[dict[str, Any]],
) -> None:
    lines = ["# PPT 生成运行摘要", "", f"- 运行结果：**{'已完成' if final_status == 'pass' else '未完成'}**", f"- 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"]
    if failed_stage:
        lines.append(f"- 停止阶段：{STAGE_LABELS.get(failed_stage, failed_stage)}")
    lines += ["", "## 处理进度"]
    for s in stages:
        label = s.get("label") or STAGE_LABELS.get(s.get("name"), s.get("name"))
        status = {"pass": "完成", "fail": "失败", "skipped": "已复用上次结果"}.get(s.get("status"), s.get("status"))
        lines.append(f"- {label}：{status}")
    if recovery:
        lines += ["", "## 自动恢复"]
        for item in recovery:
            lines.append(f"- {item.get('message', item.get('action', '已执行恢复操作'))}")

    if final_status == "pass":
        lines += ["", "## 生成文件"]
        for name, value in outputs.items():
            if Path(value).exists():
                lines.append(f"- {name}：`{value}`")
    else:
        failed = next((x for x in stages if x.get("status") == "fail"), {})
        diag = failed.get("diagnostic") or {}
        lines += ["", "## 现在怎么处理", "", f"**{diag.get('user_title', '任务未完成')}**", "", diag.get("user_message", diag.get("message", ""))]
        for idx, step in enumerate((diag.get("steps") or [])[:4], 1):
            lines.append(f"{idx}. {step}")
        lines.append("\n修复后直接重新运行即可，默认会从已完成的阶段继续，不必从头开始。")

    diagnostics = analysis.get("diagnostics") or []
    if diagnostics:
        lines += ["", "## 资料注意事项"]
        for d in diagnostics[:8]:
            lines.append(f"- **{d.get('user_title', d.get('code'))}**：{d.get('user_message', d.get('message', ''))}")
    fallback_count = int(render_report.get("fallback_slide_count", 0) or 0)
    if fallback_count:
        lines += ["", "## 兼容恢复页面", f"- 有 {fallback_count} 页因原版式异常改用了兼容文字页。", "- 请根据 render_report.json 中的页码重新上传图片或精简内容。"]
    planned_visuals = int(visual_plan.get("planned_count", 0) or 0)
    if planned_visuals:
        applied_visuals = int(visual_plan.get("applied_count", 0) or 0)
        pending_visuals = int(visual_plan.get("pending_count", 0) or 0)
        lines += ["", "## 自动配图", f"- 已规划：{planned_visuals} 张", f"- 已绑定：{applied_visuals} 张", f"- 待生成：{pending_visuals} 张"]
        if pending_visuals:
            lines.append("- 请按 image_plan.json 中的 expected_filename 生成图片，再使用 --visual-assets-dir 重新运行。")
    review_issues = review.get("issues") or []
    validation_issues = validation.get("issues") or []
    if review_issues or validation_issues:
        lines += ["", "## 正式使用前建议核对"]
        for item in (review_issues + validation_issues)[:10]:
            slide = item.get("slide")
            prefix = f"第 {slide} 页：" if slide else ""
            lines.append(f"- {prefix}{item.get('message') or item.get('type') or item.get('code')}")
    lines += ["", "## 必须人工确认", "- 标题和结论是否符合真实业务语境。", "- 数字、单位、时间范围和来源是否与原始资料一致。", "- 扫描 PDF、旧版 Excel、超长资料或读取状态为 partial 的内容是否补充核对。"]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="一键生成、检查并自动恢复 PPT")
    parser.add_argument("--inputs", nargs="+", required=True, help="资料文件或文件夹")
    parser.add_argument("--outdir", required=True, help="输出目录")
    parser.add_argument("--title", default="智能演示文稿")
    parser.add_argument("--subtitle", default="")
    parser.add_argument("--author", default="")
    parser.add_argument("--audience", default="", help="演示对象，如管理层、客户、员工")
    parser.add_argument("--purpose", default="", help="演示目的，如汇报决策、培训、提案")
    parser.add_argument("--target-pages", type=int, default=0, help="期望页数，0 表示自动")
    parser.add_argument("--presentation-minutes", type=int, default=0, help="预计讲述分钟数")
    parser.add_argument("--mode", default="auto", choices=["auto", "report", "proposal", "project", "training", "product", "research", "data"])
    parser.add_argument("--theme", default="auto")
    parser.add_argument("--style", default="auto", help="视觉风格；auto 为智能匹配")
    parser.add_argument("--template-pptx", default="", help="参考 PPT 模板；自动提取背景、字体、颜色、布局和图片风格")
    parser.add_argument("--template-style", default="", help="已提取好的 template_style.json")
    parser.add_argument("--visual-mode", default="auto", choices=["off", "plan", "auto", "assets"], help="配图模式：off 关闭，plan 仅规划，auto 自动规划并绑定已有图片，assets 使用指定图片目录")
    parser.add_argument("--visual-assets-dir", default="", help="imagegen 或其他图片生成工具输出目录")
    parser.add_argument("--max-visuals", type=int, default=12, help="单份 PPT 最多规划的生成配图数量")
    parser.add_argument("--filename", default="演示文稿.pptx")
    parser.add_argument("--max-file-mb", type=int, default=150)
    parser.add_argument("--max-rows", type=int, default=200000)
    parser.add_argument("--retries", type=int, default=2, help="每阶段自动重试次数")
    parser.add_argument("--no-resume", action="store_true", help="不复用上次已完成阶段")
    parser.add_argument("--no-auto-repair", action="store_true", help="关闭兼容布局自动修复")
    parser.add_argument("--continue-on-review", action="store_true")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    outdir = Path(args.outdir).expanduser().resolve()
    analysis_dir = outdir / "analysis"
    analysis_json = analysis_dir / "analysis.json"
    template_style_dir = outdir / "template_style"
    template_style_json = template_style_dir / "template_style.json"
    effective_template_style = args.template_style or (str(template_style_json) if args.template_pptx else "")
    spec_json = outdir / "deck_spec.json"
    visual_plan_json = outdir / "image_plan.json"
    visual_assets_dir = Path(args.visual_assets_dir).expanduser().resolve() if args.visual_assets_dir else outdir / "visual_assets"
    content_review = outdir / "content_review.json"
    pptx_path = outdir / args.filename
    validation_json = outdir / "validation.json"
    template_match_json = outdir / "template_match_report.json"
    render_report_json = pptx_path.with_suffix(".render_report.json")
    report_path = outdir / "pipeline_report.json"
    user_summary = outdir / "运行摘要.md"
    state_path = outdir / ".pipeline_state.json"
    outdir.mkdir(parents=True, exist_ok=True)

    options = {
        "title": args.title, "subtitle": args.subtitle, "author": args.author,
        "audience": args.audience, "purpose": args.purpose, "target_pages": args.target_pages,
        "presentation_minutes": args.presentation_minutes, "mode": args.mode, "theme": args.theme, "style": args.style,
        "template_pptx": args.template_pptx, "template_style": args.template_style,
        "visual_mode": args.visual_mode, "visual_assets_dir": str(visual_assets_dir), "max_visuals": args.max_visuals,
        "max_file_mb": args.max_file_mb, "max_rows": args.max_rows,
    }
    fingerprint_paths = list(args.inputs)
    if args.template_pptx:
        fingerprint_paths.append(args.template_pptx)
    if args.template_style:
        fingerprint_paths.append(args.template_style)
    if args.visual_mode in {"auto", "assets"} and visual_assets_dir.exists():
        fingerprint_paths.append(str(visual_assets_dir))
    fingerprint = inputs_fingerprint(fingerprint_paths, options)
    old_state = load_json(state_path)
    resume_enabled = not args.no_resume and old_state.get("fingerprint") == fingerprint

    commands = {
        "analysis": [sys.executable, str(script_dir / "analyze_materials.py"), "--inputs", *args.inputs, "--outdir", str(analysis_dir), "--max-file-mb", str(args.max_file_mb), "--max-rows", str(args.max_rows)],
        "template_style": [sys.executable, str(script_dir / "template_style.py"), "--pptx", args.template_pptx, "--outdir", str(template_style_dir), "--output", str(template_style_json)],
        "planning": [sys.executable, str(script_dir / "draft_spec.py"), "--analysis", str(analysis_json), "--output", str(spec_json), "--title", args.title, "--subtitle", args.subtitle, "--author", args.author, "--mode", args.mode, "--theme", args.theme, "--style", args.style, "--template-style", effective_template_style, "--audience", args.audience, "--purpose", args.purpose, "--target-pages", str(args.target_pages), "--presentation-minutes", str(args.presentation_minutes)],
        "visual_planning": [sys.executable, str(script_dir / "visual_planner.py"), "--spec", str(spec_json), "--analysis", str(analysis_json), "--output", str(visual_plan_json), "--output-spec", str(spec_json), "--assets-dir", str(visual_assets_dir), "--mode", args.visual_mode, "--max-images", str(args.max_visuals)],
        "content_review": [sys.executable, str(script_dir / "review_content.py"), "--spec", str(spec_json), "--analysis", str(analysis_json), "--report", str(content_review)],
        "render": [sys.executable, str(script_dir / "build_deck.py"), "--spec", str(spec_json), "--output", str(pptx_path)],
        "validation": [sys.executable, str(script_dir / "validate_deck.py"), "--pptx", str(pptx_path), "--spec", str(spec_json), "--analysis", str(analysis_json), "--content-review", str(content_review), "--visual-plan", str(visual_plan_json), "--report", str(validation_json)],
        "template_match": [sys.executable, str(script_dir / "template_match_report.py"), "--pptx", str(pptx_path), "--spec", str(spec_json), "--template-style", effective_template_style, "--report", str(template_match_json)],
    }
    timeouts = {"analysis": 360, "template_style": 180, "planning": 180, "visual_planning": 180, "content_review": 180, "render": 240, "validation": 240, "template_match": 180}
    expected = {
        "analysis": [analysis_json], "template_style": [template_style_json], "planning": [spec_json], "visual_planning": [visual_plan_json, spec_json], "content_review": [content_review],
        "render": [pptx_path, render_report_json], "validation": [validation_json], "template_match": [template_match_json],
    }

    print("开始生成演示文稿。遇到异常时会自动重试，并保留已完成结果。", flush=True)
    stages: list[dict[str, Any]] = []
    recovery: list[dict[str, Any]] = []
    state = {"fingerprint": fingerprint, "updated_at": datetime.now().isoformat(timespec="seconds"), "stages": {}}

    stage_order = ["analysis"]
    if args.template_pptx:
        stage_order.append("template_style")
    stage_order += ["planning", "visual_planning", "content_review", "render", "validation"]
    if effective_template_style:
        stage_order.append("template_match")

    for name in stage_order:
        print(f"[{len(stages)+1}/{len(stage_order)}] {STAGE_LABELS[name]}……", flush=True)
        can_skip = resume_enabled and old_state.get("stages", {}).get(name, {}).get("status") == "pass" and output_ok(expected[name])
        if can_skip:
            stage = {"name": name, "label": STAGE_LABELS[name], "status": "skipped", "duration_seconds": 0, "resume": True}
            print("  已复用上次完成结果。", flush=True)
        else:
            stage = run_stage(name, commands[name], timeouts[name], retries=max(0, args.retries))
            if stage["status"] == "pass" and not output_ok(expected[name]):
                stage["status"] = "fail"
                stage["diagnostic"] = make_diagnostic("INPUT_PARSE_FAILED", name, "阶段返回成功，但没有生成预期文件。", details={"expected": [str(x) for x in expected[name]]})

        # Render fallback: sanitize the spec and retry with compatible layouts.
        if stage["status"] == "fail" and name == "render" and not args.no_auto_repair and spec_json.exists():
            print("  正在切换到兼容布局并自动修复……", flush=True)
            repair = run_command([sys.executable, str(script_dir / "repair_spec.py"), "--spec", str(spec_json)], 120)
            recovery.append({"action": "render_repair", "status": repair.returncode, "message": "渲染失败后已切换到兼容布局并重试。"})
            if repair.returncode == 0:
                stage = run_stage(name, commands[name], timeouts[name], retries=1)

        # Validation fallback: repair problem slides, rerender and validate once.
        if stage["status"] == "fail" and name == "validation" and not args.no_auto_repair and spec_json.exists() and validation_json.exists():
            print("  正在根据问题页码自动精简并重新生成……", flush=True)
            repair = run_command([sys.executable, str(script_dir / "repair_spec.py"), "--spec", str(spec_json), "--validation", str(validation_json), "--aggressive"], 120)
            recovery.append({"action": "validation_repair", "status": repair.returncode, "message": "质量检查未通过后已自动精简问题页面并重新验证。"})
            if repair.returncode == 0:
                render_retry = run_stage("render", commands["render"], timeouts["render"], retries=1)
                recovery.append({"action": "rerender", "status": render_retry["status"], "message": "自动修复后已重新渲染 PPT。"})
                if render_retry["status"] == "pass":
                    stage = run_stage(name, commands[name], timeouts[name], retries=1)

        stages.append(stage)
        state["stages"][name] = {"status": "pass" if stage["status"] in {"pass", "skipped"} else "fail", "updated_at": datetime.now().isoformat(timespec="seconds")}
        state["updated_at"] = datetime.now().isoformat(timespec="seconds")
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

        if stage["status"] in {"pass", "skipped"}:
            print("  完成。", flush=True)
            continue
        print("  未完成。", flush=True)
        print(plain_summary(stage.get("diagnostic") or {}), file=sys.stderr, flush=True)
        if name == "content_review" and args.continue_on_review:
            continue
        break

    completed_names = {s["name"] for s in stages if s["status"] in {"pass", "skipped"}}
    final_status = "pass" if set(stage_order).issubset(completed_names) else "fail"
    failed_stage = next((s["name"] for s in stages if s["status"] == "fail"), None)
    outputs = {
        "资料分析": str(analysis_json), "模板风格": str(effective_template_style) if effective_template_style else "",
        "模板还原度": str(template_match_json) if effective_template_style else "",
        "配图规划": str(visual_plan_json), "配图素材目录": str(visual_assets_dir),
        "页面规划": str(spec_json), "内容审校": str(content_review),
        "PowerPoint": str(pptx_path), "渲染恢复记录": str(render_report_json), "版式验证": str(validation_json), "运行摘要": str(user_summary),
    }
    report = {
        "status": final_status,
        "failed_stage": failed_stage,
        "resume_enabled": resume_enabled,
        "fingerprint": fingerprint,
        "stages": stages,
        "recovery": recovery,
        "outputs": outputs,
        "user_summary": str(user_summary),
        "next_actions": [
            "无需查看技术日志，优先打开运行摘要.md。",
            "修复资料后直接重新运行，默认从已完成阶段继续。",
            "正式发布前核对标题、数字、单位、来源和扫描页。",
        ],
    }
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    write_user_summary(
        user_summary,
        final_status=final_status,
        failed_stage=failed_stage,
        stages=stages,
        outputs=outputs,
        analysis=load_json(analysis_json),
        review=load_json(content_review),
        validation=load_json(validation_json),
        render_report=load_json(render_report_json),
        visual_plan=load_json(visual_plan_json),
        recovery=recovery,
    )

    if final_status == "pass":
        print("PPT 已生成并通过检查。", flush=True)
        print(str(pptx_path), flush=True)
        print(f"使用说明：{user_summary}", flush=True)
        return 0
    print(f"处理建议已写入：{user_summary}", file=sys.stderr, flush=True)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
