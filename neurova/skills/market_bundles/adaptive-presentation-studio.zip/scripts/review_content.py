#!/usr/bin/env python3
"""Audit deck content quality, source traceability and narrative completeness."""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

WEAK_TITLES = {
    "背景", "项目背景", "现状", "问题", "核心内容", "主要内容", "数据分析", "分析结果",
    "总结", "关键发现", "核心观点", "内容导航", "下一步", "下一步行动", "方案", "介绍",
    "background", "overview", "analysis", "summary", "next steps", "findings",
}
DATA_TYPES = {"chart", "table", "kpi"}
NUMERIC_RE = re.compile(r"(?<![A-Za-z])(?:\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:%|万|亿|元|人|次|件|家|天|月|年)?")
PLACEHOLDER_RE = re.compile(r"待确认|待补充|TBD|TODO|示例文字|占位", re.I)


def clean(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def slide_text(slide: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in ("title", "subtitle", "key_message", "body", "source", "footer"):
        if slide.get(key):
            parts.append(clean(slide[key]))
    for key in ("bullets", "insights", "captions"):
        for item in slide.get(key) or []:
            parts.append(clean(item))
    for item in slide.get("items") or []:
        if isinstance(item, dict):
            parts.extend(clean(item.get(k)) for k in ("title", "body", "value", "time", "owner", "timing") if item.get(k))
        else:
            parts.append(clean(item))
    for side in ("left", "right"):
        block = slide.get(side) or {}
        if isinstance(block, dict):
            parts.append(clean(block.get("title")))
            parts.extend(clean(x) for x in block.get("items") or [])
    return " ".join(x for x in parts if x)


def issue(code: str, severity: str, slide: int | None, message: str, suggestion: str, **details: Any) -> dict[str, Any]:
    result = {"code": code, "severity": severity, "slide": slide, "message": message, "suggestion": suggestion}
    if details:
        result["details"] = details
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Review deck_spec content quality and traceability")
    parser.add_argument("--spec", required=True)
    parser.add_argument("--analysis", default="")
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    spec_path = Path(args.spec).expanduser().resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    slides = spec.get("slides") or []
    issues: list[dict[str, Any]] = []
    title_counter: Counter[str] = Counter()
    message_counter: Counter[str] = Counter()
    data_slides = 0
    sourced_data_slides = 0
    placeholder_slides = 0
    chart_slides = 0
    table_slides = 0
    card_slides = 0

    for idx, slide in enumerate(slides, 1):
        stype = clean(slide.get("type") or "content").lower()
        title = clean(slide.get("title"))
        text = slide_text(slide)
        source = clean(slide.get("source"))
        key_message = clean(slide.get("key_message"))

        if stype != "cover" and not title:
            issues.append(issue("MISSING_SLIDE_TITLE", "error", idx, "页面缺少标题。", "为每个内容页补充能表达该页结论的标题。"))
        if title:
            title_counter[title.lower()] += 1
            if stype not in {"cover", "agenda", "section", "summary", "closing"} and (title.lower() in WEAK_TITLES or len(title) <= 3):
                issues.append(issue("WEAK_SLIDE_TITLE", "warning", idx, f"标题“{title}”信息量偏低。", "改为结论句，例如“核心渠道贡献了主要增量”。"))
        if key_message:
            message_counter[key_message.lower()] += 1
        if PLACEHOLDER_RE.search(text):
            placeholder_slides += 1
            issues.append(issue("PLACEHOLDER_REMAINS", "warning", idx, "页面仍包含待确认或占位内容。", "正式发布前补齐责任人、时间、数据口径或说明。"))

        has_numeric = bool(NUMERIC_RE.search(text))
        is_data_slide = stype in DATA_TYPES or has_numeric
        if is_data_slide and stype not in {"cover", "agenda", "section", "closing"}:
            data_slides += 1
            if source:
                sourced_data_slides += 1
            else:
                issues.append(issue("NUMERIC_SOURCE_MISSING", "warning", idx, "页面包含数字或数据表达，但未填写 source。", "注明文件名、Sheet、时间范围和统计口径。"))

        if stype == "chart" and not (slide.get("image") or slide.get("chart_data")):
            issues.append(issue("CHART_ASSET_MISSING", "error", idx, "图表页未指定图表图片或可编辑 chart_data。", "补充 image 路径、chart_data，或将页面改为内容/表格页。"))
        if stype == "chart":
            chart_slides += 1
            chart_data = slide.get("chart_data") or {}
            if chart_data:
                categories = chart_data.get("categories") or chart_data.get("x_values") or []
                series = chart_data.get("series") or []
                if not categories or not series:
                    issues.append(issue("CHART_DATA_INCOMPLETE", "error", idx, "可编辑图表缺少类别/X轴或数据序列。", "补充 chart_data.categories/x_values 和 series。"))
                elif any(not (item.get("values") or []) for item in series if isinstance(item, dict)):
                    issues.append(issue("CHART_SERIES_EMPTY", "error", idx, "可编辑图表存在空数据序列。", "移除空序列或补充真实数据。"))
        if stype == "table" and not (slide.get("columns") and slide.get("rows")):
            issues.append(issue("TABLE_CONTENT_MISSING", "error", idx, "表格页缺少 columns 或 rows。", "补充表头和数据行，或删除该页面。"))
        if stype == "table":
            table_slides += 1
        if stype in {"cards", "summary"}:
            card_slides += 1
        if stype in {"cards", "summary", "process", "timeline", "closing"} and not slide.get("items"):
            issues.append(issue("STRUCTURED_ITEMS_MISSING", "error", idx, f"{stype} 页面缺少 items。", "补充结构化条目，或改用 content 页面。"))
        if len(text) > 900:
            issues.append(issue("CONTENT_TOO_DENSE", "warning", idx, "页面文本超过 900 字符，可能影响可读性。", "拆成两页并为每页保留一个中心观点。", characters=len(text)))

    for title, count in title_counter.items():
        if count >= 2 and title not in {"总结", "summary"}:
            issues.append(issue("DUPLICATE_TITLES", "warning", None, f"标题“{title}”重复 {count} 次。", "区分每页结论，避免章节内部标题同质化。"))
    for message, count in message_counter.items():
        if count >= 2 and len(message) >= 8:
            issues.append(issue("DUPLICATE_KEY_MESSAGES", "warning", None, f"核心表述重复 {count} 次。", "合并重复页面，或分别说明不同证据与行动含义。"))

    if slides:
        if clean(slides[0].get("type")).lower() != "cover":
            issues.append(issue("COVER_NOT_FIRST", "warning", 1, "首屏不是 cover 页面。", "将封面放在第一页，便于建立主题与场景。"))
        if len(slides) >= 5 and clean(slides[-1].get("type")).lower() not in {"closing", "summary"}:
            issues.append(issue("ENDING_NOT_ACTIONABLE", "warning", len(slides), "文稿末页不是总结或行动页。", "以关键结论、下一步、责任人或决策请求收束。"))

    analysis_status = "not_provided"
    analysis_diagnostics = 0
    if args.analysis:
        analysis_path = Path(args.analysis).expanduser().resolve()
        if analysis_path.exists():
            analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
            analysis_status = analysis.get("status", "unknown")
            analysis_diagnostics = len(analysis.get("diagnostics") or [])
            if analysis_status == "partial":
                issues.append(issue("ANALYSIS_PARTIAL", "warning", None, "资料解析状态为 partial。", "先处理 analysis.json 的 diagnostics，再决定是否用于正式汇报。", diagnostic_count=analysis_diagnostics))
            elif analysis_status == "fail":
                issues.append(issue("ANALYSIS_FAILED", "error", None, "资料解析失败，当前内容不可视为可靠输出。", "修复输入文件后重新运行完整流程。", diagnostic_count=analysis_diagnostics))


    provenance = spec.get("provenance") or {}
    coverage_info = provenance.get("source_coverage") or {}
    missing_sources = coverage_info.get("unrepresented_sources") or []
    if missing_sources:
        issues.append(issue(
            "SOURCE_COVERAGE_INCOMPLETE", "warning", None,
            f"有 {len(missing_sources)} 份资料尚未明确体现在页面来源中。",
            "确认这些资料是否应纳入；不需要时在运行摘要中说明排除原因。",
            sources=missing_sources[:10],
        ))
    planning = spec.get("planning") or {}
    mode = clean(spec.get("mode")).lower()
    if mode == "data":
        required_charts = 3 if len(slides) >= 8 else 2 if len(slides) >= 5 else 1
        if data_slides >= 3 and chart_slides < required_charts:
            issues.append(issue(
                "DATA_VISUALIZATION_INSUFFICIENT", "error", None,
                f"数据型汇报仅有 {chart_slides} 个图表页，至少需要 {required_charts} 个。",
                "优先加入趋势图、分类对比图和单位效率/强度图，减少重复卡片或纯文字数据页。",
                chart_slides=chart_slides, required=required_charts,
            ))
        if data_slides >= 4 and chart_slides == 0:
            issues.append(issue(
                "DATA_DECK_WITHOUT_CHARTS", "error", None,
                "文稿包含多页数字内容，但没有任何可视化图表。",
                "重新规划页面，确保关键趋势、结构差异和异常均有图表证据。",
            ))
        if card_slides > max(3, chart_slides + 2):
            issues.append(issue(
                "CARD_HEAVY_DATA_DECK", "warning", None,
                "数据型汇报使用了过多卡片页，信息对比和趋势不够直观。",
                "合并重复 KPI 卡片，将至少两页改成趋势图、对比图或明细表。",
                card_slides=card_slides, chart_slides=chart_slides,
            ))
    if planning.get("content_complexity") == "high":
        issues.append(issue(
            "COMPLEX_CONTENT_MANUAL_REVIEW", "warning", None,
            "资料复杂度较高，自动生成结果需要重点核对逻辑覆盖和取舍。",
            "优先检查目录、关键结论、来源覆盖和被省略的章节。",
        ))

    error_count = sum(1 for x in issues if x["severity"] == "error")
    warning_count = sum(1 for x in issues if x["severity"] == "warning")
    source_coverage = round(sourced_data_slides / data_slides * 100, 1) if data_slides else 100.0
    title_quality = round(max(0.0, 100 - 12 * sum(1 for x in issues if x["code"] == "WEAK_SLIDE_TITLE") / max(len(slides), 1)), 1)
    status = "fail" if error_count else "review" if warning_count else "pass"
    readiness_score = max(0.0, min(100.0, 100 - error_count * 20 - warning_count * 3))
    report = {
        "file": str(spec_path),
        "status": status,
        "summary": {
            "slide_count": len(slides),
            "error_count": error_count,
            "warning_count": warning_count,
            "data_slide_count": data_slides,
            "chart_slide_count": chart_slides,
            "table_slide_count": table_slides,
            "card_slide_count": card_slides,
            "numeric_source_coverage_pct": source_coverage,
            "title_quality_score": title_quality,
            "placeholder_slide_count": placeholder_slides,
            "analysis_status": analysis_status,
            "source_file_coverage_pct": round(float(coverage_info.get("coverage_ratio", 1.0)) * 100, 1),
            "formal_use_readiness_score": round(readiness_score, 1),
            "manual_review_required": bool(error_count or warning_count or planning.get("manual_review_required")),
        },
        "issues": issues,
        "human_review_checklist": [
            "标题是否准确表达结论，而非仅写主题名。",
            "数字、时间范围、单位和来源是否与原始资料一致。",
            "跨文件口径是否一致，冲突处是否明确标注。",
            "页面顺序是否形成背景—证据—判断—行动的完整逻辑。",
            "行动项是否有负责人、时间和可验证结果。",
        ],
    }
    out = Path(args.report).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    user_lines = [
        "# 内容审校结果", "",
        f"- 状态：**{'可继续生成' if not error_count else '需要先修复'}**",
        f"- 正式使用准备度：{readiness_score:.1f}/100",
        f"- 数字来源覆盖率：{source_coverage:.1f}%",
        f"- 资料来源覆盖率：{float(coverage_info.get('coverage_ratio', 1.0)) * 100:.1f}%",
    ]
    if issues:
        user_lines += ["", "## 需要核对"]
        for item in issues[:12]:
            page = f"第 {item.get('slide')} 页" if item.get('slide') else "整份文稿"
            user_lines.append(f"- **{page}**：{item.get('message')}；建议：{item.get('suggestion')}")
    else:
        user_lines += ["", "未发现阻断性内容问题。正式发布前仍需核对业务判断和原始数据。"]
    (out.parent / "内容审校说明.md").write_text("\n".join(user_lines), encoding="utf-8")
    print(str(out))
    return 2 if error_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
