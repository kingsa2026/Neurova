#!/usr/bin/env python3
"""Validate structure, safety, documentation and release readiness."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

try:
    import yaml
except Exception:
    yaml = None

REQUIRED = [
    "SKILL.md", "manifest.yaml", "README.md", "QUICKSTART.md", "PUBLISHING.md",
    "CHANGELOG.md", "LICENSE.txt", "requirements.txt", "requirements-tested.txt",
    "scripts", "references", "assets", "examples",
]
REQUIRED_SCRIPTS = [
    "analyze_materials.py", "draft_spec.py", "review_content.py", "build_deck.py",
    "validate_deck.py", "run_pipeline.py", "quick_start.py", "repair_spec.py",
    "preflight.py", "self_test.py", "package_check.py", "style_engine.py", "template_style.py", "template_match_report.py", "visual_planner.py",
]
REQUIRED_REFS = [
    "capability-boundaries.md", "case-library.md", "best-practices.md",
    "troubleshooting.md", "content-planning.md", "publishing-checklist.md", "style-system.md", "domain-profile-energy.md", "visual-generation.md",
]
EMBEDDED_PRESENTATIONS_REQUIRED = [
    "embedded_skills/presentations/SKILL.md",
    "embedded_skills/presentations/style_guidelines.md",
    "embedded_skills/presentations/references/template-following.md",
    "embedded_skills/presentations/template_following_scripts",
    "embedded_skills/presentations/container_tools",
]
FORBIDDEN_NAMES = {".env", "id_rsa", "credentials.json", "secrets.json", "token.json"}
FORBIDDEN_SUFFIXES = {".key", ".pem", ".p12", ".pfx", ".pyc", ".ttf", ".otf", ".woff", ".woff2"}
OUTPUT_PATTERNS = re.compile(r"(?:analysis|validation|content_review|pipeline_report|self_test_report|preflight|package_check_report)\.json$|\.pptx$", re.I)
SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
]
TRIGGER_PHRASES = ["做成PPT", "整理成汇报", "帮我讲清楚", "开会用", "排成好看的页", "给领导做个简报"]
BOUNDARY_PHRASES = ["扫描版 PDF", "不执行 OCR", ".xls", "人工核对", "专业可编辑初稿"]


def load_yaml_mapping(text: str) -> dict:
    if yaml is not None:
        return yaml.safe_load(text) or {}
    result: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key and not key.startswith("-"):
            result[key.strip()] = value.strip().strip("\"'")
    return result


def add_check(checks, issues, name, passed, *, severity="error", details=None, code=None):
    checks.append({"check": name, "pass": bool(passed), "details": details})
    if not passed:
        issues.append({"severity": severity, "code": code or name.upper(), "details": details})


def main() -> int:
    parser = argparse.ArgumentParser(description="Check skill package structure, safety and publish readiness")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--report", default="")
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    checks: list[dict] = []
    issues: list[dict] = []

    for item in REQUIRED:
        add_check(checks, issues, f"required:{item}", (root / item).exists(), code="PACKAGE_REQUIRED_MISSING", details=item)
    for item in REQUIRED_SCRIPTS:
        add_check(checks, issues, f"script:{item}", (root / "scripts" / item).exists(), code="PACKAGE_SCRIPT_MISSING", details=item)
    for item in REQUIRED_REFS:
        add_check(checks, issues, f"reference:{item}", (root / "references" / item).exists(), code="PACKAGE_REFERENCE_MISSING", details=item)
    for item in EMBEDDED_PRESENTATIONS_REQUIRED:
        add_check(checks, issues, f"embedded_presentations:{item}", (root / item).exists(), code="EMBEDDED_PRESENTATIONS_MISSING", details=item)

    manifest = {}
    manifest_path = root / "manifest.yaml"
    if manifest_path.exists():
        try:
            manifest = load_yaml_mapping(manifest_path.read_text(encoding="utf-8"))
            add_check(checks, issues, "manifest_yaml", True)
        except Exception as exc:
            add_check(checks, issues, "manifest_yaml", False, code="MANIFEST_INVALID", details=str(exc))

    skill_path = root / "SKILL.md"
    frontmatter = {}
    skill_text = ""
    if skill_path.exists():
        skill_text = skill_path.read_text(encoding="utf-8")
        match = re.match(r"^---\n(.*?)\n---\n", skill_text, re.S)
        if match:
            try:
                frontmatter = load_yaml_mapping(match.group(1))
                add_check(checks, issues, "skill_frontmatter", True)
            except Exception as exc:
                add_check(checks, issues, "skill_frontmatter", False, code="SKILL_FRONTMATTER_INVALID", details=str(exc))
        else:
            add_check(checks, issues, "skill_frontmatter", False, code="SKILL_FRONTMATTER_MISSING")

    if manifest and frontmatter:
        add_check(checks, issues, "name_consistency", manifest.get("name") == frontmatter.get("name"), code="NAME_MISMATCH", details={"manifest": manifest.get("name"), "skill": frontmatter.get("name")})
        version = str(manifest.get("version", ""))
        add_check(checks, issues, "semantic_version", bool(re.fullmatch(r"\d+\.\d+\.\d+", version)), code="VERSION_INVALID", details=version)
        add_check(checks, issues, "display_name_present", bool(manifest.get("display_name")), code="DISPLAY_NAME_MISSING")

    trigger_count = sum(1 for x in TRIGGER_PHRASES if x in skill_text)
    add_check(checks, issues, "fuzzy_trigger_coverage", trigger_count >= 5, severity="warning", code="TRIGGER_COVERAGE_LOW", details={"matched": trigger_count, "expected": TRIGGER_PHRASES})
    boundary_count = sum(1 for x in BOUNDARY_PHRASES if x in skill_text)
    add_check(checks, issues, "boundary_frontloaded", boundary_count == len(BOUNDARY_PHRASES), code="BOUNDARY_NOT_EXPLICIT", details={"matched": boundary_count, "expected": BOUNDARY_PHRASES})

    run_text = (root / "scripts" / "run_pipeline.py").read_text(encoding="utf-8") if (root / "scripts" / "run_pipeline.py").exists() else ""
    recovery_terms = ["--no-resume", "--retries", "repair_spec.py", ".pipeline_state.json", "运行摘要.md"]
    add_check(checks, issues, "recovery_features", all(x in run_text for x in recovery_terms), code="RECOVERY_FEATURE_MISSING", details=[x for x in recovery_terms if x not in run_text])

    case_text = (root / "references" / "case-library.md").read_text(encoding="utf-8") if (root / "references" / "case-library.md").exists() else ""
    case_count = len(re.findall(r"^## 案例", case_text, re.M))
    add_check(checks, issues, "complete_case_count", case_count >= 6, severity="warning", code="CASE_LIBRARY_TOO_SMALL", details=case_count)

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if path.name in FORBIDDEN_NAMES or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            issues.append({"severity": "error", "code": "FORBIDDEN_FILE", "path": rel})
        if "__pycache__" in path.parts:
            issues.append({"severity": "error", "code": "CACHE_FILE", "path": rel})
        if OUTPUT_PATTERNS.search(path.name) and not rel.startswith("examples/"):
            issues.append({"severity": "warning", "code": "GENERATED_OUTPUT_INCLUDED", "path": rel})
        if path.stat().st_size > 20 * 1024 * 1024:
            issues.append({"severity": "warning", "code": "LARGE_PACKAGE_FILE", "path": rel, "size_bytes": path.stat().st_size})
        if path.suffix.lower() in {".md", ".py", ".yaml", ".yml", ".json", ".txt"} and path.stat().st_size < 2 * 1024 * 1024:
            try:
                content = path.read_text(encoding="utf-8")
                for pattern in SECRET_PATTERNS:
                    if pattern.search(content):
                        issues.append({"severity": "error", "code": "POSSIBLE_SECRET", "path": rel, "pattern": pattern.pattern})
            except Exception:
                pass

    compile_errors = []
    for script in (root / "scripts").glob("*.py") if (root / "scripts").exists() else []:
        try:
            compile(script.read_text(encoding="utf-8"), str(script), "exec")
        except Exception as exc:
            compile_errors.append({"path": script.name, "message": str(exc)})
    add_check(checks, issues, "python_compile", not compile_errors, code="PYTHON_COMPILE_FAILED", details=compile_errors)

    # Validate JSON examples.
    json_errors = []
    for path in (root / "examples").rglob("*.json") if (root / "examples").exists() else []:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            json_errors.append({"path": path.relative_to(root).as_posix(), "message": str(exc)})
    add_check(checks, issues, "example_json_valid", not json_errors, code="EXAMPLE_JSON_INVALID", details=json_errors)

    # requirements should use bounded ranges for reproducible upgrades.
    req_text = (root / "requirements.txt").read_text(encoding="utf-8") if (root / "requirements.txt").exists() else ""
    req_lines = [x.strip() for x in req_text.splitlines() if x.strip() and not x.startswith("#")]
    bounded = all(">=" in x and "<" in x for x in req_lines)
    add_check(checks, issues, "bounded_dependencies", bounded, severity="warning", code="DEPENDENCIES_UNBOUNDED", details=[x for x in req_lines if not (">=" in x and "<" in x)])

    errors = [x for x in issues if x.get("severity") == "error"]
    warnings = [x for x in issues if x.get("severity") == "warning"]
    report = {
        "root": str(root),
        "status": "pass" if not errors else "fail",
        "skill": manifest.get("name"),
        "display_name": manifest.get("display_name"),
        "version": manifest.get("version"),
        "check_count": len(checks),
        "error_count": len(errors),
        "warning_count": len(warnings),
        "checks": checks,
        "issues": issues,
    }
    report_path = Path(args.report).expanduser().resolve() if args.report else root.parent / "package_check_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(report_path))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
