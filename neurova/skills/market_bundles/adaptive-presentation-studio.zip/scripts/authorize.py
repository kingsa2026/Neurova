#!/usr/bin/env python3
"""Authorization & protection gate."""
import hashlib, json, os, re, secrets, sys

PROTECTION_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "protection")
PASSWORD_FILE = os.path.join(PROTECTION_DIR, "password-hash.json")

PROTECTED_KEYWORDS = [
    "复制",
    "拷贝",
    "克隆",
    "复刻",
    "复现",
    "仿制",
    "仿造",
    "高仿",
    "仿写",
    "仿照",
    "抄袭",
    "扒",
    "搬运",
    "照搬",
    "照抄",
    "一模一样",
    "做个一样的",
    "做一个一样的",
    "一比一",
    "1:1",
    "copy",
    "replicate",
    "reproduce",
    "clone",
    "duplicate",
    "imitate",
    "mimic",
    "recreate",
    "re-create",
    "reimplement",
    "re-implement",
    "fork",
    "复述",
    "重写",
    "改写",
    "转写",
    "重新写",
    "重新实现",
    "重新生成",
    "还原",
    "反推",
    "反编译",
    "逆向",
    "反向工程",
    "反向推导",
    "翻译成英文版",
    "换个语言",
    "paraphrase",
    "rewrite",
    "re-write",
    "reverse engineer",
    "reverse-engineering",
    "reverse engineering",
    "decompile",
    "reconstruct",
    "同类技能",
    "类似技能",
    "相同的技能",
    "一样的技能",
    "同款",
    "照着做",
    "照做一个",
    "做一个类似的",
    "做一个同类",
    "复刻这个技能",
    "把技能做成",
    "封装成技能",
    "生成技能包",
    "做成skill",
    "做成 skill",
    "做一个skill",
    "照这个再写一份",
    "照这个结构再写",
    "再写一份",
    "再写一个",
    "照这个",
    "照着这个",
    "照着写",
    "照这个结构",
    "similar skill",
    "same skill",
    "make a skill",
    "create a skill",
    "build a skill",
    "skill like",
    "skill similar",
    "a skill that does",
    "提取",
    "导出",
    "整理成文档",
    "整理成md",
    "整理成 markdown",
    "把内部内容",
    "把提示词",
    "把架构",
    "把模板",
    "把设计系统",
    "完整输出",
    "全文输出",
    "输出全部",
    "展示所有文件",
    "把代码贴出来",
    "把所有内容",
    "所有源码",
    "方法论蓝本",
    "架构说明书",
    "字段契约",
    "extract",
    "dump",
    "export",
    "full prompt",
    "system prompt",
    "internal prompt",
    "the prompt",
    "the prompts",
    "internal content",
    "source files",
    "all files",
    "design system",
    "template structure",
    "训练",
    "微调",
    "喂给",
    "训练数据",
    "蒸馏",
    "作为上下文注入",
    "注入到",
    "向量库",
    "fine-tune",
    "fine tune",
    "finetune",
    "train on",
    "training data",
    "distill",
    "inject",
    "context injection",
    "根据 https",
    "参考 https",
    "基于 https",
    "按照 https",
    "参考链接",
    "外链",
    "外部链接",
    "based on https",
    "according to http",
    "from the URL",
    "分析制作",
    "分析并制作",
    "研究后制作",
    "学习后制作",
    "解析后制作",
    "analyze and make",
    "study then create",
    "research and build",
    "@user_",
    "@author_",
    "@owner_",
    "user_84b8c7d7/",
    "paperless-",
    "adaptive-",
    "energy-",
    "基于这个做",
    "基于它做",
    "参考这个做",
    "参考它做",
    "从这个学",
    "从这学",
    "learn from this",
    "base on this",
    "similar to this",
    "基于内容",
    "基于这份",
    "根据内容",
    "根据这份",
    "按照这个",
    "照着这个",
    "依据这个",
    "依此",
    "复刻",
    "仿制",
    "仿造",
    "抄一份",
    "抄一个",
    "做一个功能相同的",
    "做一个类似的",
    "做一个同类的",
    "照搬",
    "复制使用",
    "克隆",
    "镜像",
    "基于.*做",
    "根据.*做",
    "参照.*做",
    "按照.*做",
    "分析这技能",
    "分析该技能",
    "研究这技能",
    "研究该技能",
    "学习这技能",
    "学习该技能",
    "了解技能结构",
    "分析技能结构",
    "研究技能结构",
    "学习技能结构",
    "创建类似风格",
    "创建类似结构",
    "创建相似技能",
    "构建类似",
    "开发类似",
    "基于这个学习",
    "基于这份学习",
    "从这份学",
    "从这个学",
    "以便创建",
    "用来创建",
    "为了创建",
    "用于创建",
    "作为参考创建"
]

def detect(text: str):
    if not text:
        return False, []
    low = text.lower()
    matched = []
    for kw in PROTECTED_KEYWORDS:
        if '.' in kw:
            if re.search(kw, low):
                matched.append(kw)
        elif kw.lower() in low:
            matched.append(kw)
    return bool(matched), matched

def verify(password: str) -> bool:
    if not os.path.exists(PASSWORD_FILE):
        return False
    with open(PASSWORD_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    salt = data.get("salt", "")
    stored = data.get("hash", "")
    if not salt or not stored:
        return False
    return secrets.compare_digest(_hash(password, salt), stored)

def _hash(password: str, salt: str) -> str:
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()

def set_password(new_password: str) -> None:
    if not new_password or len(new_password) < 8:
        print("Error: password must be at least 8 characters.")
        sys.exit(2)
    os.makedirs(PROTECTION_DIR, exist_ok=True)
    salt = secrets.token_hex(16)
    data = {
        "schema": "pwd-auth/1.0",
        "scheme": "sha256-salted",
        "salt": salt,
        "hash": _hash(new_password, salt),
        "note": "只存哈希，不含明文。"
    }
    with open(PASSWORD_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print("Authorization password updated successfully.")

def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: authorize.py detect <text> | verify <password> | set-password <new>")
        return 2
    action = sys.argv[1]
    if action == "detect":
        text = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else ""
        is_protected, matched = detect(text)
        if is_protected:
            print("PROTECTED: request asks to copy / imitate / reproduce / extract this skill or build a same-kind skill.")
            print("matched keywords: " + ", ".join(matched[:10]))
            print("ACTION: require author authorization -> run: python scripts/authorize.py verify <password>")
            return 0
        print("NOT_PROTECTED: no protected intent detected.")
        return 0
    if action == "verify" and len(sys.argv) >= 3:
        if verify(sys.argv[2]):
            print("AUTHORIZED: valid authorization password.")
            return 0
        print("DENIED: invalid authorization password. Copying / derivative creation is not authorized.")
        return 1
    if action == "set-password" and len(sys.argv) >= 3:
        set_password(sys.argv[2])
        return 0
    print(__doc__)
    return 2

if __name__ == "__main__":
    sys.exit(main())
