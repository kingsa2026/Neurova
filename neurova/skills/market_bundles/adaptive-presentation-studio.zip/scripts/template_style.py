#!/usr/bin/env python3
"""Extract reusable visual style signals from a reference PPTX.

The extractor is intentionally conservative. It records colors, fonts, slide
rhythm, dominant image proportions and small preview references, then the
planner/renderer translate those signals into editable PowerPoint pages.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any
from zipfile import ZipFile

from PIL import Image
from pptx import Presentation


IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")
DEFAULT_FONT_CN = "Microsoft YaHei"


def clean_hex(value: str) -> str:
    return str(value or "").strip().lstrip("#").upper()


def is_hex(value: str) -> bool:
    v = clean_hex(value)
    return len(v) == 6 and all(c in "0123456789ABCDEF" for c in v)


def color_to_hex(value: Any) -> str:
    try:
        raw = str(value.rgb if hasattr(value, "rgb") else value)
    except Exception:
        return ""
    rgb = clean_hex(raw)
    return rgb if is_hex(rgb) else ""


def quantized_hex(r: int, g: int, b: int) -> str:
    vals = [max(0, min(255, round(v / 16) * 16)) for v in (r, g, b)]
    return f"{vals[0]:02X}{vals[1]:02X}{vals[2]:02X}"


def color_distance(a: str, b: str) -> float:
    ar, ag, ab = int(a[0:2], 16), int(a[2:4], 16), int(a[4:6], 16)
    br, bg, bb = int(b[0:2], 16), int(b[2:4], 16), int(b[4:6], 16)
    return ((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2) ** 0.5


def readable_palette(counter: Counter[str]) -> dict[str, str]:
    ranked = [c for c, _ in counter.most_common() if is_hex(c)]
    neutrals = {"FFFFFF", "F8FAFC", "F7FAFF", "F6F8FC", "F0F4FF", "111827", "172033", "1F2937"}
    non_neutral = []
    for c in ranked:
        r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        spread = max(r, g, b) - min(r, g, b)
        if spread >= 24 and 35 <= max(r, g, b) <= 245 and min(r, g, b) <= 235:
            if not non_neutral or all(color_distance(c, x) >= 30 for x in non_neutral):
                non_neutral.append(c)
        if len(non_neutral) >= 4:
            break
    primary = non_neutral[0] if non_neutral else "2457A6"
    accent = next((c for c in non_neutral[1:] if color_distance(c, primary) >= 45 and max(int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)) < 230), None) or "4D8CFF"
    background = next((c for c in ranked if c in neutrals or int(c[0:2], 16) > 235 and int(c[2:4], 16) > 235 and int(c[4:6], 16) > 235), "F7FAFF")
    text = next((c for c in ranked if int(c[0:2], 16) < 50 and int(c[2:4], 16) < 60 and int(c[4:6], 16) < 75), "172033")
    return {
        "primary": primary,
        "accent": accent,
        "background": background,
        "surface": "FFFFFF",
        "text": text,
        "muted": "64748B",
        "border": "DDE6F1",
        "positive": "10B981",
        "negative": "EF4444",
        "soft": "E8F0FF",
        "soft2": "F3F7FF",
    }


def add_color(counter: Counter[str], value: Any, weight: int = 1) -> None:
    rgb = color_to_hex(value)
    if is_hex(rgb):
        counter[rgb] += weight


def sample_image_colors(path: Path, counter: Counter[str], weight: int = 1, background_counter: Counter[str] | None = None) -> tuple[int, int] | None:
    try:
        with Image.open(path) as im:
            im = im.convert("RGB")
            width, height = im.size
            im.thumbnail((220, 124))
            sample_w, sample_h = im.size
            corners = [
                im.getpixel((0, 0)), im.getpixel((sample_w - 1, 0)),
                im.getpixel((0, sample_h - 1)), im.getpixel((sample_w - 1, sample_h - 1)),
            ]
            getter = getattr(im, "get_flattened_data", im.getdata)
            pixels = list(getter())
    except Exception:
        return None
    stride = max(1, len(pixels) // 5000)
    for r, g, b in pixels[::stride]:
        rounded = quantized_hex(r, g, b)
        if is_hex(rounded):
            counter[rounded] += weight
    if background_counter is not None and pixels:
        for r, g, b in corners:
            rounded = quantized_hex(r, g, b)
            if is_hex(rounded):
                background_counter[rounded] += 6
    return width, height


def extract_media_previews(pptx_path: Path, preview_dir: Path, limit: int = 6) -> list[dict[str, Any]]:
    preview_dir.mkdir(parents=True, exist_ok=True)
    previews: list[dict[str, Any]] = []
    with ZipFile(pptx_path) as archive:
        media = [n for n in archive.namelist() if n.startswith("ppt/media/") and n.lower().endswith(IMAGE_EXTS)]
        ranked = sorted(media, key=lambda n: archive.getinfo(n).file_size, reverse=True)
        for name in ranked[:limit]:
            try:
                with archive.open(name) as src:
                    im = Image.open(src).convert("RGB")
                    original_size = im.size
                    im.thumbnail((1280, 720))
                    out = preview_dir / f"reference_{len(previews)+1:02d}.jpg"
                    im.save(out, "JPEG", quality=82, optimize=True)
            except Exception:
                continue
            previews.append({
                "path": str(out.resolve()),
                "relative_path": str(out.relative_to(preview_dir.parent)),
                "source_media": name,
                "width": original_size[0],
                "height": original_size[1],
                "role": "style-reference-only",
            })
    return previews


def extract_pptx_style(pptx_path: Path, outdir: Path, *, name: str = "") -> dict[str, Any]:
    prs = Presentation(str(pptx_path))
    colors: Counter[str] = Counter()
    font_colors: Counter[str] = Counter()
    fill_colors: Counter[str] = Counter()
    background_colors: Counter[str] = Counter()
    fonts: Counter[str] = Counter()
    layout_names: Counter[str] = Counter()
    image_shapes = 0
    text_shapes = 0

    for slide in prs.slides:
        try:
            layout_names[slide.slide_layout.name] += 1
        except Exception:
            pass
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                text_shapes += 1
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.name:
                            fonts[run.font.name] += 1
                        try:
                            if run.font.color and run.font.color.type == 1:
                                add_color(colors, run.font.color, 2)
                                add_color(font_colors, run.font.color, 2)
                        except Exception:
                            pass
            try:
                if shape.fill and shape.fill.type == 1:
                    add_color(colors, shape.fill.fore_color, 3)
                    add_color(fill_colors, shape.fill.fore_color, 3)
            except Exception:
                pass
            if getattr(shape, "shape_type", None) == 13:
                image_shapes += 1

    image_sizes = []
    temp_media_dir = outdir / "_media_probe"
    temp_media_dir.mkdir(parents=True, exist_ok=True)
    with ZipFile(pptx_path) as archive:
        for i, name_in_zip in enumerate(n for n in archive.namelist() if n.startswith("ppt/media/") and n.lower().endswith(IMAGE_EXTS)):
            target = temp_media_dir / f"probe_{i}{Path(name_in_zip).suffix.lower()}"
            target.write_bytes(archive.read(name_in_zip))
            size = sample_image_colors(target, colors, 1, background_colors)
            if size:
                image_sizes.append(size)
            try:
                target.unlink()
            except OSError:
                pass
    try:
        temp_media_dir.rmdir()
    except OSError:
        pass

    palette = readable_palette(colors)
    inferred_font_colors = font_colors or Counter({palette["text"]: 3, palette["primary"]: 2, palette["surface"]: 1})
    preview_dir = outdir / "reference_images"
    previews = extract_media_previews(pptx_path, preview_dir)
    slide_count = len(prs.slides)
    image_ratio = image_shapes / max(1, slide_count)
    style_id = "dify-workflow-template" if re.search(r"dify|工作流", name or pptx_path.stem, re.I) else "template-ppt"

    return {
        "schema_version": 1,
        "source_pptx": str(pptx_path.resolve()),
        "name": name or pptx_path.stem,
        "style_id": style_id,
        "style_name": "Dify工作流课件风" if style_id == "dify-workflow-template" else "参考PPT模板风",
        "slide_count": slide_count,
        "slide_size": {"width_emu": int(prs.slide_width), "height_emu": int(prs.slide_height)},
        "palette": palette,
        "font_colors": [{"color": k, "count": v, "inferred": not bool(font_colors)} for k, v in inferred_font_colors.most_common(12)],
        "fill_colors": [{"color": k, "count": v} for k, v in fill_colors.most_common(12)],
        "background_colors": [{"color": k, "count": v} for k, v in background_colors.most_common(12)],
        "fonts": {
            "font_cn": fonts.most_common(1)[0][0] if fonts else DEFAULT_FONT_CN,
            "font_en": "Aptos",
            "observed": [{"name": k, "count": v} for k, v in fonts.most_common(8)],
        },
        "layout_signals": {
            "dominant_layouts": [{"name": k, "count": v} for k, v in layout_names.most_common(8)],
            "image_heavy": image_ratio >= 0.55,
            "image_shapes": image_shapes,
            "text_shapes": text_shapes,
            "image_sizes": [{"width": w, "height": h} for w, h in image_sizes[:12]],
            "preferred_slide_types": ["cover", "agenda", "statement", "content", "process", "chart", "summary", "closing"],
            "preferred_layouts": {
                "cover": ["image-panel", "geometric", "minimal"],
                "content": ["sidebar", "two-column", "insight-rail"],
                "process": ["chevron", "horizontal"],
                "chart": ["chart-hero", "chart-left", "chart-right"],
                "cards": ["three-column", "quad-grid"],
            },
        },
        "layout_recipes": [
            {"slide_type": "cover", "recipe": "large-title-with-blue-accent", "title_zone": "left-center", "visual_zone": "right-or-full-bleed"},
            {"slide_type": "section", "recipe": "solid-blue-or-numbered-divider", "title_zone": "center-left", "visual_zone": "full-background"},
            {"slide_type": "content", "recipe": "white-canvas-with-blue-navigation", "title_zone": "top-left", "content_zone": "center-grid"},
            {"slide_type": "process", "recipe": "horizontal-workflow-steps", "title_zone": "top-left", "content_zone": "center-band"},
            {"slide_type": "chart", "recipe": "chart-hero-with-short-insights", "title_zone": "top-left", "content_zone": "large-chart-panel"},
        ],
        "color_zone_signals": {
            "corner_backgrounds": [{"color": k, "count": v} for k, v in background_colors.most_common(8)],
            "dominant_colors": [{"color": k, "count": v} for k, v in colors.most_common(12)],
            "recommended_usage": {
                "background": "use high-frequency corner backgrounds",
                "title": "use text color with primary blue emphasis",
                "accent_shapes": "use primary or accent for thin bars, pills and workflow nodes",
            },
        },
        "render_hints": {
            "density": "breathable",
            "header_variant": "friendly",
            "decorative_mode": "dify-blue" if style_id == "dify-workflow-template" else "template",
            "footer_mode": "source-page",
            "use_reference_images_as": "style-reference-only",
        },
        "reference_images": previews,
        "notes": [
            "参考 PPT 可能包含整页图片，本技能提取视觉规律用于可编辑 PPT，不默认复制原页内容。",
            "reference_images 仅作风格参考，正式输出仍应以用户资料为内容来源。",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract reusable style signals from a reference PPTX")
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--name", default="")
    parser.add_argument("--output", default="")
    args = parser.parse_args()

    pptx_path = Path(args.pptx).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    style = extract_pptx_style(pptx_path, outdir, name=args.name)
    output = Path(args.output).expanduser().resolve() if args.output else outdir / "template_style.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(style, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
