#!/usr/bin/env python3
"""Render a content-adaptive 16:9 PowerPoint from deck_spec.json.

The renderer intentionally supports multiple visual structures per slide type.
When ``layout`` is ``auto`` it selects a layout from content length, item count,
image aspect ratio and recent layout history to avoid a fixed-template result.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import traceback
from pathlib import Path
from typing import Any

from PIL import Image
from pptx.chart.data import ChartData, XyChartData
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from style_engine import STYLE_PRESETS, style_profile

try:
    from visual_fillers import draw_filler
except Exception:  # pragma: no cover - kept as safe fallback
    draw_filler = None

THEMES = {
    "dify-workflow": {
        "primary": "0046C7", "accent": "4D8CFF", "background": "F7FAFF",
        "surface": "FFFFFF", "text": "111827", "muted": "64748B", "border": "DDE6F1",
        "positive": "10B981", "negative": "EF4444", "soft": "E8F0FF", "soft2": "F3F7FF"
    },
    "modern-blue": {
        "primary": "2457A6", "accent": "F2A900", "background": "F6F8FC",
        "surface": "FFFFFF", "text": "172033", "muted": "667085", "border": "D8E0EA",
        "positive": "237A57", "negative": "B13A3A", "soft": "E9F0FB", "soft2": "EEF2F7"
    },
    "editorial-red": {
        "primary": "A61B2B", "accent": "E6A23C", "background": "FBF7F5",
        "surface": "FFFFFF", "text": "2C2021", "muted": "756468", "border": "E7D9D7",
        "positive": "237A57", "negative": "A61B2B", "soft": "F8E8E9", "soft2": "F2ECE9"
    },
    "warm-neutral": {
        "primary": "5E5147", "accent": "C78545", "background": "FAF8F4",
        "surface": "FFFFFF", "text": "2B2926", "muted": "756F68", "border": "E5DED5",
        "positive": "557A5B", "negative": "A64B45", "soft": "F1E9DE", "soft2": "F3F0EA"
    },
    "creative-purple": {
        "primary": "6542A6", "accent": "EC8F5E", "background": "F8F6FC",
        "surface": "FFFFFF", "text": "201A2E", "muted": "6D657A", "border": "DED8E8",
        "positive": "2A8066", "negative": "B3475B", "soft": "EEE9F8", "soft2": "F2EEF7"
    },
    "fresh-green": {
        "primary": "16725E", "accent": "D8A129", "background": "F4F9F7",
        "surface": "FFFFFF", "text": "17322C", "muted": "60736F", "border": "D5E4DF",
        "positive": "16725E", "negative": "B54B42", "soft": "E3F2ED", "soft2": "ECF4F1"
    },
    "dark-tech": {
        "primary": "8DB4FF", "accent": "FFB657", "background": "0F1726",
        "surface": "182338", "text": "F4F7FB", "muted": "B8C2D1", "border": "31415B",
        "positive": "69D3A7", "negative": "FF8B8B", "soft": "203352", "soft2": "16243A"
    },
    "consulting-light": {
        "primary": "1F3A5F", "accent": "4D78A8", "background": "F7F9FC",
        "surface": "FFFFFF", "text": "111827", "muted": "667085", "border": "D9E1EA",
        "positive": "2A7A5F", "negative": "A84040", "soft": "EAF0F6", "soft2": "F2F5F8"
    },
    "magazine-mono": {
        "primary": "151515", "accent": "D84A62", "background": "F7F6F2",
        "surface": "FFFFFF", "text": "141414", "muted": "6B6B6B", "border": "DCD8D0",
        "positive": "2F7D62", "negative": "C43D4D", "soft": "EEEAE4", "soft2": "F2EFEA"
    },
    "dashboard-light": {
        "primary": "2563EB", "accent": "06A6B8", "background": "F5F8FC",
        "surface": "FFFFFF", "text": "0F172A", "muted": "64748B", "border": "DDE6F1",
        "positive": "10B981", "negative": "EF4444", "soft": "E8F0FF", "soft2": "F0F5FA"
    },
    "academic-blue": {
        "primary": "274C77", "accent": "6096BA", "background": "F6F8FB",
        "surface": "FFFFFF", "text": "183153", "muted": "687789", "border": "D9E1E8",
        "positive": "3B7A57", "negative": "A94442", "soft": "E8F0F6", "soft2": "F0F4F7"
    },
    "teaching-warm": {
        "primary": "2F6B5C", "accent": "F0A23A", "background": "FBF9F3",
        "surface": "FFFFFF", "text": "20342E", "muted": "6B756F", "border": "E4DFD4",
        "positive": "2F7D62", "negative": "B6554B", "soft": "E8F3EE", "soft2": "F6F1E8"
    },
    "brand-pop": {
        "primary": "4C1D95", "accent": "F43F5E", "background": "FFFBFA",
        "surface": "FFFFFF", "text": "1F1530", "muted": "71667B", "border": "E7DBEE",
        "positive": "0F9D75", "negative": "E23D55", "soft": "F2EAFE", "soft2": "FFF0F3"
    },
    "minimal-stone": {
        "primary": "262626", "accent": "7C8A97", "background": "FAFAF8",
        "surface": "FFFFFF", "text": "171717", "muted": "737373", "border": "E5E5E1",
        "positive": "3D7B66", "negative": "A64B45", "soft": "EFEEE9", "soft2": "F5F4F0"
    },
    "luxury-ink": {
        "primary": "2B2926", "accent": "B49A6A", "background": "F6F2EA",
        "surface": "FFFFFF", "text": "1C1B19", "muted": "776F64", "border": "DFD8CC",
        "positive": "5D7A68", "negative": "A04A45", "soft": "ECE5D9", "soft2": "F4EFE7"
    },
    "china-red": {
        "primary": "A51C30", "accent": "D6A649", "background": "FCF8F5",
        "surface": "FFFFFF", "text": "3A2424", "muted": "7B6868", "border": "E9DCD8",
        "positive": "416E5C", "negative": "A51C30", "soft": "F7E9E8", "soft2": "F8F1EC"
    },
    # Backward-compatible names.
    "corporate-blue": {}, "warm-red": {}, "emerald": {}, "dark-navy": {},
}
THEMES["corporate-blue"] = THEMES["modern-blue"]
THEMES["warm-red"] = THEMES["editorial-red"]
THEMES["emerald"] = THEMES["fresh-green"]
THEMES["dark-navy"] = THEMES["dark-tech"]

SLIDE_W = 13.333
SLIDE_H = 7.5
MARGIN_X = 0.62
CONTENT_TOP = 1.38
FOOTER_Y = 7.14
# A second typeface for big numerals/metrics. Latin-only glyphs keep Chinese
# running on the main font while giving numbers a distinct, lighter weight.
FONT_NUM = "Arial"


def rgb(value: str) -> RGBColor:
    value = value.strip().lstrip("#")
    return RGBColor(int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def valid_hex(value: str) -> bool:
    v = value.strip().lstrip("#")
    return len(v) == 6 and all(c in "0123456789abcdefABCDEF" for c in v)


def add_shape(slide, shape_type, x, y, w, h, fill, line=None, line_width=0.7):
    shape = slide.shapes.add_shape(shape_type, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    shape.line.color.rgb = rgb(line or fill)
    shape.line.width = Pt(line_width)
    return shape


def add_text(slide, text, x, y, w, h, font_size=18, color="172033", bold=False,
             font_name="Microsoft YaHei", align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.TOP,
             margin=0.0, italic=False):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = Inches(margin)
    tf.margin_right = Inches(margin)
    tf.margin_top = Inches(margin)
    tf.margin_bottom = Inches(margin)
    tf.vertical_anchor = valign
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = str(text or "")
    run.font.name = font_name
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = rgb(color)
    return box


def add_bullets(slide, items, x, y, w, h, theme, font_name, font_size=17, numbered=False):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = Inches(0.02)
    tf.margin_right = Inches(0.02)
    for i, raw in enumerate(items[:8]):
        item = raw.get("body") or raw.get("text") or raw.get("title") if isinstance(raw, dict) else str(raw)
        prefix = f"{i+1:02d}  " if numbered else "•  "
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = prefix + str(item)
        p.font.name = font_name
        p.font.size = Pt(font_size)
        p.font.color.rgb = rgb(theme["text"])
        p.space_after = Pt(9)
        p.line_spacing = 1.12
    return box


def resolve_path(value: str | None, base: Path) -> Path | None:
    if not value:
        return None
    p = Path(value).expanduser()
    return p.resolve() if p.is_absolute() else (base / p).resolve()


def image_ratio(path: Path | None) -> float | None:
    if not path or not path.exists():
        return None
    try:
        with Image.open(path) as im:
            return im.width / max(im.height, 1)
    except Exception:
        return None


def add_picture_contain(slide, path: Path, x, y, w, h):
    with Image.open(path) as im:
        ratio = im.width / max(im.height, 1)
    box_ratio = w / h
    if ratio > box_ratio:
        pic_w, pic_h = w, w / ratio
        px, py = x, y + (h - pic_h) / 2
    else:
        pic_h, pic_w = h, h * ratio
        px, py = x + (w - pic_w) / 2, y
    return slide.shapes.add_picture(str(path), Inches(px), Inches(py), Inches(pic_w), Inches(pic_h))


def add_picture_cover(slide, path: Path, x, y, w, h):
    with Image.open(path) as im:
        iw, ih = im.width, im.height
    ratio, box_ratio = iw / max(ih, 1), w / h
    # Keep the PowerPoint shape exactly inside its visual slot. Cropping is
    # applied to the picture content, not by enlarging the shape beyond bounds.
    pic = slide.shapes.add_picture(str(path), Inches(x), Inches(y), Inches(w), Inches(h))
    if ratio > box_ratio:
        visible = box_ratio / ratio
        crop = max(0.0, (1 - visible) / 2)
        pic.crop_left = crop
        pic.crop_right = crop
    else:
        visible = ratio / box_ratio
        crop = max(0.0, (1 - visible) / 2)
        pic.crop_top = crop
        pic.crop_bottom = crop
    return pic


def add_visual_labels(slide, labels, theme, font_name, x, y, w, h):
    labels = [str(label).strip() for label in (labels or []) if str(label).strip()][:4]
    if not labels:
        return
    cols = 2 if len(labels) > 1 else 1
    rows = math.ceil(len(labels) / cols)
    gap = 0.12
    label_h = 0.42
    label_w = min(2.35, (w - gap * (cols + 1)) / cols)
    start_y = y + h - rows * (label_h + gap) - 0.06
    for i, label in enumerate(labels):
        col = i % cols
        row = i // cols
        lx = x + gap + col * (label_w + gap)
        ly = start_y + row * (label_h + gap)
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, lx, ly, label_w, label_h, theme["surface"], theme["accent"], 0.8)
        add_text(slide, label, lx + 0.08, ly + 0.08, label_w - 0.16, 0.24, 10.5, theme["primary"], True, font_name, PP_ALIGN.CENTER)


def is_template_strong(theme) -> bool:
    template = theme.get("_template_style") or {}
    return bool(template) and str(template.get("template_strength") or "").lower() == "strong"


def add_image_or_filler(slide, data, x, y, w, h, theme, font_name, base_dir, keyword=""):
    """Place a generated image when available, otherwise draw an on-brand filler.

    This guarantees the visual zone is never left blank: a real photograph takes
    priority, and a themed blue scene panel is the safe fallback.
    """
    img = resolve_path(data.get("image"), base_dir) if isinstance(data, dict) else None
    caption = ""
    if isinstance(data, dict):
        caption = data.get("image_caption") or data.get("visual_caption") or ""
    if img and img.exists():
        add_picture_cover(slide, img, x, y, w, h)
        return img
    if draw_filler is not None:
        draw_filler(slide, x, y, w, h, theme, keyword=keyword or "energy", caption=caption or "", font_name=font_name)
    else:
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, theme["soft"], theme["border"])
        add_text(slide, "示意图", x, y + h / 2 - 0.2, w, 0.4, 14, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    return None


def derive_keyword(data: dict[str, Any]) -> str:
    """Infer a filler/visual theme keyword from slide content."""
    blob = " ".join(str(data.get(k, "")) for k in ("title", "key_message", "body", "subtitle", "eyebrow"))
    for item in (data.get("items") or []):
        if isinstance(item, dict):
            blob += " " + str(item.get("title", "")) + " " + str(item.get("body", ""))
    return blob


def is_dify_template(theme) -> bool:
    template = theme.get("_template_style") or {}
    text = " ".join(str(x or "") for x in [theme.get("_style_id"), template.get("name"), template.get("source_pptx")]).lower()
    return theme.get("_decorative_mode") == "dify-blue" or "dify" in text or "工作流" in text


# Themes that should inherit the strong full-bleed blue panel treatment even
# though they are not the literal Dify reference (consulting-light is what an
# energy/data report actually resolves to, and it reads as a blue business
# deck). Routing them through the same branch fixes the pale-blue-dominant,
# image-sparse look while keeping each theme's own primary color.
BLUE_FAMILY = {"dify-workflow", "consulting-light", "academic-blue", "dashboard-light", "modern-blue"}


def use_blue_panels(theme) -> bool:
    template = theme.get("_template_style") or {}
    text = " ".join(str(x or "") for x in [theme.get("_style_id"), template.get("name"), template.get("source_pptx")]).lower()
    if theme.get("_decorative_mode") == "dify-blue" or "dify" in text or "工作流" in text:
        return True
    return theme.get("_theme_name") in BLUE_FAMILY


# Avoid repeating a single generic eyebrow ("概览") on every page. When the
# author left it generic we derive a type-appropriate label instead.
GENERIC_EYEBROWS = {"概览", "overview", "section", "内容", "章节", "contents",
                    "agenda", "highlights", "要点", "分析", "content", "summary"}
EYEBROW_BY_TYPE = {
    "agenda": "内容导航", "section": "章节", "statement": "核心观点",
    "content": "分析", "cards": "关键要点", "closing": "下一步", "image_feature": "图解",
    "process": "流程", "timeline": "时间线", "comparison": "对比", "matrix": "矩阵",
    "chart": "图表", "table": "数据表", "image_grid": "图集",
}


def eyebrow_for(data, stype, default):
    eb = str((data or {}).get("eyebrow") or "").strip()
    if eb and eb.lower() not in GENERIC_EYEBROWS:
        return eb
    return EYEBROW_BY_TYPE.get(stype, default)


def add_top_progress(slide, theme):
    x0 = 10.72
    for i, width in enumerate((0.36, 0.36, 0.36)):
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x0 + i * 0.46, 0.32, width, 0.12, theme["soft"], theme["border"], 0.3)
    add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x0 + 1.38, 0.32, 0.62, 0.12, theme["accent"], theme["accent"], 0.3)


def add_template_chrome(slide, theme, page_role="content"):
    if not use_blue_panels(theme):
        return
    # Dify reference pages use a bright white/blue canvas, small top-right
    # progress pills, and strong blue blocks on section/statement pages.
    add_top_progress(slide, theme)
    if page_role in {"section", "statement"}:
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.0, 0.0, 3.15, SLIDE_H, theme["primary"], theme["primary"])
        add_shape(slide, MSO_SHAPE.RECTANGLE, 3.15, 0.0, 0.08, SLIDE_H, theme["accent"], theme["accent"])
    elif page_role == "cover":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.68, 0.64, 0.08, 5.75, theme["accent"], theme["accent"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 10.35, 1.08, 1.55, 0.18, theme["soft"], theme["soft"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 10.72, 1.42, 0.98, 0.12, theme["accent"], theme["accent"])
    elif page_role == "chart":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.62, 1.22, 0.06, 5.35, theme["accent"], theme["accent"])
    else:
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.58, 1.36, 0.05, 5.0, theme["soft"], theme["soft"])


def new_slide(prs, theme):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = rgb(theme["background"])
    mode = theme.get("_decorative_mode", "quiet")
    # Decorations are intentionally subtle. They establish style identity without
    # turning every page into the same master template.
    if mode == "grid":
        for i in range(5):
            add_shape(slide, MSO_SHAPE.RECTANGLE, 9.05 + i * 0.72, 0.42, 0.015, 0.7, theme["border"], theme["border"], 0.2)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 9.05, 1.08, 3.55, 0.015, theme["border"], theme["border"], 0.2)
    elif mode == "editorial":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 12.92, 0.0, 0.12, 2.0, theme["accent"], theme["accent"])
        add_shape(slide, MSO_SHAPE.OVAL, 11.92, 6.45, 0.52, 0.52, theme["soft"], theme["soft"])
    elif mode == "dashboard":
        for x in (10.55, 11.18, 11.81):
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, 0.37, 0.44, 0.18, theme["soft"], theme["soft"])
    elif mode in ("friendly", "warm"):
        add_shape(slide, MSO_SHAPE.OVAL, 11.70, 0.10, 1.45, 1.45, theme["soft"], theme["soft"])
    elif mode == "dify-blue":
        add_top_progress(slide, theme)
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 11.76, 6.54, 0.52, 0.18, theme["soft"], theme["border"], 0.3)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.0, 0.0, 0.06, SLIDE_H, theme["accent"], theme["accent"])
        # bottom hairline reinforces the courseware frame
        add_shape(slide, MSO_SHAPE.RECTANGLE, MARGIN_X, 7.02, 12.1, 0.02, theme["border"], theme["border"], 0.2)
        # small brand mark, top-left
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, MARGIN_X, 0.32, 0.22, 0.22, theme["primary"], theme["primary"], 0.3)
    elif mode == "template":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 11.25, 0.35, 1.05, 0.16, theme["soft"], theme["soft"])
        add_shape(slide, MSO_SHAPE.RECTANGLE, MARGIN_X, 6.86, 2.3, 0.025, theme["border"], theme["border"], 0.3)
    elif mode == "pop":
        add_shape(slide, MSO_SHAPE.OVAL, 12.12, 0.4, 0.48, 0.48, theme["accent"], theme["accent"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 11.56, 6.86, 0.95, 0.12, theme["primary"], theme["primary"])
    elif mode == "tech":
        for x, y, d in ((11.95, 0.45, 0.35), (12.46, 0.86, 0.18), (11.72, 6.78, 0.26)):
            add_shape(slide, MSO_SHAPE.OVAL, x, y, d, d, theme["soft"], theme["border"])
    elif mode == "luxury":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.68, 0.48, 0.95, 0.025, theme["accent"], theme["accent"], 0.3)
    elif mode == "formal-red":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 12.93, 0, 0.11, SLIDE_H, theme["accent"], theme["accent"])
    return slide


def add_footer(slide, theme, font_name, source=None, page_no=None):
    footer_mode = theme.get("_footer_mode", "source-page")
    if source and footer_mode != "page-only":
        add_text(slide, f"来源：{source}", MARGIN_X, FOOTER_Y, 10.8, 0.18, 9.5, theme["muted"], False, font_name)
    if page_no is not None:
        add_text(slide, str(page_no), 12.18, FOOTER_Y, 0.55, 0.18, 9.5, theme["muted"], False, font_name, PP_ALIGN.RIGHT)


def add_header(slide, data, theme, font_name, page_no, variant="line", stype="content", render_title=True):
    title = data.get("title", "")
    key = data.get("key_message", "")
    if variant == "line":
        variant = theme.get("_header_variant", "hairline")
    # --- Blue family: one centralized eyebrow + progress; the builder owns the
    #     title and body (or asks the header to render the title via render_title).
    #     This guarantees a type-appropriate eyebrow on every blue slide and
    #     avoids the duplicate raw "概览" label the old dify branch could echo. ---
    if use_blue_panels(theme):
        add_top_progress(slide, theme)
        add_text(slide, str(eyebrow_for(data, stype, "OVERVIEW")).upper(), MARGIN_X, 0.28, 2.6, 0.22, 8.8, theme["accent"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, MARGIN_X, 0.56, 0.78, 0.035, theme["accent"], theme["accent"], 0.2)
        if render_title:
            size = 28 if len(str(title)) <= 28 else 24
            add_text(slide, title, MARGIN_X, 0.42, 11.8, 0.55, size, theme["text"], True, font_name)
            if key:
                add_text(slide, key, MARGIN_X, 1.05, 11.85, 0.3, 13.5, theme["primary"], True, font_name)
            add_footer(slide, theme, font_name, data.get("source"), page_no)
        return
    if variant == "sidebar":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 0.19, SLIDE_H, theme["primary"], theme["primary"])
    elif variant == "band":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, 0.78, theme["primary"], theme["primary"])
    elif variant == "consulting":
        add_shape(slide, MSO_SHAPE.RECTANGLE, MARGIN_X, 0.24, 11.95, 0.025, theme["border"], theme["border"], 0.3)
        add_text(slide, str(data.get("eyebrow") or "EXECUTIVE VIEW").upper(), 10.0, 0.34, 2.55, 0.22, 9.5, theme["muted"], True, font_name, PP_ALIGN.RIGHT)
    elif variant == "editorial":
        add_text(slide, str(data.get("eyebrow") or "FEATURE").upper(), MARGIN_X, 0.30, 2.4, 0.25, 10, theme["accent"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 3.08, 0.42, 9.45, 0.025, theme["border"], theme["border"], 0.3)
    elif variant == "dashboard":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, MARGIN_X, 0.31, 1.08, 0.29, theme["soft"], theme["soft"])
        add_text(slide, "OVERVIEW", MARGIN_X + 0.12, 0.37, 0.84, 0.13, 8.7, theme["primary"], True, font_name, PP_ALIGN.CENTER)
    elif variant == "minimal":
        pass
    elif variant == "friendly":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, MARGIN_X, 0.31, 0.55, 0.25, theme["accent"], theme["accent"])
    elif variant == "dark":
        add_shape(slide, MSO_SHAPE.RECTANGLE, MARGIN_X, 0.32, 11.95, 0.025, theme["border"], theme["border"], 0.3)
    else:
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, 0.07, theme["primary"], theme["primary"])
    if variant == "band":
        add_text(slide, title, MARGIN_X, 0.22, 11.7, 0.38, 26, theme["surface"], True, font_name)
        if key:
            add_text(slide, key, MARGIN_X, 0.93, 11.8, 0.35, 14, theme["primary"], True, font_name)
    else:
        top = 0.55 if variant in ("consulting", "editorial", "dashboard", "minimal", "friendly", "dark") else 0.42
        size = 28 if len(str(title)) <= 28 else 24
        add_text(slide, title, MARGIN_X, top, 11.8, 0.55, size, theme["text"], True, font_name)
        if key:
            add_text(slide, key, MARGIN_X, 1.05, 11.85, 0.3, 13.5, theme["primary"], True, font_name)
    add_footer(slide, theme, font_name, data.get("source"), page_no)


def choose_layout(data: dict[str, Any], idx: int, base_dir: Path, history: list[str]) -> str:
    requested = str(data.get("layout", "auto") or "auto")
    if requested != "auto":
        return requested
    stype = data.get("type", "content")
    items = data.get("items") or data.get("bullets") or []
    n = len(items)
    body_len = len(str(data.get("body", ""))) + sum(len(str(x)) for x in data.get("bullets", []))
    image = resolve_path(data.get("image"), base_dir)
    ratio = image_ratio(image)
    variants = {
        "cover": ["split", "minimal", "geometric", "image-panel" if image else "geometric"],
        "agenda": ["numbered", "roadmap"],
        "section": ["solid", "split-number"],
        "statement": ["centered", "split-accent", "editorial", "insight-rail", "poster"],
        "quote": ["centered", "side-mark", "poster"],
        "content": ["editorial", "sidebar", "two-column", "insight-rail", "number-focus" if data.get("value") else "editorial"],
        "text": ["editorial", "sidebar", "two-column", "insight-rail"],
        "cards": ["duo" if n <= 2 else "three-column" if n == 3 else "quad-grid" if n == 4 else "mosaic", "stripe", "staggered"],
        "summary": ["three-column" if n == 3 else "quad-grid" if n == 4 else "mosaic", "stripe"],
        "kpi": ["three-column" if n == 3 else "quad-grid", "stripe"],
        "process": ["horizontal" if n <= 5 else "vertical", "chevron" if n <= 4 else "vertical"],
        "timeline": ["horizontal" if n <= 5 else "vertical", "milestones"],
        "comparison": ["balanced", "versus", "asymmetric"],
        "matrix": ["quadrant", "grid"],
        "chart": ["chart-left", "chart-right", "chart-full", "chart-hero"],
        "table": ["full", "table-notes" if data.get("insights") else "full"],
        "image_feature": ["side-image" if ratio is None or ratio < 1.25 else "top-image", "image-left", "image-right"],
        "image_grid": ["gallery", "featured-grid"],
        "closing": ["action-cards", "minimal-next", "decision"],
    }
    candidates = list(variants.get(stype, variants["content"]))
    style_id = str(data.get("_style_id", "") or "")
    if style_id in STYLE_PRESETS:
        bias = style_profile(style_id).get("layout_bias", {}).get(stype, [])
        # Style bias leads, generic candidates remain as safety fallbacks.
        candidates = list(dict.fromkeys([*bias, *candidates]))
    # Content-aware preferences.
    if stype in ("content", "text") and body_len > 260:
        preferred = ["two-column", "sidebar", "editorial"]
        candidates = list(dict.fromkeys([*preferred, *candidates]))
    if stype == "image_feature" and ratio and ratio > 1.6:
        preferred = ["top-image", "image-left", "image-right"]
        candidates = list(dict.fromkeys([*preferred, *candidates]))
    # Stable but content-sensitive rotation. The same deck does not collapse into
    # a single layout, while reruns with the same content remain deterministic.
    seed = idx + n * 3 + body_len // 90
    choice = candidates[seed % len(candidates)]
    if len(history) >= 2 and history[-1] == history[-2] == choice and len(candidates) > 1:
        choice = candidates[(candidates.index(choice) + 1) % len(candidates)]
    return choice


def add_cover(prs, data, deck, theme, font_name, layout, base_dir):
    slide = new_slide(prs, theme)
    title = data.get("title") or deck.get("title") or "演示文稿"
    subtitle = data.get("subtitle") or deck.get("subtitle") or ""
    meta = "  ·  ".join(x for x in [deck.get("author", ""), deck.get("date", "")] if x)
    img = resolve_path(data.get("image"), base_dir)
    if use_blue_panels(theme):
        add_text(slide, str(deck.get("mode", "PRESENTATION")).upper(), 0.95, 0.95, 3.1, 0.28, 11, theme["accent"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.97, 1.34, 0.85, 0.05, theme["accent"], theme["accent"], 0.2)
        add_text(slide, title, 0.93, 1.62, 7.05, 2.05, 35 if len(title) < 18 else 28, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 0.95, 4.12, 6.9, 0.95, 15.5, theme["muted"], False, font_name)
        add_text(slide, meta, 0.95, 6.5, 6.4, 0.28, 11, theme["muted"], False, font_name)
        # RIGHT hero visual panel: real image when present, else themed filler.
        rx, ry, rw, rh = 8.35, 1.0, 4.32, 5.5
        add_image_or_filler(slide, data, rx, ry, rw, rh, theme, font_name, base_dir, keyword=title or "workflow")
        add_text(slide, "WORKFLOW", rx + 0.3, ry + 0.22, rw - 0.6, 0.26, 10.5, theme["surface"], True, font_name)
        labels = ["INPUT", "WORKFLOW", "OUTPUT"]
        for i, label in enumerate(labels):
            bx = rx + 0.55 + (i % 2) * 1.72
            by = ry + 1.0 + i * 1.18
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, bx, by, 1.82, 0.72, theme["surface"], theme["accent"], 0.9)
            add_text(slide, label, bx + 0.16, by + 0.24, 1.5, 0.16, 9.5, theme["primary"], True, font_name, PP_ALIGN.CENTER)
        add_shape(slide, MSO_SHAPE.CHEVRON, rx + 2.45, ry + 1.7, 0.62, 0.38, theme["primary"], theme["primary"])
        add_shape(slide, MSO_SHAPE.CHEVRON, rx + 0.55, ry + 2.9, 0.62, 0.38, theme["primary"], theme["primary"])
        return slide
    if layout in ("typographic", "dashboard-cover", "dark-hero"):
        label = str(deck.get("mode", "PRESENTATION")).upper()
        add_text(slide, label, 0.82, 0.74, 3.2, 0.32, 12, theme["accent"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.82, 1.22, 1.42, 0.06, theme["accent"], theme["accent"])
        add_text(slide, title, 0.82, 1.62, 11.4, 2.05, 47 if len(title) < 19 else 37, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 0.86, 4.12, 8.6, 0.72, 17, theme["muted"], False, font_name)
        if layout == "dashboard-cover":
            for i, text in enumerate(("OVERVIEW", "EVIDENCE", "ACTION")):
                x = 0.86 + i * 2.55
                add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, 5.62, 2.25, 0.72, theme["surface"], theme["border"])
                add_text(slide, text, x + 0.18, 5.84, 1.9, 0.2, 10, theme["primary"], True, font_name)
        else:
            add_text(slide, meta, 0.86, 6.48, 9.2, 0.28, 11, theme["muted"], False, font_name)
    elif layout in ("consulting", "editorial-cover"):
        panel = theme["primary"] if layout == "editorial-cover" else theme["soft"]
        panel_text = theme["surface"] if layout == "editorial-cover" else theme["primary"]
        add_shape(slide, MSO_SHAPE.RECTANGLE, 9.15, 0, 4.18, SLIDE_H, panel, panel)
        add_text(slide, "01", 9.62, 0.72, 2.7, 1.05, 50, theme["accent"], True, font_name)
        add_text(slide, str(deck.get("mode", "PRESENTATION")).upper(), 9.62, 2.02, 2.9, 0.32, 11, panel_text, True, font_name)
        add_text(slide, title, 0.82, 1.52, 7.75, 2.05, 41 if len(title) < 22 else 33, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.82, 3.92, 2.2, 0.07, theme["accent"], theme["accent"])
        add_text(slide, subtitle, 0.86, 4.35, 7.3, 0.78, 17, theme["muted"], False, font_name)
        add_text(slide, meta, 0.86, 6.48, 7.3, 0.28, 11, theme["muted"], False, font_name)
    elif layout == "minimal":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.72, 0.75, 0.12, 5.85, theme["accent"], theme["accent"])
        add_text(slide, title, 1.18, 1.38, 10.9, 1.7, 42 if len(title) < 22 else 34, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 1.22, 3.35, 9.8, 0.75, 18, theme["muted"], False, font_name)
        add_text(slide, meta, 1.22, 6.45, 9.8, 0.28, 11, theme["muted"], False, font_name)
    elif layout == "geometric":
        add_shape(slide, MSO_SHAPE.OVAL, 8.72, 0.08, 4.45, 4.45, theme["soft"], theme["soft"])
        add_shape(slide, MSO_SHAPE.OVAL, 10.3, 3.8, 2.6, 2.6, theme["accent"], theme["accent"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 8.1, 4.8, 2.0, 1.2, theme["primary"], theme["primary"])
        add_text(slide, title, 0.9, 1.25, 7.7, 1.75, 40 if len(title) < 22 else 32, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 0.94, 3.35, 7.0, 0.8, 18, theme["muted"], False, font_name)
        add_text(slide, meta, 0.94, 6.45, 7.0, 0.28, 11, theme["muted"], False, font_name)
    elif layout == "image-panel" and img and img.exists():
        add_picture_cover(slide, img, 0, 0, 6.2, SLIDE_H)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 6.15, 0, 0.16, SLIDE_H, theme["accent"], theme["accent"])
        add_text(slide, title, 6.85, 1.4, 5.7, 1.8, 37 if len(title) < 22 else 31, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 6.88, 3.6, 5.2, 0.9, 17, theme["muted"], False, font_name)
        add_text(slide, meta, 6.88, 6.45, 5.2, 0.28, 11, theme["muted"], False, font_name)
    else:  # split
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 4.15, SLIDE_H, theme["primary"], theme["primary"])
        add_shape(slide, MSO_SHAPE.RECTANGLE, 4.15, 0, 0.13, SLIDE_H, theme["accent"], theme["accent"])
        add_text(slide, str(deck.get("mode", "PRESENTATION")).upper(), 0.65, 0.75, 2.8, 0.45, 14, theme["surface"], True, font_name)
        for i in range(5):
            h = 0.45 + (i % 3) * 0.32
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.68 + i * 0.57, 5.85 - h, 0.28, h, theme["surface"], theme["surface"])
        add_text(slide, title, 4.95, 1.4, 7.25, 1.75, 38 if len(title) < 22 else 31, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, subtitle, 4.98, 3.6, 6.8, 0.8, 18, theme["muted"], False, font_name)
        add_text(slide, meta, 4.98, 6.45, 6.8, 0.28, 11, theme["muted"], False, font_name)
    return slide


def add_agenda(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "content")
        add_text(slide, str(eyebrow_for(data, "agenda", "AGENDA")).upper(), 0.95, 0.7, 3.0, 0.26, 10, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "内容导航"), 0.92, 1.05, 11.2, 0.6, 26, theme["text"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.95, 1.78, 1.1, 0.05, theme["accent"], theme["accent"], 0.2)
        items = (data.get("items") or data.get("bullets") or [])[:5]
        n = max(1, len(items))
        y0, rh = 2.12, min(0.92, 4.35 / n)
        for i, item in enumerate(items):
            y = y0 + i * (rh + 0.12)
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.95, y, 6.55, rh, theme["surface"], theme["border"])
            add_text(slide, f"{i+1:02d}", 1.2, y + 0.12, 0.9, 0.4, 18, theme["accent"], True, FONT_NUM)
            title = item.get("title", "") if isinstance(item, dict) else str(item)
            body = item.get("body", "") if isinstance(item, dict) else ""
            add_text(slide, title, 2.1, y + 0.12, 5.2, 0.36, 16, theme["text"], True, font_name)
            if body:
                add_text(slide, body, 2.1, y + 0.5, 5.2, 0.32, 12, theme["muted"], False, font_name)
        add_image_or_filler(slide, data, 7.9, 2.1, 4.7, 4.4, theme, font_name, base_dir, keyword="agenda 导航 流程 内容")
        add_footer(slide, theme, font_name, data.get("source"), page_no)
        return slide
    add_header(slide, data, theme, font_name, page_no, "line", stype="agenda")
    items = data.get("items") or data.get("bullets") or []
    if layout == "roadmap":
        y = 3.55
        add_shape(slide, MSO_SHAPE.RECTANGLE, 1.0, y, 11.3, 0.05, theme["border"], theme["border"])
        n = max(1, min(len(items), 6))
        for i, item in enumerate(items[:6]):
            x = 1.05 + i * (11.15 / max(n - 1, 1))
            add_shape(slide, MSO_SHAPE.OVAL, x - 0.22, y - 0.22, 0.44, 0.44, theme["primary"] if i == 0 else theme["surface"], theme["primary"])
            add_text(slide, f"{i+1:02d}", x - 0.35, 2.55 if i % 2 == 0 else 4.05, 0.7, 0.32, 13, theme["accent"], True, font_name, PP_ALIGN.CENTER)
            text = item.get("title", "") if isinstance(item, dict) else str(item)
            add_text(slide, text, x - 0.82, 2.9 if i % 2 == 0 else 4.42, 1.64, 0.75, 15, theme["text"], True, font_name, PP_ALIGN.CENTER)
    else:
        n = max(1, min(len(items), 6))
        card_h = min(0.83, 4.8 / n)
        for i, item in enumerate(items[:6]):
            y = 1.65 + i * (card_h + 0.12)
            add_text(slide, f"{i+1:02d}", 0.9, y + 0.04, 0.7, 0.4, 21, theme["accent"], True, font_name)
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 1.75, y, 10.65, card_h, theme["surface"], theme["border"])
            title = item.get("title", "") if isinstance(item, dict) else str(item)
            body = item.get("body", "") if isinstance(item, dict) else ""
            add_text(slide, title, 2.02, y + 0.12, 4.15, 0.34, 17, theme["text"], True, font_name)
            if body:
                add_text(slide, body, 6.25, y + 0.12, 5.75, 0.38, 13, theme["muted"], False, font_name)
    return slide


def add_section(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    if use_blue_panels(theme):
        add_top_progress(slide, theme)
        # Full-bleed navy band on the left third for a strong blue identity.
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 4.55, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, data.get("number", f"{page_no:02d}"), 0.8, 0.7, 2.8, 1.1, 52, theme["surface"], True, FONT_NUM)
        add_text(slide, str(eyebrow_for(data, "section", "SECTION")).upper(), 0.8, 2.12, 3.4, 0.32, 12, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "章节"), 0.76, 2.55, 3.55, 1.85, 33, theme["surface"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        sub = data.get("subtitle") or data.get("key_message", "")
        if sub:
            add_text(slide, sub, 0.78, 4.45, 3.35, 0.95, 14, theme["surface"], False, font_name)
        # Right visual panel: real image when present, else strong-blue filler.
        add_image_or_filler(slide, data, 4.95, 0.9, 7.6, 5.7, theme, font_name, base_dir, keyword=data.get("title", "section"))
        return slide
    if layout == "split-number":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 4.4, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, data.get("number", f"{page_no:02d}"), 0.8, 1.1, 2.8, 1.3, 58, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "章节"), 5.1, 2.25, 7.3, 1.1, 38, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, data.get("subtitle") or data.get("key_message", ""), 5.15, 3.65, 6.6, 0.75, 17, theme["muted"], False, font_name)
    else:
        slide.background.fill.fore_color.rgb = rgb(theme["primary"])
        add_text(slide, data.get("number", f"{page_no:02d}"), 0.75, 0.75, 2.0, 0.8, 44, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "章节"), 0.75, 2.35, 11.5, 1.1, 39, theme["surface"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, data.get("subtitle") or data.get("key_message", ""), 0.78, 3.75, 10.5, 0.7, 17, theme["surface"], False, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.78, 5.9, 2.0, 0.08, theme["accent"], theme["accent"])
    return slide


def add_statement(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    statement = data.get("key_message") or data.get("statement") or data.get("title", "")
    body = data.get("body", "")
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "statement")
        add_text(slide, str(eyebrow_for(data, "statement", "KEY INSIGHT")).upper(), 0.8, 0.95, 2.2, 0.26, 10, theme["accent"], True, font_name)
        add_text(slide, statement, 4.12, 1.7, 7.7, 2.0, 30 if len(statement) < 38 else 25, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, body, 4.16, 3.95, 7.7, 0.9, 14.5, theme["muted"], False, font_name)
        # Fill the lower band so the page never reads as empty.
        add_image_or_filler(slide, data, 4.12, 5.1, 8.48, 1.55, theme, font_name, base_dir, keyword=statement)
        add_footer(slide, theme, font_name, data.get("source"), page_no)
        return slide
    if layout == "insight-rail":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.76, 1.18, 0.11, 4.9, theme["accent"], theme["accent"])
        add_text(slide, str(data.get("eyebrow") or "KEY INSIGHT").upper(), 1.16, 1.18, 2.7, 0.36, 12, theme["primary"], True, font_name)
        add_text(slide, statement, 1.16, 1.75, 10.8, 2.45, 37 if len(statement) < 34 else 29, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, body, 6.8, 4.75, 5.2, 0.95, 15.5, theme["muted"], False, font_name, PP_ALIGN.RIGHT)
    elif layout == "poster":
        add_text(slide, str(data.get("eyebrow") or "POINT OF VIEW").upper(), 0.78, 0.7, 3.2, 0.34, 11, theme["accent"], True, font_name)
        add_text(slide, statement, 0.78, 1.4, 11.7, 3.35, 42 if len(statement) < 28 else 32, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 10.85, 5.25, 1.55, 0.12, theme["accent"], theme["accent"])
        add_text(slide, body, 0.82, 5.32, 8.6, 0.9, 15.5, theme["muted"], False, font_name)
    elif layout == "split-accent":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 4.35, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, data.get("eyebrow", "核心观点"), 0.72, 0.95, 2.5, 0.42, 14, theme["accent"], True, font_name)
        add_text(slide, statement, 4.95, 1.55, 7.3, 2.25, 34 if len(statement) < 36 else 28, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, body, 4.98, 4.35, 6.9, 1.0, 17, theme["muted"], False, font_name)
    elif layout == "editorial":
        add_text(slide, data.get("title", "观点"), 0.75, 0.65, 3.5, 0.42, 14, theme["primary"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.75, 1.3, 2.2, 0.08, theme["accent"], theme["accent"])
        add_text(slide, statement, 0.78, 1.72, 11.6, 2.65, 38 if len(statement) < 32 else 30, theme["text"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, body, 7.25, 5.3, 5.1, 0.85, 16, theme["muted"], False, font_name, PP_ALIGN.RIGHT)
    else:
        add_shape(slide, MSO_SHAPE.OVAL, 0.75, 0.75, 1.05, 1.05, theme["soft"], theme["soft"])
        add_text(slide, "“", 0.96, 0.75, 0.65, 0.7, 32, theme["primary"], True, font_name, PP_ALIGN.CENTER)
        add_text(slide, statement, 1.15, 2.05, 11.0, 2.1, 38 if len(statement) < 32 else 30, theme["text"], True, font_name, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
        add_text(slide, body, 2.15, 4.65, 9.0, 0.9, 16.5, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    add_footer(slide, theme, font_name, data.get("source"), page_no)
    return slide


def add_content(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "sidebar" if layout == "sidebar" else "line", stype="content", render_title=False)
    bullets = data.get("bullets") or data.get("items") or []
    body = data.get("body", "")
    value = data.get("value", "")
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "content")
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.0, 0.0, 0.16, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, data.get("title", ""), 0.92, 1.05, 11.2, 0.6, 26, theme["text"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.95, 1.78, 1.1, 0.05, theme["accent"], theme["accent"], 0.2)
        card_x, card_y, card_w, card_h = 0.95, 2.1, 6.6, 4.4
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, card_x, card_y, card_w, card_h, theme["surface"], theme["border"])
        if bullets:
            add_bullets(slide, bullets, card_x + 0.3, card_y + 0.35, card_w - 0.6, card_h - 0.6, theme, font_name, 15.5)
        elif body:
            add_text(slide, body, card_x + 0.3, card_y + 0.3, card_w - 0.6, card_h - 0.6, 16, theme["text"], False, font_name, valign=MSO_ANCHOR.TOP)
        else:
            add_text(slide, data.get("key_message", ""), card_x + 0.3, card_y + 0.3, card_w - 0.6, card_h - 0.6, 15, theme["muted"], False, font_name)
        add_image_or_filler(slide, data, 7.9, 2.1, 4.7, 4.4, theme, font_name, base_dir, keyword=derive_keyword(data))
        add_footer(slide, theme, font_name, data.get("source"), page_no)
        return slide
    if layout == "insight-rail":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.78, 1.66, 4.25, 4.84, theme["soft"], theme["soft"])
        add_text(slide, str(data.get("side_title") or "核心判断"), 1.08, 1.98, 3.55, 0.42, 16, theme["primary"], True, font_name)
        add_text(slide, body or data.get("key_message", ""), 1.08, 2.65, 3.55, 2.65, 21, theme["text"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 5.48, 1.82, 0.055, 4.25, theme["accent"], theme["accent"])
        add_bullets(slide, bullets, 5.92, 1.86, 6.05, 4.35, theme, font_name, 16.5)
    elif layout == "two-column":
        left = data.get("left") or {"title": data.get("left_title", "重点一"), "items": bullets[::2]}
        right = data.get("right") or {"title": data.get("right_title", "重点二"), "items": bullets[1::2]}
        for x, side, fill in [(0.75, left, theme["surface"]), (6.85, right, theme["soft2"])]:
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, 1.62, 5.72, 4.95, fill, theme["border"])
            add_text(slide, side.get("title", ""), x + 0.3, 1.95, 5.1, 0.45, 19, theme["text"], True, font_name)
            add_bullets(slide, side.get("items", []), x + 0.3, 2.6, 5.1, 3.55, theme, font_name, 16)
    elif layout == "number-focus" and value:
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.78, 1.7, 4.25, 4.65, theme["primary"], theme["primary"])
        add_text(slide, value, 1.1, 2.45, 3.62, 1.35, 48, theme["surface"], True, font_name, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
        add_text(slide, data.get("value_label", "关键数字"), 1.1, 4.05, 3.62, 0.5, 16, theme["accent"], True, font_name, PP_ALIGN.CENTER)
        add_bullets(slide, bullets, 5.7, 2.0, 6.3, 3.9, theme, font_name, 17)
    elif layout == "sidebar":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.8, 1.66, 3.15, 4.8, theme["soft"], theme["soft"])
        add_text(slide, data.get("side_title", "核心信息"), 1.1, 2.05, 2.55, 0.45, 18, theme["primary"], True, font_name)
        add_text(slide, body or data.get("key_message", ""), 1.1, 2.7, 2.55, 2.7, 18, theme["text"], True, font_name)
        add_bullets(slide, bullets, 4.55, 1.85, 7.55, 4.45, theme, font_name, 17)
    else:  # editorial
        if body:
            add_text(slide, body, 0.82, 1.78, 4.2, 4.5, 20, theme["text"], True, font_name)
            add_shape(slide, MSO_SHAPE.RECTANGLE, 5.35, 1.83, 0.05, 4.25, theme["accent"], theme["accent"])
            add_bullets(slide, bullets, 5.8, 1.82, 6.25, 4.45, theme, font_name, 16.5)
        else:
            add_bullets(slide, bullets, 1.0, 1.75, 11.2, 4.65, theme, font_name, 18)
    return slide


def add_cards(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "band" if layout == "mosaic" else "line", stype="cards", render_title=False)
    items = (data.get("items") or [])[:6]
    n = max(1, len(items))
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "content")
        add_text(slide, data.get("title", ""), 0.92, 1.05, 11.2, 0.6, 26, theme["text"], True, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.95, 1.78, 1.1, 0.05, theme["accent"], theme["accent"], 0.2)
        if n <= 1:
            item = items[0] if items else {}
            card_x, card_y, card_w, card_h = 0.95, 2.1, 6.7, 4.45
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, card_x, card_y, card_w, card_h, theme["surface"], theme["border"])
            marker = item.get("value") or "01"
            add_text(slide, marker, card_x + 0.32, card_y + 0.28, 1.6, 0.55, 30, theme["accent"], True, font_name)
            add_text(slide, item.get("title", ""), card_x + 0.32, card_y + 1.05, card_w - 0.64, 0.7, 19, theme["text"], True, font_name)
            add_text(slide, item.get("body") or item.get("detail", ""), card_x + 0.32, card_y + 1.85, card_w - 0.64, 2.2, 15, theme["muted"], False, font_name, valign=MSO_ANCHOR.TOP)
            add_image_or_filler(slide, data, 7.95, 2.1, 4.65, 4.45, theme, font_name, base_dir, keyword=derive_keyword(data))
        else:
            cols = 3 if n >= 3 else n
            rows = math.ceil(n / cols)
            card_w = (12.1 - 0.3 * (cols - 1)) / cols
            card_h = (4.75 - 0.3 * (rows - 1)) / rows
            for i, item in enumerate(items):
                x = 0.9 + (i % cols) * (card_w + 0.3)
                y = 2.0 + (i // cols) * (card_h + 0.3)
                fill = theme["surface"] if i % 2 == 0 else theme["soft2"]
                add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, card_w, card_h, fill, theme["border"])
                marker = item.get("value") or f"{i+1:02d}"
                add_text(slide, marker, x + 0.24, y + 0.22, 1.0, 0.34, 16, theme["accent"], True, font_name)
                add_text(slide, item.get("title", ""), x + 0.24, y + 0.72, card_w - 0.48, 0.42, 15.5, theme["text"], True, font_name)
                add_text(slide, item.get("body") or item.get("detail", ""), x + 0.24, y + 1.2, card_w - 0.48, max(0.4, card_h - 1.4), 12.5, theme["muted"], False, font_name)
        add_footer(slide, theme, font_name, data.get("source"), page_no)
        return slide
    if layout == "stripe":
        positions = [(0.78, 1.62 + i * (4.9 / max(n, 1)), 11.75, min(0.9, 4.5 / max(n, 1))) for i in range(n)]
    elif layout == "staggered":
        if n <= 3:
            positions = [(0.78 + i * 4.05, 1.72 + (0.34 if i % 2 else 0), 3.75, 4.25) for i in range(n)]
        else:
            positions = [(0.78 + (i % 3) * 4.05, 1.62 + (i // 3) * 2.43 + (0.16 if i % 2 else 0), 3.75, 2.05) for i in range(n)]
    elif layout == "duo":
        positions = [(0.78, 1.75, 5.8, 4.75), (6.75, 1.75, 5.8, 4.75)]
    elif layout == "three-column":
        positions = [(0.73 + i * 4.15, 1.75, 3.9, 4.75) for i in range(min(n, 3))]
    elif layout == "quad-grid":
        positions = [(0.76 + (i % 2) * 6.08, 1.7 + (i // 2) * 2.45, 5.75, 2.18) for i in range(min(n, 4))]
    else:  # mosaic
        positions = []
        widths = [4.05, 3.72, 4.05, 3.72, 4.05, 3.72]
        for i in range(n):
            row, col = i // 3, i % 3
            positions.append((0.72 + col * 4.2, 1.62 + row * 2.5, widths[i], 2.15))
    for i, (item, pos) in enumerate(zip(items, positions)):
        x, y, w, h = pos
        fill = theme["surface"] if i % 2 == 0 else theme["soft2"]
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, fill, theme["border"])
        marker = item.get("value") or f"{i+1:02d}"
        if layout == "stripe":
            add_text(slide, marker, x + 0.22, y + 0.18, 0.82, 0.32, 15, theme["accent"], True, font_name)
            add_text(slide, item.get("title", ""), x + 1.12, y + 0.16, 3.2, 0.34, 16.5, theme["text"], True, font_name)
            add_text(slide, item.get("body") or item.get("detail", ""), x + 4.42, y + 0.16, w - 4.7, 0.4, 13.2, theme["muted"], False, font_name)
        else:
            add_text(slide, marker, x + 0.25, y + 0.2, min(1.25, w - 0.5), 0.42, 18, theme["accent"], True, font_name)
            add_text(slide, item.get("title", ""), x + 0.25, y + 0.78, w - 0.5, 0.58, 18, theme["text"], True, font_name)
            body_h = max(0.45, h - 1.6)
            add_text(slide, item.get("body") or item.get("detail", ""), x + 0.25, y + 1.42, w - 0.5, body_h, 14.5, theme["muted"], False, font_name)
    return slide


def add_process(prs, data, theme, font_name, page_no, layout):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="process")
    items = (data.get("items") or [])[:7]
    n = max(1, len(items))
    if layout in ("horizontal", "chevron") and n <= 5:
        gap = 0.17
        w = (11.75 - gap * (n - 1)) / n
        for i, item in enumerate(items):
            x = 0.78 + i * (w + gap)
            if layout == "chevron":
                shape = MSO_SHAPE.CHEVRON
                fill = theme["soft"] if i % 2 == 0 else theme["surface"]
            else:
                shape = MSO_SHAPE.ROUNDED_RECTANGLE
                fill = theme["surface"]
            add_shape(slide, shape, x, 2.0, w, 3.9, fill, theme["border"])
            add_text(slide, f"{i+1:02d}", x + 0.2, 2.28, w - 0.4, 0.4, 18, theme["accent"], True, font_name)
            add_text(slide, item.get("title", ""), x + 0.2, 3.02, w - 0.4, 0.7, 17, theme["text"], True, font_name)
            add_text(slide, item.get("body", ""), x + 0.2, 4.02, w - 0.4, 1.3, 13.5, theme["muted"], False, font_name)
    else:
        for i, item in enumerate(items[:6]):
            y = 1.62 + i * 0.84
            add_shape(slide, MSO_SHAPE.OVAL, 0.9, y, 0.52, 0.52, theme["primary"], theme["primary"])
            add_text(slide, str(i + 1), 1.02, y + 0.08, 0.28, 0.22, 13, theme["surface"], True, font_name, PP_ALIGN.CENTER)
            add_text(slide, item.get("title", ""), 1.72, y - 0.02, 3.15, 0.42, 17, theme["text"], True, font_name)
            add_text(slide, item.get("body", ""), 4.85, y - 0.02, 7.1, 0.55, 14.5, theme["muted"], False, font_name)
            if i < len(items[:6]) - 1:
                add_shape(slide, MSO_SHAPE.RECTANGLE, 1.14, y + 0.53, 0.04, 0.31, theme["border"], theme["border"])
    return slide


def add_timeline(prs, data, theme, font_name, page_no, layout):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="timeline")
    items = (data.get("items") or [])[:8]
    n = max(1, len(items))
    if layout in ("horizontal", "milestones") and n <= 6:
        y = 3.68
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0.95, y, 11.4, 0.05, theme["border"], theme["border"])
        for i, item in enumerate(items):
            x = 1.0 + i * (11.25 / max(n - 1, 1))
            add_shape(slide, MSO_SHAPE.OVAL, x - 0.21, y - 0.21, 0.42, 0.42, theme["primary"], theme["primary"])
            above = i % 2 == 0
            add_text(slide, item.get("time", str(i + 1)), x - 0.65, 2.18 if above else 4.08, 1.3, 0.34, 14, theme["accent"], True, font_name, PP_ALIGN.CENTER)
            add_text(slide, item.get("title", ""), x - 0.9, 2.55 if above else 4.45, 1.8, 0.52, 15.5, theme["text"], True, font_name, PP_ALIGN.CENTER)
            add_text(slide, item.get("body", ""), x - 0.95, 3.03 if above else 4.96, 1.9, 0.8, 12.5, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    else:
        add_shape(slide, MSO_SHAPE.RECTANGLE, 2.2, 1.75, 0.06, 4.55, theme["border"], theme["border"])
        for i, item in enumerate(items[:6]):
            y = 1.72 + i * 0.78
            add_shape(slide, MSO_SHAPE.OVAL, 1.98, y + 0.08, 0.5, 0.5, theme["primary"], theme["primary"])
            add_text(slide, item.get("time", str(i + 1)), 0.78, y + 0.04, 0.95, 0.4, 14, theme["accent"], True, font_name, PP_ALIGN.RIGHT)
            add_text(slide, item.get("title", ""), 2.8, y, 3.0, 0.4, 17, theme["text"], True, font_name)
            add_text(slide, item.get("body", ""), 5.7, y, 6.2, 0.52, 14.5, theme["muted"], False, font_name)
    return slide


def add_comparison(prs, data, theme, font_name, page_no, layout):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "band" if layout == "versus" else "line", stype="comparison")
    left = data.get("left") or {"title": "左侧", "items": []}
    right = data.get("right") or {"title": "右侧", "items": []}
    if layout == "versus":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.78, 1.65, 5.45, 4.9, theme["surface"], theme["border"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 7.1, 1.65, 5.45, 4.9, theme["soft"], theme["border"])
        add_shape(slide, MSO_SHAPE.OVAL, 6.17, 3.35, 1.0, 1.0, theme["accent"], theme["accent"])
        add_text(slide, "VS", 6.34, 3.65, 0.66, 0.25, 15, theme["surface"], True, font_name, PP_ALIGN.CENTER)
        boxes = [(0.78, left), (7.1, right)]
    elif layout == "asymmetric":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.78, 1.65, 4.15, 4.9, theme["primary"], theme["primary"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 5.25, 1.65, 7.3, 4.9, theme["surface"], theme["border"])
        boxes = [(0.78, left), (5.25, right)]
    else:
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.78, 1.65, 5.75, 4.9, theme["surface"], theme["border"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 6.8, 1.65, 5.75, 4.9, theme["soft2"], theme["border"])
        boxes = [(0.78, left), (6.8, right)]
    for i, (x, side) in enumerate(boxes):
        w = 4.15 if layout == "asymmetric" and i == 0 else 7.3 if layout == "asymmetric" else 5.45 if layout == "versus" else 5.75
        inverted = layout == "asymmetric" and i == 0
        color = theme["surface"] if inverted else theme["text"]
        muted = theme["surface"] if inverted else theme["muted"]
        add_text(slide, side.get("title", ""), x + 0.3, 1.98, w - 0.6, 0.5, 20, color, True, font_name)
        add_bullets(slide, side.get("items", []), x + 0.3, 2.75, w - 0.6, 3.35, {**theme, "text": muted}, font_name, 16)
    return slide


def add_matrix(prs, data, theme, font_name, page_no, layout):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="matrix")
    items = data.get("items") or []
    x0, y0, w, h = 2.1, 1.72, 9.55, 4.85
    add_shape(slide, MSO_SHAPE.RECTANGLE, x0, y0, w, h, theme["surface"], theme["border"])
    add_shape(slide, MSO_SHAPE.RECTANGLE, x0 + w / 2, y0, 0.04, h, theme["border"], theme["border"])
    add_shape(slide, MSO_SHAPE.RECTANGLE, x0, y0 + h / 2, w, 0.04, theme["border"], theme["border"])
    labels = data.get("quadrants") or ["高价值 / 高可行", "高价值 / 低可行", "低价值 / 高可行", "低价值 / 低可行"]
    coords = [(x0 + 0.22, y0 + 0.18), (x0 + w/2 + 0.24, y0 + 0.18), (x0 + 0.22, y0 + h/2 + 0.18), (x0 + w/2 + 0.24, y0 + h/2 + 0.18)]
    for i, (label, (x, y)) in enumerate(zip(labels, coords)):
        add_text(slide, label, x, y, w/2 - 0.48, 0.34, 14, theme["primary"], True, font_name)
        bucket = [it for it in items if int(it.get("quadrant", 1)) == i + 1][:4]
        add_bullets(slide, [it.get("title", "") for it in bucket], x, y + 0.5, w/2 - 0.5, 1.48, theme, font_name, 14)
    add_text(slide, data.get("x_label", "可行性 →"), x0 + 3.8, 6.65, 2.0, 0.25, 11, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    add_text(slide, data.get("y_label", "价值 ↑"), 0.7, 3.65, 1.0, 0.25, 11, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    return slide


def numeric_values(values: list[Any]) -> list[float]:
    result: list[float] = []
    for value in values:
        try:
            result.append(float(value))
        except Exception:
            result.append(0.0)
    return result


def add_native_chart(slide, chart_data_spec: dict[str, Any], x, y, w, h, theme, font_name) -> bool:
    if not isinstance(chart_data_spec, dict) or not chart_data_spec:
        return False
    kind = str(chart_data_spec.get("kind") or chart_data_spec.get("type") or "").lower()
    series_specs = chart_data_spec.get("series") or []
    if not isinstance(series_specs, list) or not series_specs:
        return False
    try:
        if kind == "scatter":
            x_values = numeric_values(chart_data_spec.get("x_values") or [])
            if not x_values:
                return False
            data = XyChartData()
            for spec in series_specs[:3]:
                y_values = numeric_values(spec.get("values") or [])
                xy_series = data.add_series(str(spec.get("name") or "series"))
                for xv, yv in zip(x_values, y_values):
                    xy_series.add_data_point(xv, yv)
            chart_type = XL_CHART_TYPE.XY_SCATTER
        else:
            categories = chart_data_spec.get("categories") or []
            if not categories:
                return False
            category_limit = 36 if kind == "line" else 20 if kind in {"bar", "column", "histogram"} else 12
            data = ChartData()
            data.categories = [str(c) for c in categories[:category_limit]]
            for spec in series_specs[:4]:
                values = numeric_values((spec.get("values") or [])[:category_limit])
                data.add_series(str(spec.get("name") or "series"), values)
            chart_type = {
                "line": XL_CHART_TYPE.LINE_MARKERS,
                "pie": XL_CHART_TYPE.DOUGHNUT,
                "donut": XL_CHART_TYPE.DOUGHNUT,
                "bar": XL_CHART_TYPE.COLUMN_CLUSTERED,
                "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
                "histogram": XL_CHART_TYPE.COLUMN_CLUSTERED,
            }.get(kind, XL_CHART_TYPE.COLUMN_CLUSTERED)
        frame = slide.shapes.add_chart(chart_type, Inches(x), Inches(y), Inches(w), Inches(h), data)
        chart = frame.chart
        chart.has_title = False
        chart.has_legend = kind in {"pie", "donut"} or len(series_specs) > 1
        if chart.has_legend:
            chart.legend.position = XL_LEGEND_POSITION.RIGHT
            chart.legend.include_in_layout = False
        palette = [theme["primary"], theme["accent"], theme["positive"], theme["negative"], theme["muted"]]
        for i, series in enumerate(chart.series):
            color = rgb(palette[i % len(palette)])
            try:
                series.format.fill.solid()
                series.format.fill.fore_color.rgb = color
            except Exception:
                pass
            try:
                series.format.line.color.rgb = color
                series.format.line.width = Pt(2.25)
            except Exception:
                pass
        try:
            if kind in {"bar", "column", "pie", "donut"}:
                plot = chart.plots[0]
                plot.has_data_labels = True
                plot.data_labels.font.name = font_name
                plot.data_labels.font.size = Pt(9)
                plot.data_labels.font.color.rgb = rgb(theme["text"])
                plot.data_labels.show_value = True
                all_values = [abs(float(v)) for spec in series_specs for v in (spec.get("values") or []) if isinstance(v, (int, float))]
                max_value = max(all_values) if all_values else 0.0
                plot.data_labels.number_format = "0.0000" if 0 < max_value < 2 else "#,##0" if max_value >= 1000 else "0.0"
                if kind in {"pie", "donut"}:
                    plot.data_labels.show_percentage = True
                    plot.data_labels.show_category_name = True
        except Exception:
            pass
        try:
            chart.category_axis.tick_labels.font.size = Pt(9)
            chart.category_axis.tick_labels.font.name = font_name
            chart.category_axis.tick_labels.font.color.rgb = rgb(theme["muted"])
            chart.value_axis.tick_labels.font.size = Pt(9)
            chart.value_axis.tick_labels.font.name = font_name
            chart.value_axis.tick_labels.font.color.rgb = rgb(theme["muted"])
            chart.value_axis.has_major_gridlines = True
            chart.value_axis.major_gridlines.format.line.color.rgb = rgb(theme["border"])
            if kind == "line" and len(chart_data_spec.get("categories") or []) > 15:
                chart.category_axis.tick_label_skip = max(2, len(chart_data_spec.get("categories") or []) // 8)
        except Exception:
            pass
        return True
    except Exception:
        return False


def add_chart_visual(slide, data, img: Path | None, x, y, w, h, theme, font_name, base_dir: Path) -> None:
    chart_data = data.get("chart_data") or {}
    if add_native_chart(slide, chart_data, x, y, w, h, theme, font_name):
        return
    if img and img.exists():
        add_picture_contain(slide, img, x, y, w, h)
    elif draw_filler is not None:
        draw_filler(slide, x, y, w, h, theme, keyword="data 图表 趋势 指标", caption="", font_name=font_name)
    else:
        add_text(slide, "图表数据不可用", x + 0.2, y + h / 2 - 0.2, w - 0.4, 0.4, 17, theme["muted"], False, font_name, PP_ALIGN.CENTER)


def add_chart(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="chart")
    img = resolve_path(data.get("image"), base_dir)
    insights = data.get("insights") or data.get("bullets") or []
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "chart")
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.95, 1.58, 7.62, 4.75, theme["surface"], theme["border"])
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 8.88, 1.58, 3.42, 4.75, theme["soft2"], theme["soft2"])
        add_text(slide, data.get("insight_title", "关键解读"), 9.18, 1.92, 2.75, 0.35, 15, theme["primary"], True, font_name)
        add_chart_visual(slide, data, img, 1.18, 1.84, 7.15, 4.18, theme, font_name, base_dir)
        add_bullets(slide, insights, 9.18, 2.58, 2.78, 3.2, theme, font_name, 12.8)
        return slide
    if layout == "chart-hero":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.72, 1.55, 11.9, 4.15, theme["surface"], theme["border"])
        add_chart_visual(slide, data, img, 0.95, 1.72, 11.45, 3.75, theme, font_name, base_dir)
        for i, insight in enumerate(insights[:3]):
            x = 0.78 + i * 4.02
            add_text(slide, f"{i+1:02d}", x, 5.98, 0.55, 0.28, 12, theme["accent"], True, font_name)
            add_text(slide, insight, x + 0.62, 5.94, 3.15, 0.52, 12.8, theme["text"], True, font_name)
    elif layout == "chart-full":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.72, 1.55, 11.9, 5.15, theme["surface"], theme["border"])
        add_chart_visual(slide, data, img, 0.95, 1.72, 11.45, 4.75, theme, font_name, base_dir)
    else:
        chart_left = layout != "chart-right"
        ix = 0.72 if chart_left else 5.18
        tx = 8.48 if chart_left else 0.78
        iw = 7.42
        tw = 4.05
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, ix, 1.62, iw, 4.95, theme["surface"], theme["border"])
        add_chart_visual(slide, data, img, ix + 0.18, 1.82, iw - 0.36, 4.55, theme, font_name, base_dir)
        add_text(slide, data.get("insight_title", "关键解读"), tx, 1.85, tw, 0.45, 18, theme["primary"], True, font_name)
        add_bullets(slide, insights, tx, 2.55, tw, 3.55, theme, font_name, 15.5)
    return slide


def add_table_slide(prs, data, theme, font_name, page_no, layout):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="table")
    columns = data.get("columns") or []
    rows = data.get("rows") or []
    insights = data.get("insights") or []
    table_w = 8.7 if layout == "table-notes" else 11.75
    x = 0.72
    y = 1.62
    table_shape = slide.shapes.add_table(max(1, len(rows) + 1), max(1, len(columns)), Inches(x), Inches(y), Inches(table_w), Inches(4.95))
    table = table_shape.table
    if columns:
        for j, value in enumerate(columns):
            cell = table.cell(0, j)
            cell.text = str(value)
            cell.fill.solid(); cell.fill.fore_color.rgb = rgb(theme["primary"])
            p = cell.text_frame.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
            for run in p.runs:
                run.font.name = font_name; run.font.size = Pt(13); run.font.bold = True; run.font.color.rgb = rgb(theme["surface"])
    for i, row in enumerate(rows[:8], 1):
        for j, value in enumerate(row[:len(columns)]):
            cell = table.cell(i, j)
            cell.text = str(value)
            cell.fill.solid(); cell.fill.fore_color.rgb = rgb(theme["surface"] if i % 2 else theme["soft2"])
            p = cell.text_frame.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
            for run in p.runs:
                run.font.name = font_name; run.font.size = Pt(12.5); run.font.color.rgb = rgb(theme["text"])
    if layout == "table-notes":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 9.7, 1.62, 2.9, 4.95, theme["soft"], theme["soft"])
        add_text(slide, "重点说明", 10.0, 1.98, 2.3, 0.4, 17, theme["primary"], True, font_name)
        add_bullets(slide, insights, 10.0, 2.58, 2.25, 3.4, theme, font_name, 14)
    return slide


def add_image_feature(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="image_feature")
    img = resolve_path(data.get("image"), base_dir)
    body = data.get("body", "")
    bullets = data.get("bullets") or []
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "content")
        add_image_or_filler(slide, data, 0.95, 1.56, 7.4, 4.9, theme, font_name, base_dir, keyword=derive_keyword(data))
        add_visual_labels(slide, data.get("visual_labels"), theme, font_name, 1.08, 1.7, 7.14, 4.6)
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 8.72, 1.56, 3.55, 4.9, theme["soft2"], theme["soft2"])
        add_text(slide, body, 9.05, 2.0, 2.9, 1.28, 18, theme["text"], True, font_name)
        add_bullets(slide, bullets, 9.05, 3.55, 2.85, 2.15, theme, font_name, 12.8)
        return slide
    if layout == "top-image":
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.72, 1.55, 11.9, 3.45, theme["surface"], theme["border"])
        if img and img.exists():
            add_picture_cover(slide, img, 0.82, 1.65, 11.7, 3.25)
            add_visual_labels(slide, data.get("visual_labels"), theme, font_name, 0.82, 1.65, 11.7, 3.25)
        add_text(slide, body, 0.82, 5.35, 5.4, 1.0, 17, theme["text"], True, font_name)
        add_bullets(slide, bullets, 6.5, 5.25, 5.55, 1.25, theme, font_name, 14.5)
    else:
        image_left = layout in ("side-image", "image-left")
        ix, tx = (0.72, 7.15) if image_left else (7.2, 0.78)
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, ix, 1.58, 5.45, 4.95, theme["surface"], theme["border"])
        if img and img.exists():
            add_picture_cover(slide, img, ix + 0.1, 1.68, 5.25, 4.75)
            add_visual_labels(slide, data.get("visual_labels"), theme, font_name, ix + 0.1, 1.68, 5.25, 4.75)
        add_text(slide, body, tx, 2.05, 5.55, 1.5, 20, theme["text"], True, font_name)
        add_bullets(slide, bullets, tx, 3.85, 5.45, 2.2, theme, font_name, 15.5)
    return slide


def add_image_grid(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    add_header(slide, data, theme, font_name, page_no, "line", stype="image_grid")
    images = data.get("images") or []
    captions = data.get("captions") or []
    if use_blue_panels(theme):
        add_template_chrome(slide, theme, "content")
        n = min(len(images), 6)
        if n == 0:
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 0.92, 1.66, 11.45, 4.72, theme["surface"], theme["border"])
            if draw_filler is not None:
                draw_filler(slide, 1.0, 1.74, 11.29, 4.56, theme, keyword="image", caption="", font_name=font_name)
            return slide
        cols = 3 if n > 2 else n
        rows = math.ceil(n / max(cols, 1))
        cell_w = (11.45 - 0.24 * (cols - 1)) / max(cols, 1)
        cell_h = (4.72 - 0.24 * (rows - 1)) / max(rows, 1)
        for i in range(n):
            x = 0.92 + (i % cols) * (cell_w + 0.24)
            y = 1.66 + (i // cols) * (cell_h + 0.24)
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, cell_w, cell_h, theme["surface"], theme["border"])
            path = resolve_path(images[i], base_dir)
            cap_h = 0.42 if i < len(captions) and captions[i] else 0.1
            if path and path.exists():
                add_picture_cover(slide, path, x + 0.08, y + 0.08, cell_w - 0.16, cell_h - cap_h - 0.08)
            else:
                kw = captions[i] if i < len(captions) and captions[i] else "image"
                if draw_filler is not None:
                    draw_filler(slide, x + 0.08, y + 0.08, cell_w - 0.16, cell_h - cap_h - 0.08, theme, keyword=kw, caption="", font_name=font_name)
            if i < len(captions) and captions[i]:
                add_text(slide, captions[i], x + 0.12, y + cell_h - 0.32, cell_w - 0.24, 0.22, 10.5, theme["muted"], False, font_name, PP_ALIGN.CENTER)
        return slide
    if layout == "featured-grid" and images:
        positions = [(0.72, 1.58, 6.4, 4.95), (7.35, 1.58, 2.55, 2.35), (10.05, 1.58, 2.55, 2.35), (7.35, 4.18, 2.55, 2.35), (10.05, 4.18, 2.55, 2.35)]
    else:
        n = max(1, min(len(images), 6)); cols = 3 if n > 4 else 2; rows = math.ceil(n / cols)
        cell_w = (11.85 - 0.24 * (cols - 1)) / cols; cell_h = (4.95 - 0.24 * (rows - 1)) / rows
        positions = [(0.72 + (i % cols) * (cell_w + 0.24), 1.58 + (i // cols) * (cell_h + 0.24), cell_w, cell_h) for i in range(n)]
    for i, pos in enumerate(positions[:len(images)]):
        x, y, w, h = pos
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, theme["surface"], theme["border"])
        path = resolve_path(images[i], base_dir)
        cap_h = 0.48 if i < len(captions) and captions[i] else 0.12
        if path and path.exists(): add_picture_cover(slide, path, x + 0.08, y + 0.08, w - 0.16, h - cap_h - 0.1)
        if i < len(captions) and captions[i]: add_text(slide, captions[i], x + 0.12, y + h - 0.38, w - 0.24, 0.25, 11.5, theme["muted"], False, font_name, PP_ALIGN.CENTER)
    return slide


def add_closing(prs, data, theme, font_name, page_no, layout, base_dir):
    slide = new_slide(prs, theme)
    items = (data.get("items") or [])[:4]
    if use_blue_panels(theme):
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 3.6, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, str(eyebrow_for(data, "closing", "NEXT MOVES")).upper(), 0.7, 1.5, 2.5, 0.3, 12, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "下一步行动"), 0.7, 2.1, 2.7, 1.6, 32, theme["surface"], True, font_name, valign=MSO_ANCHOR.MIDDLE)
        n = max(1, len(items))
        if n <= 2:
            for i, item in enumerate(items[:2]):
                y = 1.75 + i * 2.45
                add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, 4.1, y, 4.0, 2.05, theme["surface"], theme["border"])
                add_text(slide, f"{i+1:02d}", 4.35, y + 0.22, 1.0, 0.34, 16, theme["accent"], True, FONT_NUM)
                add_text(slide, item.get("title", ""), 4.35, y + 0.7, 3.5, 0.5, 16, theme["text"], True, font_name)
                add_text(slide, item.get("body", ""), 4.35, y + 1.25, 3.5, 0.7, 12.5, theme["muted"], False, font_name)
            add_image_or_filler(slide, data, 8.55, 1.75, 3.95, 4.35, theme, font_name, base_dir, keyword="action 行动 建议 流程")
        else:
            cols, rows = 2, math.ceil(n / 2)
            cw = (8.7 - 0.25 * (cols - 1)) / cols
            ch = (4.4 - 0.25 * (rows - 1)) / rows
            for i, item in enumerate(items):
                x = 4.1 + (i % cols) * (cw + 0.25)
                y = 1.7 + (i // cols) * (ch + 0.25)
                add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, cw, ch, theme["surface"], theme["border"])
                add_text(slide, f"{i+1:02d}", x + 0.25, y + 0.18, 1.0, 0.32, 15, theme["accent"], True, FONT_NUM)
                add_text(slide, item.get("title", ""), x + 0.25, y + 0.62, cw - 0.5, 0.5, 15.5, theme["text"], True, font_name)
                add_text(slide, item.get("body", ""), x + 0.25, y + 1.12, cw - 0.5, 0.9, 12.5, theme["muted"], False, font_name)
        add_footer(slide, theme, font_name, data.get("source"), page_no)
        return slide
    if layout == "decision":
        add_text(slide, str(eyebrow_for(data, "closing", "NEXT MOVES")).upper(), 0.78, 0.72, 3.0, 0.3, 11, theme["accent"], True, font_name)
        add_text(slide, data.get("title", "下一步行动"), 0.78, 1.22, 6.15, 0.82, 36, theme["text"], True, font_name)
        add_text(slide, "把结论转成明确动作、责任和节奏。", 0.82, 2.32, 5.35, 0.68, 17, theme["muted"], False, font_name)
        add_shape(slide, MSO_SHAPE.RECTANGLE, 6.55, 0.88, 0.06, 5.65, theme["accent"], theme["accent"])
        for i, item in enumerate(items):
            y = 1.08 + i * 1.33
            add_text(slide, f"{i+1:02d}", 7.0, y, 0.62, 0.34, 15, theme["accent"], True, FONT_NUM)
            add_text(slide, item.get("title", ""), 7.72, y - 0.02, 4.5, 0.42, 17, theme["text"], True, font_name)
            add_text(slide, item.get("body", ""), 7.72, y + 0.44, 4.55, 0.54, 13.5, theme["muted"], False, font_name)
        add_footer(slide, theme, font_name, data.get("source"), page_no)
    elif layout == "minimal-next":
        add_shape(slide, MSO_SHAPE.RECTANGLE, 0, 0, 4.1, SLIDE_H, theme["primary"], theme["primary"])
        add_text(slide, data.get("title", "下一步"), 4.8, 1.2, 7.4, 0.8, 36, theme["text"], True, font_name)
        add_bullets(slide, [f"{it.get('title','')}：{it.get('body','')}" for it in items], 4.85, 2.45, 7.0, 3.2, theme, font_name, 17, numbered=True)
        add_text(slide, data.get("footer", "THANK YOU"), 4.85, 6.35, 5.2, 0.4, 13, theme["accent"], True, font_name)
    else:
        add_header(slide, data, theme, font_name, page_no, "band", stype="closing")
        n = max(1, len(items)); gap = 0.18; w = (11.8 - gap * (n - 1)) / n
        for i, item in enumerate(items):
            x = 0.75 + i * (w + gap)
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, 1.72, w, 4.72, theme["surface"] if i % 2 == 0 else theme["soft2"], theme["border"])
            add_text(slide, f"{i+1:02d}", x + 0.22, 1.98, w - 0.44, 0.4, 18, theme["accent"], True, FONT_NUM)
            add_text(slide, item.get("title", ""), x + 0.22, 2.72, w - 0.44, 0.62, 18, theme["text"], True, font_name)
            add_text(slide, item.get("body", ""), x + 0.22, 3.62, w - 0.44, 1.45, 14.5, theme["muted"], False, font_name)
            meta = " / ".join(v for v in [item.get("owner", ""), item.get("timing", "")] if v)
            if meta:
                add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x + 0.22, 5.55, w - 0.44, 0.44, theme["soft"], theme["soft"])
                add_text(slide, meta, x + 0.3, 5.66, w - 0.6, 0.2, 10.5, theme["primary"], True, font_name)
    return slide


def load_theme(deck: dict[str, Any]) -> tuple[dict[str, str], str]:
    cfg = deck.get("theme") or {}
    style_id = "clean-professional"
    if isinstance(cfg, dict):
        style_id = str(cfg.get("visual_style") or cfg.get("style_id") or style_id)
    profile = style_profile(style_id)
    name = cfg.get("name", profile.get("theme_name", "modern-blue")) if isinstance(cfg, dict) else str(cfg)
    theme = dict(THEMES.get(name, THEMES.get(profile.get("theme_name", "modern-blue"), THEMES["modern-blue"])))
    theme["_theme_name"] = name
    font_name = "Microsoft YaHei"
    if isinstance(cfg, dict):
        for key, value in (cfg.get("custom_colors") or {}).items():
            if key in theme and isinstance(value, str) and valid_hex(value):
                theme[key] = value.strip().lstrip("#").upper()
        font_name = cfg.get("font_cn") or font_name
    template_style = cfg.get("template_style") if isinstance(cfg, dict) else {}
    theme["_style_id"] = style_id
    theme["_header_variant"] = (cfg.get("header_variant") if isinstance(cfg, dict) else None) or profile.get("header_variant", "hairline")
    theme["_footer_mode"] = (cfg.get("footer_mode") if isinstance(cfg, dict) else None) or profile.get("footer_mode", "source-page")
    theme["_decorative_mode"] = (cfg.get("decorative_mode") if isinstance(cfg, dict) else None) or profile.get("decorative_mode", "quiet")
    theme["_density"] = (cfg.get("density") if isinstance(cfg, dict) else None) or profile.get("density", "balanced")
    theme["_template_style"] = template_style if isinstance(template_style, dict) else {}
    if is_dify_template(theme):
        theme.update({
            "primary": "0040C0",
            "accent": "2E86FF",
            "background": "F5F8FF",
            "surface": "FFFFFF",
            "soft": "E8F0FF",
            "soft2": "F1F6FF",
            "border": "D8E6FA",
        })
        theme["_decorative_mode"] = "dify-blue"
        theme["_header_variant"] = "dify"
    return theme, font_name


def remove_last_slide(prs: Presentation) -> None:
    """Remove a partially rendered last slide using python-pptx internals."""
    if not prs.slides:
        return
    slide_id = prs.slides._sldIdLst[-1]  # type: ignore[attr-defined]
    rel_id = slide_id.rId
    prs.part.drop_rel(rel_id)
    del prs.slides._sldIdLst[-1]  # type: ignore[attr-defined]


def render_slide(prs, stype, data, deck, theme, font_name, idx, layout, base_dir):
    if stype == "cover": return add_cover(prs, data, deck, theme, font_name, layout, base_dir)
    if stype == "agenda": return add_agenda(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "section": return add_section(prs, data, theme, font_name, idx, layout, base_dir)
    if stype in ("statement", "quote"): return add_statement(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "content": return add_content(prs, data, theme, font_name, idx, layout, base_dir)
    if stype in ("cards", "summary"): return add_cards(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "process": return add_process(prs, data, theme, font_name, idx, layout)
    if stype == "timeline": return add_timeline(prs, data, theme, font_name, idx, layout)
    if stype == "comparison": return add_comparison(prs, data, theme, font_name, idx, layout)
    if stype == "matrix": return add_matrix(prs, data, theme, font_name, idx, layout)
    if stype == "chart": return add_chart(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "table": return add_table_slide(prs, data, theme, font_name, idx, layout)
    if stype == "image_feature": return add_image_feature(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "image_grid": return add_image_grid(prs, data, theme, font_name, idx, layout, base_dir)
    if stype == "closing": return add_closing(prs, data, theme, font_name, idx, layout, base_dir)
    return add_content(prs, data, theme, font_name, idx, layout)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build adaptive PowerPoint from deck_spec.json")
    parser.add_argument("--spec", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    spec_path = Path(args.spec).expanduser().resolve()
    deck = json.loads(spec_path.read_text(encoding="utf-8"))
    theme, font_name = load_theme(deck)
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W)
    prs.slide_height = Inches(SLIDE_H)
    prs.core_properties.title = deck.get("title", "演示文稿")
    prs.core_properties.subject = deck.get("subtitle", "")
    prs.core_properties.author = deck.get("author", "")
    prs.core_properties.comments = "Generated by Adaptive Presentation Studio"

    slides = deck.get("slides") or [{"type": "cover", "layout": "auto", "title": deck.get("title", "演示文稿"), "subtitle": deck.get("subtitle", "")}]
    history: list[str] = []
    render_issues: list[dict[str, Any]] = []
    for idx, data in enumerate(slides, 1):
        stype = data.get("type", "content")
        if stype == "text": stype = "content"
        if stype == "kpi": stype = "cards"
        layout = choose_layout({**data, "type": stype, "_style_id": theme.get("_style_id")}, idx, spec_path.parent, history)
        history.append(layout)
        before = len(prs.slides)
        try:
            render_slide(prs, stype, data, deck, theme, font_name, idx, layout, spec_path.parent)
        except Exception as exc:
            while len(prs.slides) > before:
                remove_last_slide(prs)
            render_issues.append({
                "slide": idx, "type": stype, "layout": layout,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(limit=3),
                "recovery": "已改用兼容文字页，原页面需人工核对。",
            })
            fallback = {
                "type": "content", "title": data.get("title") or f"第 {idx} 页内容",
                "body": data.get("key_message") or data.get("body") or "本页原版式未能渲染，已保留可读取的主要内容。",
                "bullets": data.get("bullets") or data.get("insights") or [],
                "source": data.get("source") or "自动兼容恢复",
            }
            add_content(prs, fallback, theme, font_name, idx, "editorial", spec_path.parent)

    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)
    render_report = {
        "status": "review" if render_issues else "pass",
        "slide_count": len(prs.slides),
        "fallback_slide_count": len(render_issues),
        "issues": render_issues,
    }
    output.with_suffix(".render_report.json").write_text(json.dumps(render_report, ensure_ascii=False, indent=2), encoding="utf-8")
    if render_issues:
        print(f"已完成生成，其中 {len(render_issues)} 页使用兼容布局；请查看 render_report.json。")
    print(str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
