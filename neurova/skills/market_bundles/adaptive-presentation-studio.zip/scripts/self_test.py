#!/usr/bin/env python3
"""Comprehensive offline regression tests for reliability and recovery."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw


def run(command: list[str], timeout: int = 420, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False, cwd=cwd)


def check(name: str, passed: bool, details=None) -> dict[str, object]:
    return {"name": name, "pass": bool(passed), "details": details}


def main() -> int:
    parser = argparse.ArgumentParser(description="Run comprehensive local regression tests")
    parser.add_argument("--outdir", default="")
    args = parser.parse_args()

    root = Path(args.outdir).resolve() if args.outdir else Path(tempfile.mkdtemp(prefix="adaptive-ppt-v3-test-"))
    if root.exists() and args.outdir:
        shutil.rmtree(root)
    root.mkdir(parents=True, exist_ok=True)
    inputs = root / "inputs"
    inputs.mkdir()

    (inputs / "brief.md").write_text(
        "# 项目目标\n本项目需要在三个月内完成培训内容升级，并形成统一交付标准。\n"
        "# 实施路径\n第一阶段梳理资料；第二阶段开发课件；第三阶段试讲复盘。\n"
        "# 风险与应对\n资料口径不一致，需要指定负责人核对来源。\n"
        "# 下一步行动\n明确负责人、完成时间和验收标准。\n",
        encoding="utf-8",
    )
    csv_text = "月份,渠道,销售额,转化率\n1月,线上,120,12%\n2月,线下,150,14%\n3月,线上,180,16%\n4月,线下,210,18%\n"
    (inputs / "utf8_bom.csv").write_text(csv_text, encoding="utf-8-sig")
    (inputs / "gb18030.csv").write_bytes(csv_text.encode("gb18030"))
    (inputs / "malformed.csv").write_text('name,value\nA,1\nB,"2\nC,3,extra\nD,4\n', encoding="utf-8")
    (inputs / "corrupt.xlsx").write_bytes(b"not a real excel zip")
    (inputs / "long.txt").write_text("长文内容。" * 10000, encoding="utf-8")

    # Create an image-only PDF to verify the scanned-PDF boundary is explicit.
    image = Image.new("RGB", (800, 1100), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((80, 100, 720, 1000), outline="black", width=4)
    image.save(inputs / "scanned.pdf", "PDF", resolution=100.0)

    script_dir = Path(__file__).resolve().parent
    checks: list[dict[str, object]] = []

    analysis_dir = root / "analysis_all"
    analyze = run([
        sys.executable, str(script_dir / "analyze_materials.py"),
        "--inputs", str(inputs), "--outdir", str(analysis_dir), "--max-rows", "10000",
    ])
    checks.append(check("analysis_command", analyze.returncode == 0, analyze.stderr[-1000:]))
    analysis_path = analysis_dir / "analysis.json"
    analysis = json.loads(analysis_path.read_text(encoding="utf-8")) if analysis_path.exists() else {}
    files = {f.get("name"): f for f in analysis.get("input_files", [])}
    checks.append(check("utf8_bom_csv", files.get("utf8_bom.csv", {}).get("status") in {"ok", "partial"}))
    checks.append(check("gb18030_csv", files.get("gb18030.csv", {}).get("status") in {"ok", "partial"}))
    checks.append(check("malformed_csv_tolerant", files.get("malformed.csv", {}).get("status") == "partial"))
    corrupt_codes = {d.get("code") for d in files.get("corrupt.xlsx", {}).get("diagnostics", [])}
    checks.append(check("corrupt_office_diagnostic", "OFFICE_FILE_CORRUPT" in corrupt_codes, sorted(corrupt_codes)))
    scan_codes = {d.get("code") for d in files.get("scanned.pdf", {}).get("diagnostics", [])}
    checks.append(check("scanned_pdf_boundary", "PDF_TEXT_EMPTY" in scan_codes, sorted(scan_codes)))
    long_codes = {d.get("code") for d in files.get("long.txt", {}).get("diagnostics", [])}
    checks.append(check("long_text_boundary", "TEXT_TRUNCATED" in long_codes, sorted(long_codes)))
    all_diags = analysis.get("diagnostics", [])
    checks.append(check("plain_language_diagnostics", all(d.get("user_title") and d.get("user_message") and d.get("steps") for d in all_diags), all_diags[:2]))
    checks.append(check("capability_boundaries", len(analysis.get("capability_boundaries") or []) >= 5))
    checks.append(check("analysis_user_summary", (analysis_dir / "资料读取说明.md").exists()))

    pipeline_dir = root / "pipeline"
    pipeline_cmd = [
        sys.executable, str(script_dir / "run_pipeline.py"),
        "--inputs", str(inputs / "brief.md"), str(inputs / "utf8_bom.csv"),
        "--outdir", str(pipeline_dir), "--title", "通用资料演示回归测试", "--filename", "回归测试.pptx",
        "--audience", "管理层", "--purpose", "汇报决策", "--target-pages", "12",
    ]
    pipeline = run(pipeline_cmd, timeout=600)
    checks.append(check("pipeline_command", pipeline.returncode == 0, (pipeline.stdout + pipeline.stderr)[-1500:]))
    required = [
        pipeline_dir / "analysis" / "analysis.json",
        pipeline_dir / "deck_spec.json",
        pipeline_dir / "image_plan.json",
        pipeline_dir / "content_review.json",
        pipeline_dir / "回归测试.pptx",
        pipeline_dir / "回归测试.render_report.json",
        pipeline_dir / "validation.json",
        pipeline_dir / "pipeline_report.json",
        pipeline_dir / "运行摘要.md",
        pipeline_dir / "内容审校说明.md",
        pipeline_dir / "版式检查说明.md",
    ]
    checks.append(check("pipeline_outputs", all(x.exists() and x.stat().st_size > 0 for x in required), [str(x) for x in required if not x.exists()]))
    validation = json.loads((pipeline_dir / "validation.json").read_text(encoding="utf-8")) if (pipeline_dir / "validation.json").exists() else {}
    checks.append(check("ppt_validation", validation.get("status") in {"pass", "review"} and validation.get("error_count", 1) == 0, validation.get("issues", [])[:5]))
    spec = json.loads((pipeline_dir / "deck_spec.json").read_text(encoding="utf-8")) if (pipeline_dir / "deck_spec.json").exists() else {}
    checks.append(check("audience_purpose_planning", spec.get("audience") == "管理层" and spec.get("purpose") == "汇报决策"))
    theme_cfg = spec.get("theme") or {}
    checks.append(check("visual_style_selected", theme_cfg.get("visual_style") in {
        "clean-professional", "executive-consulting", "editorial-magazine", "data-dashboard",
        "academic-research", "training-friendly", "brand-pop", "minimal-keynote",
        "dark-tech", "warm-storytelling", "premium-luxury", "china-red"
    }, theme_cfg))
    checks.append(check("style_metadata_present", bool(theme_cfg.get("header_variant")) and bool(theme_cfg.get("decorative_mode")), theme_cfg))
    checks.append(check("source_coverage_present", "source_coverage" in (spec.get("provenance") or {})))
    visual_plan = json.loads((pipeline_dir / "image_plan.json").read_text(encoding="utf-8")) if (pipeline_dir / "image_plan.json").exists() else {}
    visual_items = visual_plan.get("items") or []
    checks.append(check("visual_plan_generated", visual_plan.get("provider") == "host-imagegen" and len(visual_items) >= 1, visual_plan))
    checks.append(check("visual_prompts_complete", all(x.get("prompt") and x.get("aspect_ratio") and x.get("expected_filename") for x in visual_items), visual_items[:2]))

    # Second run should resume rather than redo completed stages.
    pipeline2 = run(pipeline_cmd, timeout=300)
    report2 = json.loads((pipeline_dir / "pipeline_report.json").read_text(encoding="utf-8")) if (pipeline_dir / "pipeline_report.json").exists() else {}
    stage_statuses = [x.get("status") for x in report2.get("stages", [])]
    checks.append(check("resume_second_run", pipeline2.returncode == 0 and stage_statuses.count("skipped") >= 4, stage_statuses))

    # Simulate one host-generated image, then verify automatic binding and editable labels.
    visual_assets = pipeline_dir / "visual_assets"
    visual_assets.mkdir(exist_ok=True)
    expected_visual = visual_items[0].get("expected_filename") if visual_items else "slide-02-conceptual_illustration.png"
    generated = Image.new("RGB", (1536, 960), "#EAF3FF")
    generated_draw = ImageDraw.Draw(generated)
    generated_draw.rectangle((180, 180, 1350, 780), fill="#1677FF", outline="#0B57D0", width=8)
    generated.save(visual_assets / expected_visual)
    visual_pipeline = run(pipeline_cmd, timeout=600)
    applied_spec = json.loads((pipeline_dir / "deck_spec.json").read_text(encoding="utf-8")) if (pipeline_dir / "deck_spec.json").exists() else {}
    applied_plan = json.loads((pipeline_dir / "image_plan.json").read_text(encoding="utf-8")) if (pipeline_dir / "image_plan.json").exists() else {}
    applied_slides = [s for s in applied_spec.get("slides") or [] if s.get("visual_asset")]
    checks.append(check("visual_asset_binding", visual_pipeline.returncode == 0 and applied_plan.get("applied_count", 0) >= 1 and bool(applied_slides), applied_plan))
    checks.append(check("native_visual_labels", bool(applied_slides) and isinstance(applied_slides[0].get("visual_labels"), list), applied_slides[:1]))

    # Quick-start accepts only file names and creates a complete result.
    quick_dir = root / "quick"
    quick = run([
        sys.executable, str(script_dir / "quick_start.py"), str(inputs / "brief.md"), str(inputs / "utf8_bom.csv"),
        "--title", "快速启动测试", "--outdir", str(quick_dir), "--pages", "10",
    ], timeout=600)
    checks.append(check("quick_start", quick.returncode == 0 and (quick_dir / "快速启动测试.pptx").exists(), (quick.stdout + quick.stderr)[-1200:]))

    # Repair a deliberately unsafe spec without crashing.
    broken_spec = root / "broken_spec.json"
    broken_spec.write_text(json.dumps({
        "title": "修复测试", "theme": {"name": "modern-blue"},
        "slides": [
            {"type": "cover", "title": "修复测试"},
            {"type": "unknown_type", "title": "异常页面", "body": "内容" * 500, "image": "missing.png"},
            {"type": "closing", "title": "下一步", "items": [{"title": "行动", "body": "完成验证"}]},
        ],
    }, ensure_ascii=False), encoding="utf-8")
    repair = run([sys.executable, str(script_dir / "repair_spec.py"), "--spec", str(broken_spec), "--aggressive"])
    repaired = json.loads(broken_spec.read_text(encoding="utf-8"))
    checks.append(check("spec_auto_repair", repair.returncode == 0 and repaired["slides"][1]["type"] == "content" and len(repaired["slides"][1]["body"]) <= 180))

    # Package check must include the newly added scripts and docs.
    for cache in script_dir.parent.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    package_report = root / "package_check.json"
    pkg = run([sys.executable, str(script_dir / "package_check.py"), "--root", str(script_dir.parent), "--report", str(package_report)])
    pkg_data = json.loads(package_report.read_text(encoding="utf-8")) if package_report.exists() else {}
    checks.append(check("package_check", pkg.returncode == 0 and pkg_data.get("status") == "pass", pkg_data.get("issues", [])))

    passed = sum(1 for c in checks if c.get("pass"))
    report = {
        "status": "pass" if passed == len(checks) else "fail",
        "passed": passed,
        "total": len(checks),
        "pass_rate_pct": round(passed / max(1, len(checks)) * 100, 1),
        "checks": checks,
        "artifacts": str(root),
    }
    report_path = root / "self_test_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(report_path))
    return 0 if report["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
