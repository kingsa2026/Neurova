#!/usr/bin/env python3
"""Plan slide visuals and bind host-generated assets to deck_spec.json."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
ELIGIBLE_TYPES = {"cover", "section", "agenda", "statement", "content", "cards", "process", "timeline", "comparison", "matrix", "summary", "closing", "image_feature"}
PRIORITY = {
    "cover": 10,
    "image_feature": 10,
    "section": 9,
    "statement": 9,
    "closing": 8,
    "process": 8,
    "comparison": 8,
    "timeline": 7,
    "content": 7,
    "agenda": 6,
    "matrix": 6,
    "cards": 5,
    "summary": 5,
}
KIND_BY_TYPE = {
    "cover": "editorial_explainer",
    "section": "conceptual_illustration",
    "agenda": "process_diagram",
    "image_feature": "editorial_explainer",
    "statement": "conceptual_illustration",
    "content": "editorial_explainer",
    "cards": "conceptual_illustration",
    "closing": "conceptual_illustration",
    "process": "process_diagram",
    "timeline": "timeline_illustration",
    "comparison": "comparison_explainer",
    "matrix": "system_relationship",
    "summary": "conceptual_illustration",
}
RATIO_BY_TYPE = {
    "cover": "16:9",
    "section": "16:9",
    "agenda": "16:10",
    "statement": "16:9",
    "content": "16:10",
    "cards": "16:10",
    "process": "16:9",
    "timeline": "16:9",
    "comparison": "16:9",
    "matrix": "16:9",
    "summary": "16:10",
    "closing": "16:10",
    "image_feature": "16:10",
}
SIZE_BY_RATIO = {
    "16:9": {"width": 1536, "height": 864},
    "16:10": {"width": 1536, "height": 960},
    "21:9": {"width": 1792, "height": 768},
    "1:1": {"width": 1024, "height": 1024},
    "3:4": {"width": 960, "height": 1280},
}


def compact(value: Any, limit: int = 80) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text if len(text) <= limit else text[: max(1, limit - 1)].rstrip() + "…"


def slide_text(slide: dict[str, Any]) -> str:
    parts = [slide.get("title"), slide.get("key_message"), slide.get("body")]
    parts.extend(slide.get("bullets") or [])
    for item in slide.get("items") or []:
        if isinstance(item, dict):
            parts.extend([item.get("title"), item.get("body"), item.get("value")])
        else:
            parts.append(item)
    return compact("；".join(str(x) for x in parts if x), 280)


def labels_for(slide: dict[str, Any]) -> list[str]:
    labels: list[str] = []
    for item in slide.get("items") or []:
        value = item.get("title") if isinstance(item, dict) else item
        if value:
            labels.append(compact(value, 14))
    if not labels:
        labels.extend(compact(x, 14) for x in (slide.get("bullets") or []) if x)
    if not labels and slide.get("key_message"):
        labels.append(compact(slide["key_message"], 14))
    return list(dict.fromkeys(x for x in labels if x))[:4]


def style_context(deck: dict[str, Any]) -> dict[str, Any]:
    theme = deck.get("theme") or {}
    template = theme.get("template_style") or {}
    palette = theme.get("custom_colors") or {}
    colors = [str(v) for v in palette.values() if isinstance(v, str) and re.fullmatch(r"#?[0-9A-Fa-f]{6}", v)]
    return {
        "visual_style": theme.get("visual_style") or "clean-professional",
        "style_name": theme.get("style_name") or "清爽专业风",
        "background": colors[0] if colors else "#F5F7FA",
        "primary": colors[1] if len(colors) > 1 else "#1677FF",
        "accent": colors[2] if len(colors) > 2 else "#39A7FF",
        "font_cn": theme.get("font_cn") or "Microsoft YaHei",
        "template_name": template.get("name"),
        "template_source": template.get("source_pptx"),
        "render_hints": template.get("render_hints") or {},
        "layout_recipes": template.get("layout_recipes") or [],
    }


def visual_zone_for(slide_type: str, style: dict[str, Any]) -> str:
    for recipe in style.get("layout_recipes") or []:
        if str(recipe.get("slide_type")) == slide_type and recipe.get("visual_zone"):
            return str(recipe["visual_zone"])
    return "right-or-full-bleed" if slide_type in {"statement", "content"} else "centered-main-visual"


def image_exists(slide: dict[str, Any], base_dir: Path) -> bool:
    raw = slide.get("image")
    if not raw:
        return False
    path = Path(str(raw)).expanduser()
    if not path.is_absolute():
        path = base_dir / path
    return path.exists() and path.is_file()


def choose_kind(slide: dict[str, Any], deck: dict[str, Any]) -> str:
    stype = str(slide.get("type") or "content")
    domain = str((deck.get("planning") or {}).get("domain") or "")
    mode = str(deck.get("mode") or "")
    if domain == "energy-operations" and stype in {"cover", "section", "content", "statement", "summary", "closing"}:
        return "industrial_operations_scene"
    if mode == "product" and stype in {"cover", "content", "statement", "image_feature"}:
        return "product_scenario"
    if mode == "training" and stype in {"content", "process", "timeline", "section"}:
        return "teaching_explainer"
    return KIND_BY_TYPE.get(stype, "editorial_explainer")


def make_prompt(slide: dict[str, Any], deck: dict[str, Any], style: dict[str, Any], kind: str, ratio: str) -> str:
    title = compact(slide.get("title"), 70)
    context = slide_text(slide)
    zone = visual_zone_for(str(slide.get("type") or "content"), style)
    return (
        f"为中文商务 PowerPoint 生成一张 {kind} 类型主视觉。页面结论：{title}。"
        f"内容语境：{context}。画面比例 {ratio}，视觉落位 {zone}。"
        f"严格继承 {style['style_name']}：背景 {style['background']}，主色 {style['primary']}，强调色 {style['accent']}。"
        "构图清晰、信息层级明确、适合会议投影；主体完整，四周保留安全留白，避免重要元素贴边。"
        "只生成图片素材，不画 PPT 标题、页眉、页脚、页码、边框或大段文字；不要在图中生成任何中文或英文标签，标签由 PowerPoint 原生文字叠加。"
    )


def find_asset(asset_dir: Path | None, slide_no: int, expected_name: str) -> Path | None:
    if not asset_dir or not asset_dir.exists():
        return None
    exact = asset_dir / expected_name
    if exact.exists() and exact.is_file():
        return exact.resolve()
    prefixes = [f"slide-{slide_no:02d}", f"slide_{slide_no:02d}", f"visual-{slide_no:02d}", f"visual_{slide_no:02d}"]
    candidates = [p for p in asset_dir.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    for prefix in prefixes:
        match = next((p for p in candidates if p.stem.lower().startswith(prefix.lower())), None)
        if match:
            return match.resolve()
    return None


def relative_asset(path: Path, spec_dir: Path) -> str:
    try:
        return path.relative_to(spec_dir).as_posix()
    except ValueError:
        return str(path)


def apply_asset(slide: dict[str, Any], asset: Path, spec_dir: Path, item: dict[str, Any]) -> None:
    """Bind a generated image to the slide while keeping its semantic type.

    Keeping the original page type lets the renderer place the image inside the
    bespoke layout for that role (cover hero panel, section side panel, content
    right zone, cards feature panel, closing action rail, etc.). The renderer's
    image-or-filler fallback still guarantees no blank space when no asset exists.
    """
    labels = item.get("editable_labels") or []
    slide["image"] = relative_asset(asset, spec_dir)
    slide["visual_asset"] = slide["image"]
    slide["visual_request_id"] = item["id"]
    slide["visual_labels"] = labels
    if not slide.get("body"):
        slide["body"] = slide.get("key_message") or "用主视觉解释本页核心结论。"


def select_slides(deck: dict[str, Any], base_dir: Path, max_images: int) -> list[tuple[int, dict[str, Any]]]:
    candidates = []
    for index, slide in enumerate(deck.get("slides") or [], 1):
        stype = str(slide.get("type") or "content")
        if stype not in ELIGIBLE_TYPES or image_exists(slide, base_dir):
            continue
        if not slide_text(slide):
            continue
        candidates.append((PRIORITY.get(stype, 0), index, slide))
    candidates.sort(key=lambda x: (-x[0], x[1]))
    chosen: list[tuple[int, dict[str, Any]]] = []
    for _, index, slide in candidates:
        if len(chosen) >= max_images:
            break
        if any(abs(index - existing_index) == 1 for existing_index, _ in chosen) and len(candidates) > max_images:
            continue
        chosen.append((index, slide))
    if len(chosen) < min(max_images, len(candidates)):
        used = {x[0] for x in chosen}
        for _, index, slide in candidates:
            if len(chosen) >= max_images:
                break
            if index not in used:
                chosen.append((index, slide))
    return sorted(chosen, key=lambda x: x[0])


def main() -> int:
    parser = argparse.ArgumentParser(description="规划 PPT 配图提示词并绑定宿主生成的图片")
    parser.add_argument("--spec", required=True, help="输入 deck_spec.json")
    parser.add_argument("--analysis", default="", help="可选 analysis.json")
    parser.add_argument("--output", required=True, help="输出 image_plan.json")
    parser.add_argument("--output-spec", default="", help="写入带配图状态的 deck_spec；可与 --spec 相同")
    parser.add_argument("--assets-dir", default="", help="宿主图片生成工具输出目录")
    parser.add_argument("--mode", choices=["off", "plan", "auto", "assets"], default="auto")
    parser.add_argument("--max-images", type=int, default=4)
    args = parser.parse_args()

    spec_path = Path(args.spec).expanduser().resolve()
    deck = json.loads(spec_path.read_text(encoding="utf-8"))
    spec_dir = spec_path.parent
    asset_dir = Path(args.assets_dir).expanduser().resolve() if args.assets_dir else None
    style = style_context(deck)
    selected = [] if args.mode == "off" else select_slides(deck, spec_dir, max(0, args.max_images))
    items: list[dict[str, Any]] = []
    applied = 0

    for slide_no, slide in selected:
        stype = str(slide.get("type") or "content")
        kind = choose_kind(slide, deck)
        ratio = RATIO_BY_TYPE.get(stype, "16:9")
        expected = f"slide-{slide_no:02d}-{kind}.png"
        labels = labels_for(slide)
        item = {
            "id": f"visual-{slide_no:02d}",
            "slide": slide_no,
            "slide_type": stype,
            "title": compact(slide.get("title"), 70),
            "kind": kind,
            "aspect_ratio": ratio,
            "recommended_size": SIZE_BY_RATIO[ratio],
            "expected_filename": expected,
            "prompt": make_prompt(slide, deck, style, kind, ratio),
            "negative_prompt": "乱码、错误文字、标题、页脚、页码、水印、复杂边框、低清晰度、过度装饰、主体被裁切、风格与模板冲突",
            "editable_labels": labels,
            "visual_zone": visual_zone_for(stype, style),
            "asset": None,
            "status": "planned",
        }
        asset = None if args.mode == "plan" else find_asset(asset_dir, slide_no, expected)
        if asset:
            item["asset"] = str(asset)
            item["status"] = "applied"
            apply_asset(slide, asset, spec_dir, item)
            applied += 1
        slide["visual_request"] = {k: item[k] for k in ("id", "kind", "aspect_ratio", "expected_filename", "editable_labels", "status")}
        items.append(item)

    status = "off" if args.mode == "off" else "applied" if items and applied == len(items) else "partially_applied" if applied else "planned"
    plan = {
        "status": status,
        "mode": args.mode,
        "provider": "host-imagegen",
        "spec": str(spec_path),
        "assets_dir": str(asset_dir) if asset_dir else "",
        "style_context": style,
        "planned_count": len(items),
        "applied_count": applied,
        "pending_count": len(items) - applied,
        "items": items,
        "generation_instructions": [
            "使用宿主 imagegen/GPT-Image 能力逐项生成图片。",
            "按 expected_filename 保存到 assets_dir，不要把中文标签画进位图。",
            "再次运行流水线并传入 --visual-assets-dir，图片会自动绑定到对应页面。",
            "中文标签由 PowerPoint 原生文本框叠加，保持可编辑并继承模板字体颜色。",
        ],
    }
    deck["visuals"] = {
        "mode": args.mode,
        "provider": "host-imagegen",
        "plan": Path(args.output).expanduser().resolve().name,
        "planned_count": len(items),
        "applied_count": applied,
        "pending_count": len(items) - applied,
        "native_label_overlay": True,
    }

    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.output_spec:
        output_spec = Path(args.output_spec).expanduser().resolve()
        output_spec.parent.mkdir(parents=True, exist_ok=True)
        output_spec.write_text(json.dumps(deck, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
