#!/usr/bin/env python3
"""Analyze imported materials and create analysis.json plus presentation-ready charts."""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    MATPLOTLIB_AVAILABLE = True
except Exception:
    matplotlib = None
    plt = None
    font_manager = None
    MATPLOTLIB_AVAILABLE = False
import numpy as np
import pandas as pd
from docx import Document
from PIL import Image
from pypdf import PdfReader
from pptx import Presentation

from diagnostics import classify_exception, make_diagnostic

try:
    from charset_normalizer import from_bytes as detect_charset
except Exception:  # optional; fallback encodings remain available
    detect_charset = None

SUPPORTED = {
    ".xlsx", ".xls", ".csv", ".tsv", ".docx", ".pdf", ".pptx",
    ".txt", ".md", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif"
}
DATE_HINT = re.compile(r"日期|时间|月份|年月|季度|年度|年|月|date|time|month|quarter|year", re.I)
SUM_HINT = re.compile(r"销售|销量|金额|收入|营收|订单|数量|产量|用电|电量|用水|水量|成本|费用|利润|revenue|sales|amount|count|qty|quantity|production|electricity|electric|water|kwh|cost|profit", re.I)
PERCENT_HINT = re.compile(r"率|占比|比例|百分比|强度|单耗|rate|ratio|percent|intensity|per[_ -]?unit|%", re.I)

DEFAULT_MAX_FILE_MB = 150
DEFAULT_MAX_ROWS = 200_000
DEFAULT_MAX_COLUMNS = 500
DEFAULT_MAX_SHEETS = 100

COLORS = {
    "primary": "#1F4E79",
    "accent": "#F59E0B",
    "secondary": "#5B8FF9",
    "positive": "#2E8B57",
    "negative": "#C63C3C",
    "muted": "#6B7280",
    "grid": "#D9E1EA",
    "text": "#172033",
    "background": "#FFFFFF",
}


@dataclass
class Dataset:
    name: str
    source_file: str
    sheet: str | None
    frame: pd.DataFrame


def json_safe(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return round(value, 6)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        v = float(value)
        return None if math.isnan(v) or math.isinf(v) else round(v, 6)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    return str(value)


def _encoding_candidates(raw: bytes) -> list[str]:
    candidates: list[str] = []
    if detect_charset is not None:
        try:
            best = detect_charset(raw[:1_000_000]).best()
            if best and best.encoding:
                candidates.append(best.encoding)
        except Exception:
            pass
    candidates.extend(["utf-8-sig", "utf-8", "gb18030", "big5", "gbk", "latin1"])
    result: list[str] = []
    for enc in candidates:
        if enc and enc.lower() not in {x.lower() for x in result}:
            result.append(enc)
    return result


def read_text_file(path: Path) -> tuple[str, dict[str, Any]]:
    raw = path.read_bytes()
    failures: list[str] = []
    for enc in _encoding_candidates(raw):
        try:
            text = raw.decode(enc)
            replacement_ratio = text.count("�") / max(len(text), 1)
            if replacement_ratio > 0.01:
                failures.append(f"{enc}: replacement_ratio={replacement_ratio:.3f}")
                continue
            return text, {"encoding": enc, "replacement_ratio": replacement_ratio, "attempts": failures}
        except (UnicodeDecodeError, LookupError) as exc:
            failures.append(f"{enc}: {type(exc).__name__}")
    raise UnicodeDecodeError("unknown", raw, 0, min(1, len(raw)), "无法可靠识别文本编码")


def _sniff_delimiter(sample: str, suffix: str) -> str:
    if suffix == ".tsv":
        return "	"
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;	|")
        return dialect.delimiter
    except Exception:
        counts = {d: sample.count(d) for d in [",", ";", "	", "|"]}
        return max(counts, key=counts.get) if max(counts.values(), default=0) else ","


def read_csv(path: Path, max_rows: int = DEFAULT_MAX_ROWS) -> tuple[pd.DataFrame, dict[str, Any]]:
    raw = path.read_bytes()
    errors: list[str] = []
    for enc in _encoding_candidates(raw):
        try:
            sample = raw[:128_000].decode(enc)
        except (UnicodeDecodeError, LookupError) as exc:
            errors.append(f"{enc}: {type(exc).__name__}")
            continue
        sep = _sniff_delimiter(sample, path.suffix.lower())
        common = dict(encoding=enc, sep=sep, nrows=max_rows + 1, engine="python")
        try:
            df = pd.read_csv(path, on_bad_lines="error", **common)
            info = {"encoding": enc, "delimiter": "TAB" if sep == "	" else sep, "parser": "strict", "bad_lines_skipped": False, "attempts": errors}
        except pd.errors.ParserError as strict_exc:
            try:
                df = pd.read_csv(path, on_bad_lines="skip", **common)
                info = {"encoding": enc, "delimiter": "TAB" if sep == "	" else sep, "parser": "tolerant", "bad_lines_skipped": True, "strict_error": str(strict_exc), "attempts": errors}
            except Exception as exc:
                errors.append(f"{enc}/{repr(sep)}: {type(exc).__name__}: {exc}")
                continue
        except Exception as exc:
            errors.append(f"{enc}/{repr(sep)}: {type(exc).__name__}: {exc}")
            continue
        truncated = len(df) > max_rows
        if truncated:
            df = df.iloc[:max_rows].copy()
        info["truncated"] = truncated
        info["max_rows"] = max_rows
        return df, info
    raise RuntimeError("CSV 读取失败；已尝试多种编码和分隔符。" + (" | " + " ; ".join(errors[-6:]) if errors else ""))


def extract_docx(path: Path) -> tuple[str, list[pd.DataFrame]]:
    doc = Document(path)
    text = "\n".join(p.text.strip() for p in doc.paragraphs if p.text.strip())
    tables: list[pd.DataFrame] = []
    for i, table in enumerate(doc.tables, 1):
        rows = [[cell.text.strip() for cell in row.cells] for row in table.rows]
        if not rows:
            continue
        width = max(len(r) for r in rows)
        rows = [r + [""] * (width - len(r)) for r in rows]
        header = rows[0]
        if len(set(header)) != len(header) or any(not h for h in header):
            header = [f"列{j+1}" for j in range(width)]
            body = rows
        else:
            body = rows[1:]
        tables.append(pd.DataFrame(body, columns=header))
    return text, tables


def extract_pdf(path: Path) -> tuple[str, dict[str, Any]]:
    """Extract searchable PDF text and report likely scanned pages.

    OCR is intentionally not performed here. The metadata makes the limitation
    explicit so users know which pages require OCR or manual verification.
    """
    reader = PdfReader(str(path))
    pages: list[str] = []
    empty_pages: list[int] = []
    low_text_pages: list[int] = []
    for index, page in enumerate(reader.pages, 1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        normalized = re.sub(r"\s+", "", text)
        if not normalized:
            empty_pages.append(index)
        elif len(normalized) < 30:
            low_text_pages.append(index)
        pages.append(text)
    page_count = len(pages)
    extracted_pages = sum(1 for x in pages if re.sub(r"\s+", "", x))
    probable_scanned = page_count > 0 and extracted_pages == 0
    partial_scan = page_count > 0 and 0 < extracted_pages < page_count
    meta = {
        "page_count": page_count,
        "extracted_text_pages": extracted_pages,
        "empty_text_pages": empty_pages[:50],
        "low_text_pages": low_text_pages[:50],
        "probable_scanned_pdf": probable_scanned,
        "partially_scanned_pdf": partial_scan,
        "ocr_performed": False,
        "manual_check_required": probable_scanned or partial_scan or bool(low_text_pages),
    }
    return "\n".join(pages), meta


def extract_pptx(path: Path) -> str:
    prs = Presentation(str(path))
    slide_texts = []
    for idx, slide in enumerate(prs.slides, 1):
        parts = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                parts.append(shape.text.strip())
        if parts:
            slide_texts.append(f"[Slide {idx}]\n" + "\n".join(parts))
    return "\n\n".join(slide_texts)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    cols, used = [], set()
    for i, c in enumerate(df.columns):
        base = str(c).strip() or f"列{i+1}"
        name = base
        n = 2
        while name in used:
            name = f"{base}_{n}"
            n += 1
        used.add(name)
        cols.append(name)
    df.columns = cols
    df = df.dropna(how="all").dropna(axis=1, how="all")
    return df


def coerce_numeric_like(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]) or pd.api.types.is_datetime64_any_dtype(df[col]):
            continue
        s = df[col].astype(str).str.strip()
        cleaned = (
            s.str.replace(",", "", regex=False)
             .str.replace("，", "", regex=False)
             .str.replace("¥", "", regex=False)
             .str.replace("￥", "", regex=False)
             .str.replace("$", "", regex=False)
             .str.replace("%", "", regex=False)
        )
        parsed = pd.to_numeric(cleaned, errors="coerce")
        nonempty = s.ne("") & s.ne("nan") & s.ne("None")
        denom = int(nonempty.sum())
        if denom >= 3 and parsed[nonempty].notna().mean() >= 0.8:
            df[col] = parsed
    return df


def detect_date_columns(df: pd.DataFrame) -> list[str]:
    dates: list[str] = []
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            dates.append(col)
            continue
        series = df[col]
        if pd.api.types.is_numeric_dtype(series) and not DATE_HINT.search(col):
            continue
        sample = series.dropna().astype(str).head(100)
        if sample.empty:
            continue
        try:
            parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
        except TypeError:
            parsed = pd.to_datetime(sample, errors="coerce")
        threshold = 0.65 if DATE_HINT.search(col) else 0.85
        if parsed.notna().mean() >= threshold:
            dates.append(col)
    return dates


def get_categorical_columns(df: pd.DataFrame, date_cols: list[str]) -> list[str]:
    result = []
    for col in df.columns:
        if col in date_cols or pd.api.types.is_numeric_dtype(df[col]):
            continue
        nunique = df[col].nunique(dropna=True)
        if 2 <= nunique <= min(30, max(2, len(df) // 2 + 1)):
            result.append(col)
    return result


def choose_cjk_font() -> str:
    if font_manager is None:
        return "Microsoft YaHei"
    candidates = ["Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", "Noto Sans CJK JP", "Source Han Sans SC", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in installed:
            return name
    return "DejaVu Sans"


def setup_plot(title: str, subtitle: str | None = None):
    if plt is None:
        raise RuntimeError("matplotlib is not available")
    plt.rcParams["font.family"] = choose_cjk_font()
    plt.rcParams["font.sans-serif"] = [choose_cjk_font()]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(12, 6.75), dpi=160)
    fig.patch.set_facecolor(COLORS["background"])
    ax.set_facecolor(COLORS["background"])
    fig.suptitle(title, x=0.06, y=0.96, ha="left", fontsize=18, fontweight="bold", color=COLORS["text"])
    if subtitle:
        fig.text(0.06, 0.91, subtitle, ha="left", fontsize=10, color=COLORS["muted"])
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color(COLORS["grid"])
    ax.tick_params(colors=COLORS["muted"], labelsize=9)
    ax.grid(axis="y", color=COLORS["grid"], linewidth=0.7, alpha=0.65)
    return fig, ax


def save_chart(fig, path: Path) -> None:
    if plt is None:
        raise RuntimeError("matplotlib is not available")
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout(rect=(0.04, 0.05, 0.98, 0.88))
    fig.savefig(path, bbox_inches="tight", facecolor=COLORS["background"])
    plt.close(fig)


def format_number(v: float) -> str:
    av = abs(v)
    if av >= 100_000_000:
        return f"{v/100_000_000:.2f}亿"
    if av >= 10_000:
        return f"{v/10_000:.1f}万"
    if av >= 1000:
        return f"{v:,.0f}"
    if av >= 10:
        return f"{v:.1f}"
    return f"{v:.2f}"


def linear_trend(values: pd.Series) -> float | None:
    y = pd.to_numeric(values, errors="coerce").dropna().values
    if len(y) < 3:
        return None
    x = np.arange(len(y), dtype=float)
    return float(np.polyfit(x, y, 1)[0])


def create_charts(dataset: Dataset, outdir: Path, limit: int = 6) -> tuple[list[dict[str, Any]], list[str]]:
    df = dataset.frame
    date_cols = detect_date_columns(df)
    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = get_categorical_columns(df, date_cols)
    charts: list[dict[str, Any]] = []
    findings: list[str] = []
    slug = re.sub(r"[^A-Za-z0-9\u4e00-\u9fff_-]+", "_", dataset.name)[:40]

    def register(kind: str, title: str, path: Path | None, description: str, x: str | None = None, y: str | None = None, chart_data: dict[str, Any] | None = None):
        charts.append({
            "type": kind,
            "title": title,
            "image": str(path.resolve()) if path else "",
            "description": description,
            "x": x,
            "y": y,
            "source_file": dataset.source_file,
            "sheet": dataset.sheet,
            "chart_data": chart_data or {},
        })

    # Time trend charts
    if date_cols and numeric_cols and len(charts) < limit:
        dcol = date_cols[0]
        temp = df[[dcol] + numeric_cols].copy()
        temp[dcol] = pd.to_datetime(temp[dcol], errors="coerce")
        temp = temp.dropna(subset=[dcol])
        preferred = sorted(numeric_cols, key=lambda c: (not bool(SUM_HINT.search(c)), -float(pd.to_numeric(df[c], errors="coerce").var(skipna=True) or 0)))
        for ncol in preferred[:2]:
            if len(charts) >= limit:
                break
            agg_fn = "sum" if SUM_HINT.search(ncol) and not PERCENT_HINT.search(ncol) else "mean"
            grouped = temp.groupby(dcol, as_index=False)[ncol].agg(agg_fn).sort_values(dcol)
            if len(grouped) < 3:
                continue
            path = None
            if MATPLOTLIB_AVAILABLE:
                fig, ax = setup_plot(f"{ncol}趋势", f"{dataset.name}｜按{dcol}汇总")
                ax.plot(grouped[dcol], grouped[ncol], marker="o", linewidth=2.6, color=COLORS["primary"])
                ax.fill_between(grouped[dcol], grouped[ncol], alpha=0.08, color=COLORS["primary"])
                ax.set_xlabel("")
                ax.set_ylabel(ncol, color=COLORS["muted"])
                for x, y in zip(grouped[dcol], grouped[ncol]):
                    if pd.notna(y):
                        ax.annotate(format_number(float(y)), (x, y), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8, color=COLORS["text"])
                path = outdir / "charts" / f"{slug}_trend_{len(charts)+1}.png"
                save_chart(fig, path)
            first, last = float(grouped[ncol].iloc[0]), float(grouped[ncol].iloc[-1])
            pct = None if first == 0 else (last - first) / abs(first) * 100
            numeric_series = pd.to_numeric(grouped[ncol], errors="coerce").dropna()
            zero_ratio = float((numeric_series.fillna(0) == 0).mean())
            low_load_tail = bool(len(numeric_series) >= 12 and float(numeric_series.median()) > 0 and last < float(numeric_series.median()) * 0.45)
            if zero_ratio >= 0.2 or low_load_tail:
                active = numeric_series
                active = active[active != 0]
                peak_idx = pd.to_numeric(grouped[ncol], errors="coerce").idxmax()
                peak_label = grouped.loc[peak_idx, dcol]
                if low_load_tail and zero_ratio < 0.2:
                    desc = f"{ncol}峰值{format_number(float(active.max()))}出现在{peak_label}，末期降至低负荷{format_number(last)}"
                else:
                    desc = f"{ncol}共有{len(active)}个非零周期，峰值{format_number(float(active.max()))}出现在{peak_label}"
            else:
                desc = f"{ncol}从首期{format_number(first)}变化至末期{format_number(last)}"
                if pct is not None:
                    desc += f"，变化{pct:+.1f}%"
            findings.append(desc + "。")
            register("line", f"{ncol}趋势", path, desc, dcol, ncol, {
                "kind": "line",
                "categories": [str(x.date()) if hasattr(x, "date") else str(x) for x in grouped[dcol].tolist()],
                "series": [{"name": ncol, "values": [float(x) if pd.notna(x) else 0.0 for x in grouped[ncol].tolist()]}],
                "x_axis": dcol,
                "y_axis": ncol,
            })

    # Category comparison chart
    # Repeated categories without an explicit date often represent aligned
    # periods, e.g. three production lines repeated once per day. Convert that
    # structure into an editable multi-series trend before aggregating totals.
    if not date_cols and cat_cols and numeric_cols and len(charts) < limit:
        ccol = cat_cols[0]
        counts = df[ccol].dropna().astype(str).value_counts()
        if 2 <= len(counts) <= 6 and counts.min() >= 5 and counts.max() - counts.min() <= 1:
            ncol = sorted(numeric_cols, key=lambda c: (not bool(SUM_HINT.search(c)), c))[0]
            temp = df[[ccol, ncol]].dropna().copy()
            temp[ccol] = temp[ccol].astype(str)
            temp["_period"] = temp.groupby(ccol).cumcount() + 1
            pivot = temp.pivot(index="_period", columns=ccol, values=ncol).sort_index()
            series = [
                {"name": str(col), "values": [float(x) if pd.notna(x) else 0.0 for x in pivot[col].tolist()]}
                for col in pivot.columns
            ]
            path = None
            if MATPLOTLIB_AVAILABLE:
                fig, ax = setup_plot(f"{ncol}分组趋势", f"{dataset.name}｜按记录顺序还原周期")
                for col in pivot.columns:
                    ax.plot(pivot.index, pivot[col], marker="o", linewidth=2.1, label=str(col))
                ax.legend(frameon=False, fontsize=9, ncol=min(3, len(pivot.columns)))
                ax.set_xlabel("周期")
                ax.set_ylabel(ncol)
                path = outdir / "charts" / f"{slug}_group_trend_{len(charts)+1}.png"
                save_chart(fig, path)
            leaders = pivot.sum().sort_values(ascending=False)
            desc = f"{leaders.index[0]}的{ncol}累计最高，为{format_number(float(leaders.iloc[0]))}"
            register("line", f"{ncol}分组趋势", path, desc, "周期", ncol, {
                "kind": "line",
                "categories": [f"第{int(x)}期" for x in pivot.index.tolist()],
                "series": series,
                "x_axis": "周期",
                "y_axis": ncol,
            })

    # Category comparison chart
    if cat_cols and numeric_cols and len(charts) < limit:
        ccol = cat_cols[0]
        preferred = sorted(numeric_cols, key=lambda c: (not bool(SUM_HINT.search(c)), c))
        ncol = preferred[0]
        agg_fn = "sum" if SUM_HINT.search(ncol) and not PERCENT_HINT.search(ncol) else "mean"
        grouped = df.groupby(ccol, dropna=True)[ncol].agg(agg_fn).dropna().sort_values(ascending=False).head(10)
        if len(grouped) >= 2:
            labels = [str(x) for x in grouped.index]
            vals = grouped.values.astype(float)
            path = None
            if MATPLOTLIB_AVAILABLE:
                fig, ax = setup_plot(f"{ccol}对比", f"按{ncol}{'合计' if agg_fn == 'sum' else '均值'}排序")
                if len(grouped) >= 6:
                    ax.barh(labels[::-1], vals[::-1], color=COLORS["primary"], alpha=0.92)
                    for i, v in enumerate(vals[::-1]):
                        ax.text(v, i, "  " + format_number(float(v)), va="center", fontsize=9, color=COLORS["text"])
                    ax.set_xlabel(ncol)
                else:
                    ax.bar(labels, vals, color=COLORS["primary"], alpha=0.92)
                    for i, v in enumerate(vals):
                        ax.text(i, v, format_number(float(v)), ha="center", va="bottom", fontsize=9, color=COLORS["text"])
                    ax.tick_params(axis="x", rotation=0)
                    ax.set_ylabel(ncol)
                path = outdir / "charts" / f"{slug}_bar_{len(charts)+1}.png"
                save_chart(fig, path)
            desc = f"{grouped.index[0]}的{ncol}最高，为{format_number(float(grouped.iloc[0]))}"
            findings.append(desc + "。")
            register("bar", f"{ccol}{ncol}对比", path, desc, ccol, ncol, {
                "kind": "bar",
                "categories": labels,
                "series": [{"name": ncol, "values": [float(x) for x in vals.tolist()]}],
                "x_axis": ccol,
                "y_axis": ncol,
            })

    # Pie for compact category distribution
    if cat_cols and len(charts) < limit:
        for ccol in cat_cols:
            counts = df[ccol].dropna().astype(str).value_counts()
            if 2 <= len(counts) <= 6 and counts.sum() >= 5 and counts.nunique() > 1:
                path = None
                if MATPLOTLIB_AVAILABLE:
                    fig, ax = plt.subplots(figsize=(12, 6.75), dpi=160)
                    fig.patch.set_facecolor(COLORS["background"])
                    fig.suptitle(f"{ccol}构成", x=0.06, y=0.96, ha="left", fontsize=18, fontweight="bold", color=COLORS["text"])
                    palette = [COLORS["primary"], COLORS["secondary"], COLORS["accent"], COLORS["positive"], "#8B5CF6", "#94A3B8"]
                    wedges, _ = ax.pie(counts.values, startangle=90, colors=palette[:len(counts)], wedgeprops={"width": 0.46, "edgecolor": "white"})
                    ax.legend(wedges, [f"{k}  {v/counts.sum()*100:.1f}%" for k, v in counts.items()], loc="center left", bbox_to_anchor=(0.78, 0.5), frameon=False, fontsize=10)
                    ax.text(0, 0.05, f"{int(counts.sum())}", ha="center", va="center", fontsize=25, fontweight="bold", color=COLORS["text"])
                    ax.text(0, -0.18, "有效样本", ha="center", va="center", fontsize=10, color=COLORS["muted"])
                    path = outdir / "charts" / f"{slug}_pie_{len(charts)+1}.png"
                    save_chart(fig, path)
                desc = f"{counts.index[0]}占比最高，为{counts.iloc[0]/counts.sum()*100:.1f}%"
                register("pie", f"{ccol}构成", path, desc, ccol, "count", {
                    "kind": "pie",
                    "categories": [str(x) for x in counts.index.tolist()],
                    "series": [{"name": "数量", "values": [float(x) for x in counts.values.tolist()]}],
                    "x_axis": ccol,
                    "y_axis": "count",
                })
                break

    # Correlation scatter
    if len(numeric_cols) >= 2 and len(charts) < limit:
        corr = df[numeric_cols].corr(numeric_only=True)
        pairs = []
        for i, a in enumerate(numeric_cols):
            for b in numeric_cols[i+1:]:
                r = corr.loc[a, b]
                n = int(df[[a, b]].dropna().shape[0])
                if pd.notna(r) and n >= 8:
                    pairs.append((abs(float(r)), float(r), a, b, n))
        if pairs:
            _, r, a, b, n = max(pairs)
            temp = df[[a, b]].dropna()
            path = None
            if MATPLOTLIB_AVAILABLE:
                fig, ax = setup_plot(f"{a}与{b}的关系", f"Pearson r={r:.2f}｜有效样本 n={n}")
                ax.scatter(temp[a], temp[b], s=48, alpha=0.75, color=COLORS["primary"], edgecolor="white", linewidth=0.6)
                if temp[a].nunique() > 1:
                    z = np.polyfit(temp[a].astype(float), temp[b].astype(float), 1)
                    xline = np.linspace(float(temp[a].min()), float(temp[a].max()), 100)
                    ax.plot(xline, z[0] * xline + z[1], color=COLORS["accent"], linewidth=2)
                ax.set_xlabel(a)
                ax.set_ylabel(b)
                path = outdir / "charts" / f"{slug}_scatter_{len(charts)+1}.png"
                save_chart(fig, path)
            strength = "较强" if abs(r) >= 0.7 else "中等" if abs(r) >= 0.4 else "较弱"
            direction = "正" if r > 0 else "负"
            desc = f"{a}与{b}呈{strength}{direction}相关（r={r:.2f}），相关不代表因果"
            findings.append(desc + "。")
            register("scatter", f"{a}与{b}相关性", path, desc, a, b, {
                "kind": "scatter",
                "x_values": [float(x) for x in temp[a].astype(float).tolist()],
                "series": [{"name": b, "values": [float(x) for x in temp[b].astype(float).tolist()]}],
                "x_axis": a,
                "y_axis": b,
            })

    # Distribution histogram
    if numeric_cols and len(charts) < limit:
        ncol = sorted(numeric_cols, key=lambda c: -int(df[c].notna().sum()))[0]
        values = pd.to_numeric(df[ncol], errors="coerce").dropna()
        if len(values) >= 8 and values.nunique() >= 5:
            bins = min(12, max(5, int(math.sqrt(len(values)))))
            path = None
            if MATPLOTLIB_AVAILABLE:
                fig, ax = setup_plot(f"{ncol}分布", f"有效样本 n={len(values)}")
                ax.hist(values, bins=bins, color=COLORS["primary"], alpha=0.85, edgecolor="white")
                ax.axvline(values.mean(), color=COLORS["accent"], linewidth=2, label=f"均值 {format_number(float(values.mean()))}")
                ax.axvline(values.median(), color=COLORS["positive"], linewidth=2, linestyle="--", label=f"中位数 {format_number(float(values.median()))}")
                ax.legend(frameon=False, fontsize=9)
                ax.set_xlabel(ncol)
                ax.set_ylabel("频数")
                path = outdir / "charts" / f"{slug}_hist_{len(charts)+1}.png"
                save_chart(fig, path)
            desc = f"{ncol}均值为{format_number(float(values.mean()))}，中位数为{format_number(float(values.median()))}"
            hist_counts, bin_edges = np.histogram(values, bins=bins)
            labels = [f"{format_number(float(bin_edges[i]))}-{format_number(float(bin_edges[i+1]))}" for i in range(len(hist_counts))]
            register("histogram", f"{ncol}分布", path, desc, ncol, "count", {
                "kind": "bar",
                "categories": labels,
                "series": [{"name": "频数", "values": [float(x) for x in hist_counts.tolist()]}],
                "x_axis": ncol,
                "y_axis": "count",
            })

    return charts, findings


def analyze_dataset(dataset: Dataset, outdir: Path) -> dict[str, Any]:
    df = normalize_columns(dataset.frame)
    df = coerce_numeric_like(df)
    dataset.frame = df
    date_cols = detect_date_columns(df)
    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = get_categorical_columns(df, date_cols)
    rows, cols = df.shape
    missing = {c: float(df[c].isna().mean() * 100) for c in df.columns}
    duplicates = int(df.duplicated().sum())

    numeric_summary: dict[str, Any] = {}
    outlier_summary: dict[str, Any] = {}
    for col in numeric_cols:
        s = pd.to_numeric(df[col], errors="coerce").dropna()
        if s.empty:
            continue
        numeric_summary[col] = {
            "count": int(s.count()),
            "sum": float(s.sum()),
            "mean": float(s.mean()),
            "median": float(s.median()),
            "min": float(s.min()),
            "max": float(s.max()),
            "std": float(s.std(ddof=1)) if len(s) > 1 else 0.0,
        }
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        outliers = s[(s < lower) | (s > upper)]
        outlier_summary[col] = {
            "count": int(len(outliers)),
            "lower_bound": float(lower),
            "upper_bound": float(upper),
        }

    category_summary: dict[str, Any] = {}
    for col in cat_cols:
        counts = df[col].dropna().astype(str).value_counts().head(10)
        category_summary[col] = {
            "unique": int(df[col].nunique(dropna=True)),
            "top_values": [{"value": str(k), "count": int(v), "share_pct": float(v / counts.sum() * 100)} for k, v in counts.items()] if counts.sum() else [],
        }

    corr_pairs: list[dict[str, Any]] = []
    if len(numeric_cols) >= 2:
        corr = df[numeric_cols].corr(numeric_only=True)
        for i, a in enumerate(numeric_cols):
            for b in numeric_cols[i+1:]:
                n = int(df[[a, b]].dropna().shape[0])
                r = corr.loc[a, b]
                if n >= 8 and pd.notna(r):
                    corr_pairs.append({"x": a, "y": b, "r": float(r), "n": n})
        corr_pairs.sort(key=lambda x: abs(x["r"]), reverse=True)

    charts, chart_findings = create_charts(dataset, outdir)
    findings = []
    findings.extend(chart_findings)
    high_missing = [(c, p) for c, p in missing.items() if p >= 20]
    if high_missing:
        findings.append("以下字段缺失率较高：" + "、".join(f"{c} {p:.1f}%" for c, p in high_missing[:5]) + "。")
    repeated_observations = bool(not date_cols and len(df.columns) <= 2 and cat_cols)
    if duplicates and not repeated_observations:
        findings.append(f"检测到 {duplicates} 行完全重复记录，需确认是否应去重。")
    for col, info in outlier_summary.items():
        if info["count"] > 0:
            findings.append(f"{col}检测到 {info['count']} 个 IQR 异常值；异常值不等于错误，建议结合业务核查。")
            if len(findings) >= 10:
                break

    preview = df.head(10).where(pd.notna(df), None).to_dict(orient="records")
    return {
        "name": dataset.name,
        "source_file": dataset.source_file,
        "sheet": dataset.sheet,
        "shape": {"rows": rows, "columns": cols},
        "columns": list(df.columns),
        "date_columns": date_cols,
        "numeric_columns": numeric_cols,
        "categorical_columns": cat_cols,
        "missing_pct": missing,
        "duplicate_rows": duplicates,
        "duplicate_interpretation": "repeated_observations_without_period_key" if duplicates and repeated_observations else "exact_duplicates",
        "numeric_summary": numeric_summary,
        "category_summary": category_summary,
        "outliers_iqr": outlier_summary,
        "correlations": corr_pairs[:10],
        "charts": charts,
        "findings": findings[:12],
        "preview": preview,
    }


def ingest_file(
    path: Path,
    *,
    max_file_mb: int = DEFAULT_MAX_FILE_MB,
    max_rows: int = DEFAULT_MAX_ROWS,
    max_columns: int = DEFAULT_MAX_COLUMNS,
    max_sheets: int = DEFAULT_MAX_SHEETS,
) -> tuple[list[Dataset], dict[str, Any]]:
    suffix = path.suffix.lower()
    datasets: list[Dataset] = []
    meta: dict[str, Any] = {
        "path": str(path.resolve()),
        "name": path.name,
        "type": suffix,
        "size_bytes": path.stat().st_size if path.exists() else 0,
        "status": "ok",
        "warnings": [],
        "diagnostics": [],
    }
    if not path.exists():
        meta["status"] = "error"
        meta["diagnostics"].append(make_diagnostic("FILE_NOT_FOUND", "ingest", "文件不存在。", file=path))
        return datasets, meta
    if suffix not in SUPPORTED:
        meta["status"] = "unsupported"
        meta["diagnostics"].append(make_diagnostic("UNSUPPORTED_FORMAT", "ingest", f"不支持的文件格式：{suffix or '无扩展名'}", file=path, severity="warning"))
        return datasets, meta
    if meta["size_bytes"] == 0:
        meta["status"] = "error"
        meta["diagnostics"].append(make_diagnostic("EMPTY_FILE", "ingest", "文件大小为 0 字节。", file=path))
        return datasets, meta
    if meta["size_bytes"] > max_file_mb * 1024 * 1024:
        meta["status"] = "skipped"
        meta["diagnostics"].append(make_diagnostic("FILE_TOO_LARGE", "ingest", f"文件大小超过 {max_file_mb} MB 安全上限。", file=path))
        return datasets, meta

    try:
        if suffix in (".xlsx", ".xls"):
            if suffix == ".xls":
                meta["diagnostics"].append(make_diagnostic("LEGACY_XLS_LIMITED", "excel-open", "检测到旧版 .xls 文件；仅保证读取主要表格值。", file=path, severity="warning"))
                meta["status"] = "partial"
            try:
                book = pd.ExcelFile(path)
            except ImportError as exc:
                meta["status"] = "error"
                meta["diagnostics"].append(make_diagnostic("EXCEL_READER_MISSING", "excel-open", str(exc), file=path))
                return datasets, meta
            sheet_names = list(book.sheet_names)
            meta["sheets"] = sheet_names[:max_sheets]
            if len(sheet_names) > max_sheets:
                meta["warnings"].append(f"Sheet 数量为 {len(sheet_names)}，仅处理前 {max_sheets} 个。")
            sheet_errors = []
            for sheet in sheet_names[:max_sheets]:
                try:
                    df = pd.read_excel(book, sheet_name=sheet, nrows=max_rows + 1)
                    truncated = len(df) > max_rows
                    if truncated:
                        df = df.iloc[:max_rows].copy()
                        meta["diagnostics"].append(make_diagnostic("DATA_TRUNCATED", "excel-read", f"Sheet“{sheet}”超过 {max_rows} 行，已截断。", file=path, severity="warning", details={"sheet": sheet, "max_rows": max_rows}))
                    if df.shape[1] > max_columns:
                        meta["warnings"].append(f"Sheet“{sheet}”列数为 {df.shape[1]}，仅保留前 {max_columns} 列。")
                        df = df.iloc[:, :max_columns]
                    datasets.append(Dataset(f"{path.stem}-{sheet}", str(path.resolve()), str(sheet), df))
                except Exception as exc:
                    diag = classify_exception(exc, "excel-sheet", path)
                    diag["code"] = "EXCEL_SHEET_FAILED" if diag["code"] == "INPUT_PARSE_FAILED" else diag["code"]
                    diag.setdefault("details", {})["sheet"] = str(sheet)
                    sheet_errors.append(diag)
            meta["diagnostics"].extend(sheet_errors)
            if sheet_errors and datasets:
                meta["status"] = "partial"
            elif sheet_errors and not datasets:
                meta["status"] = "error"
        elif suffix in (".csv", ".tsv"):
            df, read_info = read_csv(path, max_rows=max_rows)
            meta["read_info"] = read_info
            if read_info.get("bad_lines_skipped"):
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("CSV_ROWS_SKIPPED", "csv-read", "严格模式失败，已使用容错模式跳过结构异常行。", file=path, severity="warning", details={"strict_error": read_info.get("strict_error", "")}))
            if read_info.get("truncated"):
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("DATA_TRUNCATED", "csv-read", f"数据超过 {max_rows} 行，已截断。", file=path, severity="warning", details={"max_rows": max_rows}))
            if df.shape[1] > max_columns:
                meta["status"] = "partial"
                meta["warnings"].append(f"列数为 {df.shape[1]}，仅保留前 {max_columns} 列。")
                df = df.iloc[:, :max_columns]
            datasets.append(Dataset(path.stem, str(path.resolve()), None, df))
        elif suffix == ".docx":
            text, tables = extract_docx(path)
            meta["text"] = text[:30_000]
            meta["text_length"] = len(text)
            if len(text) > 30_000:
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("TEXT_TRUNCATED", "docx-extract", "Word 正文超过 30000 字符，分析阶段已分段取样。", file=path, severity="warning", details={"text_length": len(text)}))
            for i, df in enumerate(tables, 1):
                datasets.append(Dataset(f"{path.stem}-表{i}", str(path.resolve()), f"表{i}", df.iloc[:max_rows, :max_columns]))
            if not text.strip() and not tables:
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("EMPTY_FILE", "docx-extract", "Word 中未提取到正文或表格。", file=path, severity="warning"))
        elif suffix == ".pdf":
            text, pdf_info = extract_pdf(path)
            meta["pdf_info"] = pdf_info
            meta["text"] = text[:40_000]
            meta["text_length"] = len(text)
            if len(text) > 40_000:
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("TEXT_TRUNCATED", "pdf-extract", "PDF 可提取文字超过 40000 字符，分析阶段已分段取样。", file=path, severity="warning", details={"text_length": len(text)}))
            if pdf_info.get("probable_scanned_pdf"):
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("PDF_TEXT_EMPTY", "pdf-extract", "PDF 未提取到可搜索文字，判断为扫描版或文字轮廓。", file=path, severity="warning", details=pdf_info))
            elif pdf_info.get("partially_scanned_pdf") or pdf_info.get("low_text_pages"):
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("PDF_PARTIALLY_SCANNED", "pdf-extract", "PDF 部分页面缺少可搜索文字。", file=path, severity="warning", details=pdf_info))
        elif suffix == ".pptx":
            text = extract_pptx(path)
            meta["text"] = text[:40_000]
            meta["text_length"] = len(text)
            if len(text) > 40_000:
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("TEXT_TRUNCATED", "pptx-extract", "PPT 文字超过 40000 字符，分析阶段已分段取样。", file=path, severity="warning", details={"text_length": len(text)}))
            if not text.strip():
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("EMPTY_FILE", "pptx-extract", "PPT 中未提取到可编辑文字。", file=path, severity="warning"))
        elif suffix in (".txt", ".md"):
            text, read_info = read_text_file(path)
            meta["read_info"] = read_info
            meta["text"] = text[:40_000]
            meta["text_length"] = len(text)
            if len(text) > 40_000:
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("TEXT_TRUNCATED", "text-read", "文本超过 40000 字符，分析阶段已分段取样。", file=path, severity="warning", details={"text_length": len(text)}))
            if not text.strip():
                meta["status"] = "partial"
                meta["diagnostics"].append(make_diagnostic("EMPTY_FILE", "text-read", "文本文件没有有效内容。", file=path, severity="warning"))
        elif suffix == ".json":
            text, read_info = read_text_file(path)
            meta["read_info"] = read_info
            raw = json.loads(text)
            preview_value = raw if isinstance(raw, dict) else raw[:10] if isinstance(raw, list) else raw
            meta["json_preview"] = json_safe(preview_value)
            if isinstance(raw, list) and raw and isinstance(raw[0], dict):
                datasets.append(Dataset(path.stem, str(path.resolve()), None, pd.DataFrame(raw).iloc[:max_rows, :max_columns]))
            elif isinstance(raw, dict):
                for key, value in raw.items():
                    if isinstance(value, list) and value and isinstance(value[0], dict):
                        datasets.append(Dataset(f"{path.stem}-{key}", str(path.resolve()), str(key), pd.DataFrame(value).iloc[:max_rows, :max_columns]))
        elif suffix in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
            with Image.open(path) as im:
                im.verify()
            with Image.open(path) as im:
                meta["image"] = {"width": im.width, "height": im.height, "mode": im.mode, "format": im.format}
    except Exception as exc:
        meta["status"] = "error"
        diag = classify_exception(exc, "ingest", path)
        if suffix in (".csv", ".tsv") and diag["code"] == "INPUT_PARSE_FAILED":
            diag["code"] = "CSV_STRUCTURE_INVALID"
            diag["likely_cause"] = "CSV 分隔符、引号或每行字段数不一致，且容错读取也失败。"
            diag["suggestion"] = "用 Excel/WPS 重新另存为 UTF-8 CSV，并检查未闭合引号和多余分隔符。"
        elif suffix == ".xlsx" and diag["code"] == "EXCEL_READER_MISSING":
            diag = make_diagnostic(
                "OFFICE_FILE_CORRUPT", "ingest",
                f"{type(exc).__name__}: {exc}", file=path,
                details={"exception_type": type(exc).__name__},
            )
        elif suffix in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
            diag["code"] = "IMAGE_INVALID"
        meta["diagnostics"].append(diag)
    return datasets, meta


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze materials for PPT generation with structured diagnostics")
    parser.add_argument("--inputs", nargs="+", required=True, help="Input files or directories")
    parser.add_argument("--outdir", required=True, help="Output analysis directory")
    parser.add_argument("--max-file-mb", type=int, default=DEFAULT_MAX_FILE_MB)
    parser.add_argument("--max-rows", type=int, default=DEFAULT_MAX_ROWS)
    parser.add_argument("--max-columns", type=int, default=DEFAULT_MAX_COLUMNS)
    parser.add_argument("--max-sheets", type=int, default=DEFAULT_MAX_SHEETS)
    args = parser.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    missing_inputs: list[dict[str, Any]] = []
    for raw in args.inputs:
        p = Path(raw).expanduser().resolve()
        if p.is_dir():
            paths.extend(sorted(x for x in p.rglob("*") if x.is_file()))
        elif p.is_file():
            paths.append(p)
        else:
            missing_inputs.append(make_diagnostic("FILE_NOT_FOUND", "discover", "输入路径不存在。", file=p))
    paths = list(dict.fromkeys(paths))
    if not paths:
        result = {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "status": "fail",
            "summary": {"input_count": 0, "usable_file_count": 0, "error_count": len(missing_inputs)},
            "input_files": [],
            "datasets": [],
            "diagnostics": missing_inputs or [make_diagnostic("FILE_NOT_FOUND", "discover", "未找到可分析的文件。")],
            "next_actions": ["确认文件路径或重新上传资料。"],
        }
        output = outdir / "analysis.json"
        output.write_text(json.dumps(json_safe(result), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"未找到可分析的文件，诊断报告：{output}", file=sys.stderr)
        return 2

    all_datasets: list[Dataset] = []
    file_meta: list[dict[str, Any]] = []
    for path in paths:
        datasets, meta = ingest_file(
            path,
            max_file_mb=args.max_file_mb,
            max_rows=args.max_rows,
            max_columns=args.max_columns,
            max_sheets=args.max_sheets,
        )
        all_datasets.extend(datasets)
        file_meta.append(meta)

    dataset_results = []
    for ds in all_datasets:
        try:
            if ds.frame.empty or ds.frame.dropna(how="all").empty:
                dataset_results.append({
                    "name": ds.name,
                    "source_file": ds.source_file,
                    "sheet": ds.sheet,
                    "status": "empty",
                    "diagnostics": [make_diagnostic("DATASET_EMPTY", "dataset-analysis", "数据表没有有效记录。", file=ds.source_file, severity="warning", details={"sheet": ds.sheet})],
                })
                continue
            result = analyze_dataset(ds, outdir)
            result["status"] = "ok"
            dataset_results.append(result)
        except Exception as exc:
            dataset_results.append({
                "name": ds.name,
                "source_file": ds.source_file,
                "sheet": ds.sheet,
                "status": "error",
                "diagnostics": [classify_exception(exc, "dataset-analysis", ds.source_file)],
            })

    all_findings: list[str] = []
    diagnostics: list[dict[str, Any]] = list(missing_inputs)
    for f in file_meta:
        diagnostics.extend(f.get("diagnostics") or [])
    for d in dataset_results:
        all_findings.extend(d.get("findings", []))
        diagnostics.extend(d.get("diagnostics") or [])

    usable_files = [f for f in file_meta if f.get("status") in ("ok", "partial")]
    errors = [d for d in diagnostics if d.get("severity") == "error"]
    warnings = [d for d in diagnostics if d.get("severity") == "warning"]
    status = "pass" if usable_files and not diagnostics else "partial" if usable_files else "fail"
    next_actions = []
    seen = set()
    for diag in diagnostics:
        suggestion = diag.get("suggestion")
        if suggestion and suggestion not in seen:
            seen.add(suggestion)
            next_actions.append(suggestion)
    result = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": status,
        "summary": {
            "input_count": len(file_meta) + len(missing_inputs),
            "usable_file_count": len(usable_files),
            "dataset_count": len(dataset_results),
            "error_count": len(errors),
            "warning_count": len(warnings),
        },
        "limits": {
            "max_file_mb": args.max_file_mb,
            "max_rows": args.max_rows,
            "max_columns": args.max_columns,
            "max_sheets": args.max_sheets,
        },
        "input_files": file_meta,
        "dataset_count": len(dataset_results),
        "datasets": dataset_results,
        "global_findings": all_findings[:20],
        "diagnostics": diagnostics,
        "next_actions": next_actions[:10],
        "capability_boundaries": [
            "扫描版 PDF 不执行 OCR；请先转为可搜索 PDF 或补充文字稿。",
            "旧版 .xls 主要提取表格值，公式、图表和特殊格式需要人工核对。",
            "图片文件用于版式和尺寸识别，脚本不会凭空推断图片中的业务文字。",
            "超长、超大或结构复杂资料可能分段取样，正式发布前需核对来源覆盖。",
            "生成结果是专业初稿；标题措辞、数据口径、来源和业务判断必须由用户最终确认。",
        ],
        "manual_review_required": bool(diagnostics) or any(f.get("status") == "partial" for f in file_meta),
        "data_quality_notes": [
            "统计结果仅基于成功解析的非空数据。",
            "相关性不代表因果关系。",
            "IQR 异常值仅用于提示，需结合业务判断。",
            "状态为 partial 时应先查看 diagnostics，再决定是否用于正式汇报。",
        ],
    }
    output = outdir / "analysis.json"
    output.write_text(json.dumps(json_safe(result), ensure_ascii=False, indent=2), encoding="utf-8")
    summary_lines = [
        "# 资料读取结果",
        "",
        f"- 输入文件：{result['summary']['input_count']} 个",
        f"- 可用文件：{result['summary']['usable_file_count']} 个",
        f"- 状态：{'可继续生成' if usable_files else '无法继续'}",
    ]
    if diagnostics:
        summary_lines += ["", "## 需要注意"]
        for diag in diagnostics[:8]:
            summary_lines.append(f"- **{diag.get('user_title', diag.get('code'))}**：{diag.get('user_message', diag.get('message', ''))}")
            for step in (diag.get('steps') or [])[:2]:
                summary_lines.append(f"  - {step}")
    summary_lines += ["", "## 使用边界"] + [f"- {x}" for x in result.get("capability_boundaries", [])]
    (outdir / "资料读取说明.md").write_text("\n".join(summary_lines), encoding="utf-8")
    print(str(output))
    return 0 if usable_files else 2


if __name__ == "__main__":
    raise SystemExit(main())
