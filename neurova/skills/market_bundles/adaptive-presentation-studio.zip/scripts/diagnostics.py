#!/usr/bin/env python3
"""Structured and user-friendly diagnostics for the presentation skill."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
import json
import zipfile

try:
    import pandas as pd
except Exception:  # pragma: no cover
    pd = None  # type: ignore


@dataclass
class Diagnostic:
    code: str
    stage: str
    severity: str
    message: str
    likely_cause: str
    suggestion: str
    user_title: str
    user_message: str
    steps: list[str]
    can_retry: bool = True
    file: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


ERROR_CATALOG: dict[str, dict[str, Any]] = {
    "FILE_NOT_FOUND": {
        "title": "没有找到文件",
        "user": "资料可能被移动、删除，或者上传尚未完成。",
        "cause": "文件路径无效、文件已移动，或挂载未完成。",
        "suggestion": "确认文件仍存在并重新上传；文件名中尽量避免非常规控制字符。",
        "steps": ["确认文件在当前目录中", "重新上传或选择一次文件", "再次运行生成任务"],
    },
    "FILE_PERMISSION_DENIED": {
        "title": "文件暂时无法读取",
        "user": "当前环境没有权限打开这份资料。",
        "cause": "当前运行环境没有读取该文件的权限。",
        "suggestion": "复制文件到当前工作目录后重试，或重新上传一份可读取的副本。",
        "steps": ["将文件复制到普通文件夹", "确认文件没有被其他程序独占", "重新上传后重试"],
    },
    "FILE_TOO_LARGE": {
        "title": "文件过大，已安全停止",
        "user": "为了避免卡住或内存不足，本次没有继续处理这份超大文件。",
        "cause": "文件大小超过默认安全处理上限。",
        "suggestion": "拆分文件、删除无关 Sheet/图片，或使用 --max-file-mb 调高上限后重试。",
        "steps": ["删除无关页面、图片或 Sheet", "按章节或业务单元拆分", "重新运行生成任务"],
    },
    "UNSUPPORTED_FORMAT": {
        "title": "暂不支持这种文件格式",
        "user": "请先转换为常见办公格式后再导入。",
        "cause": "文件扩展名不在当前支持列表中。",
        "suggestion": "转换为 xlsx、csv、docx、pdf、pptx、txt、md、json、png、jpg 或 webp 后重试。",
        "steps": ["用原软件打开文件", "另存为常见格式", "重新导入"],
        "retry": False,
    },
    "EMPTY_FILE": {
        "title": "文件里没有可用内容",
        "user": "文件可能为空，或内容无法被正常提取。",
        "cause": "文件为空，或没有可提取的文本、表格、图片信息。",
        "suggestion": "检查文件是否保存完整；扫描版 PDF 请先进行 OCR，空表请补充表头或数据。",
        "steps": ["打开文件确认内容存在", "重新保存一份副本", "扫描 PDF 先转成可搜索文字"],
    },
    "INPUT_ENCODING_UNSUPPORTED": {
        "title": "文字编码无法识别",
        "user": "文件里可能混用了不同中文编码，导致出现乱码或读取失败。",
        "cause": "文本编码无法可靠识别，或文件混用了多种编码。",
        "suggestion": "优先另存为 UTF-8 with BOM；中文旧系统文件可另存为 GB18030 后重试。",
        "steps": ["用 Excel/WPS/记事本打开文件", "选择另存为 UTF-8 编码", "重新导入"],
    },
    "CSV_STRUCTURE_INVALID": {
        "title": "CSV 表格结构不完整",
        "user": "部分行的列数、引号或分隔符不一致。",
        "cause": "CSV 分隔符、引号或每行字段数不一致。",
        "suggestion": "用 Excel/WPS 打开并重新另存为 UTF-8 CSV；检查备注字段中的未闭合引号和多余分隔符。",
        "steps": ["用 Excel/WPS 打开 CSV", "检查异常行和备注列", "另存为 UTF-8 CSV 后重试"],
    },
    "CSV_ROWS_SKIPPED": {
        "title": "部分 CSV 数据行已跳过",
        "user": "技能已继续生成，但个别结构异常的行没有参与统计。",
        "cause": "部分行字段数量异常，已在容错模式下跳过。",
        "suggestion": "回到源文件修复异常行后再生成正式汇报。",
        "steps": ["查看 analysis.json 中的异常提示", "修复源 CSV 的异常行", "正式发布前重新生成"],
    },
    "EXCEL_READER_MISSING": {
        "title": "旧版 Excel 读取组件缺失",
        "user": "这份 .xls 文件需要额外组件，或建议直接转换为 .xlsx。",
        "cause": "读取旧版 .xls 所需的 xlrd 组件缺失或版本不兼容。",
        "suggestion": "安装 requirements.txt 中的 xlrd，或将文件另存为 .xlsx。",
        "steps": ["优先将 .xls 另存为 .xlsx", "或安装 xlrd", "重新运行"],
    },
    "LEGACY_XLS_LIMITED": {
        "title": "旧版 Excel 仅提取表格值",
        "user": "可以读取主要数据，但公式、图表、批注或特殊格式可能无法完整保留。",
        "cause": "旧版 .xls 格式兼容能力有限。",
        "suggestion": "正式汇报前建议另存为 .xlsx，并核对公式结果和关键图表。",
        "steps": ["将文件另存为 .xlsx", "核对公式和关键数据", "重新生成正式版本"],
    },
    "EXCEL_SHEET_FAILED": {
        "title": "部分 Sheet 无法读取",
        "user": "其他 Sheet 已继续处理，失败的 Sheet 不会让整个任务崩溃。",
        "cause": "工作簿可打开，但某个 Sheet 结构异常、损坏或包含不兼容对象。",
        "suggestion": "复制该 Sheet 的有效数据到新工作簿，删除损坏对象后重试。",
        "steps": ["打开提示中的 Sheet", "复制有效数据到新 Sheet", "删除嵌入对象后另存"],
    },
    "OFFICE_FILE_CORRUPT": {
        "title": "Office 文件可能已损坏",
        "user": "文件后缀看起来正常，但内部结构无法打开。",
        "cause": "Office 文件内部 ZIP 结构损坏，或扩展名与实际格式不一致。",
        "suggestion": "用 PowerPoint/Word/Excel/WPS 打开后“另存为”新文件，再重新上传。",
        "steps": ["用原软件打开文件", "选择“另存为”新文件", "重新上传新文件"],
    },
    "PDF_TEXT_EMPTY": {
        "title": "PDF 可能是扫描版",
        "user": "当前只能识别可搜索文字，扫描图片中的文字不会自动 OCR。",
        "cause": "PDF 可能是扫描图片，或文字被转为轮廓，无法直接提取。",
        "suggestion": "先使用本地 OCR 生成可搜索 PDF，或同时上传原始 Word/文字稿。",
        "steps": ["在 WPS/Adobe 中执行 OCR", "导出为可搜索 PDF", "重新导入并核对关键内容"],
        "retry": False,
    },
    "PDF_PARTIALLY_SCANNED": {
        "title": "PDF 部分页没有可搜索文字",
        "user": "已提取可读页面，扫描页或图片页需要人工核对。",
        "cause": "PDF 同时包含可搜索文字页和扫描图片页。",
        "suggestion": "对扫描页执行 OCR，或补充原始文字稿；正式发布前核对缺失页面。",
        "steps": ["检查提示的扫描页", "对这些页面做 OCR", "重新生成正式版本"],
    },
    "TEXT_TRUNCATED": {
        "title": "超长文字已分段取样",
        "user": "为了保证稳定性，分析阶段只保留了主要内容，完整长文仍需人工核对。",
        "cause": "文档文字量超过单文件安全提取上限。",
        "suggestion": "按章节拆分文档，或提供明确页数、受众和重点，减少内容遗漏。",
        "steps": ["按章节拆分长文", "明确必须保留的重点", "重新生成并核对目录覆盖率"],
    },
    "JSON_INVALID": {
        "title": "JSON 格式不正确",
        "user": "文件中可能有尾逗号、缺少引号或不是标准 JSON。",
        "cause": "JSON 语法错误、存在尾逗号，或文件并非标准 JSON。",
        "suggestion": "使用 JSON 校验工具修复；表格数据也可转换为 CSV/XLSX。",
        "steps": ["用编辑器校验 JSON", "修复语法或转成 CSV", "重新导入"],
    },
    "IMAGE_INVALID": {
        "title": "图片无法读取",
        "user": "图片可能损坏，或后缀与真实格式不一致。",
        "cause": "图片损坏、后缀与实际编码不一致，或使用了不支持的颜色/压缩模式。",
        "suggestion": "重新导出为标准 RGB PNG/JPG，避免仅修改扩展名。",
        "steps": ["用图片软件重新打开", "导出为 RGB PNG/JPG", "重新上传"],
    },
    "DATASET_EMPTY": {
        "title": "表格没有有效数据",
        "user": "只检测到空白格式，未找到可统计的行列。",
        "cause": "表格没有有效行列，或所有内容均为空。",
        "suggestion": "补充明确表头和至少一行有效数据；删除纯格式化空白区域。",
        "steps": ["补充表头", "至少保留一行有效数据", "删除无关空白区域"],
    },
    "DATA_TRUNCATED": {
        "title": "超大数据已安全截断",
        "user": "只分析了前 N 行，结果适合作为初稿，不应直接作为正式全量结论。",
        "cause": "数据量超过安全行数上限，已只分析前 N 行。",
        "suggestion": "按时间、区域或业务单元拆分后分析，或使用 --max-rows 调高限制。",
        "steps": ["按时间或业务单元拆分", "确认抽样是否具有代表性", "正式汇报前用全量数据复核"],
    },
    "INPUT_PARSE_FAILED": {
        "title": "资料读取遇到异常",
        "user": "技能已记录问题位置，请按下方步骤处理后再试。",
        "cause": "文件内容存在未识别的异常，解析器无法继续。",
        "suggestion": "尝试另存为标准格式，或移除宏、嵌入对象和损坏内容。",
        "steps": ["用原软件另存为新文件", "删除宏和嵌入对象", "重新上传后重试"],
    },
    "PIPELINE_TIMEOUT": {
        "title": "处理时间过长，已安全停止",
        "user": "系统没有崩溃，已保留前面阶段的结果，下次可以从断点继续。",
        "cause": "某一处理阶段超过安全时间限制。",
        "suggestion": "拆分超大文件、减少图片数量，或使用断点续跑。",
        "steps": ["直接再次运行，默认会从断点继续", "若仍失败，拆分大文件", "减少高分辨率图片后重试"],
    },
    "DEPENDENCY_MISSING": {
        "title": "运行组件未安装完整",
        "user": "缺少处理文件或生成 PPT 所需的 Python 组件。",
        "cause": "运行所需的 Python 依赖未安装。",
        "suggestion": "执行 pip install -r requirements.txt，或使用平台预装运行环境。",
        "steps": ["运行环境检查脚本", "安装 requirements.txt", "重新运行"],
        "retry": False,
    },
    "OUTPUT_VALIDATION_FAILED": {
        "title": "PPT 已生成，但质量检查未通过",
        "user": "技能会先自动修复一次；仍未通过时，请查看具体页码和处理建议。",
        "cause": "PPT 存在越界、空页、文字过密或其他阻断性问题。",
        "suggestion": "根据 validation.json 的页码修正内容，或使用自动修复脚本后重新渲染。",
        "steps": ["查看运行摘要中的问题页码", "运行自动修复或精简该页", "重新生成并验证"],
    },
    "RENDER_FAILED": {
        "title": "PPT 渲染未完成",
        "user": "内容规划已保留，技能会切换到兼容布局并自动重试。",
        "cause": "图片路径、版式参数或个别页面内容导致渲染器无法完成。",
        "suggestion": "使用自动修复后的 deck_spec 重新渲染；检查缺失图片和异常页面。",
        "steps": ["等待自动兼容重试", "仍失败时查看提示页码", "替换损坏图片或精简内容"],
    },
}


def make_diagnostic(
    code: str,
    stage: str,
    message: str,
    *,
    file: str | Path | None = None,
    severity: str = "error",
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    catalog = ERROR_CATALOG.get(code, ERROR_CATALOG["INPUT_PARSE_FAILED"])
    return Diagnostic(
        code=code,
        stage=stage,
        severity=severity,
        message=message,
        likely_cause=str(catalog["cause"]),
        suggestion=str(catalog["suggestion"]),
        user_title=str(catalog["title"]),
        user_message=str(catalog["user"]),
        steps=list(catalog.get("steps") or []),
        can_retry=bool(catalog.get("retry", True)),
        file=str(file) if file is not None else None,
        details=details or {},
    ).to_dict()


def classify_exception(exc: BaseException, stage: str, file: str | Path | None = None) -> dict[str, Any]:
    name = type(exc).__name__
    text = str(exc)
    lower = text.lower()
    code = "INPUT_PARSE_FAILED"

    if isinstance(exc, FileNotFoundError):
        code = "FILE_NOT_FOUND"
    elif isinstance(exc, PermissionError):
        code = "FILE_PERMISSION_DENIED"
    elif isinstance(exc, UnicodeDecodeError):
        code = "INPUT_ENCODING_UNSUPPORTED"
    elif isinstance(exc, json.JSONDecodeError):
        code = "JSON_INVALID"
    elif isinstance(exc, zipfile.BadZipFile) or "file is not a zip file" in lower or "bad zip" in lower:
        code = "OFFICE_FILE_CORRUPT"
    elif pd is not None and isinstance(exc, getattr(pd.errors, "ParserError", ())):
        code = "CSV_STRUCTURE_INVALID"
    elif "xlrd" in lower or "excel file format cannot be determined" in lower:
        code = "EXCEL_READER_MISSING"
    elif isinstance(exc, MemoryError):
        code = "FILE_TOO_LARGE"
    elif "permission denied" in lower:
        code = "FILE_PERMISSION_DENIED"

    return make_diagnostic(
        code,
        stage,
        f"{name}: {text}" if text else name,
        file=file,
        details={"exception_type": name},
    )


def plain_summary(diag: dict[str, Any]) -> str:
    title = diag.get("user_title") or diag.get("code") or "处理异常"
    message = diag.get("user_message") or diag.get("message") or ""
    steps = diag.get("steps") or []
    lines = [f"{title}：{message}"]
    if diag.get("file"):
        lines.append(f"文件：{Path(str(diag['file'])).name}")
    for idx, step in enumerate(steps[:3], 1):
        lines.append(f"{idx}. {step}")
    return "\n".join(lines)


def write_diagnostics(path: str | Path, diagnostics: list[dict[str, Any]]) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(diagnostics, ensure_ascii=False, indent=2), encoding="utf-8")
    return target
