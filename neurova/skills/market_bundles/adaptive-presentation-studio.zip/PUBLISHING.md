# 发布说明

## 发布前检查

在技能包根目录依次执行：

```bash
python scripts/preflight.py
python scripts/self_test.py --outdir /tmp/adaptive-presentation-self-test
python scripts/package_check.py --root . --report /tmp/adaptive-presentation-package-check.json
```

发布 ZIP 第一层必须直接出现 `SKILL.md`、`manifest.yaml`、`scripts/`、`references/` 等，不要再套一层目录。

## 清理

发布前删除 `__pycache__`、`.pyc`、测试生成的 PPT、分析 JSON、临时文件和任何凭据。字体文件禁止打包。

## 版本

同步修改：

- `manifest.yaml` 的 `version`
- `_meta.json` 的 `version`
- `CHANGELOG.md`

## 回归重点

- 12 套风格可识别
- `--style auto` 可运行
- 用户指定风格优先
- 8 页以上布局不单一
- PPT 可打开且元素可编辑
- 来源、扫描 PDF、旧版 XLS、截断资料等能力边界仍能正确提示
- `embedded_skills/presentations/` 完整存在，且未打包宿主运行时、字体或凭据
- `visual_planner.py` 能生成配图计划，且至少一个素材绑定测试能生成可验证 PPT
