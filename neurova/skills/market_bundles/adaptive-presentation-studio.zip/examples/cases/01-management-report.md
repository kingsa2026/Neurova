# 案例：管理层项目汇报

## 输入资料

- `项目方案.docx`
- `项目进度.xlsx`
- `现场图片/`

## 用户指令

> 帮我做成面向管理层的项目汇报，12 页，15 分钟讲完。重点讲目标、当前进展、成果、风险和需要决策的事项，风格简洁稳重，所有数据注明来源。

## 命令

```bash
python scripts/run_pipeline.py \
  --inputs 项目方案.docx 项目进度.xlsx 现场图片 \
  --outdir output-management \
  --title "项目阶段汇报" \
  --audience "管理层" \
  --purpose "汇报进展并请求决策" \
  --target-pages 12 \
  --presentation-minutes 15 \
  --filename "项目阶段汇报.pptx"
```

## 预期结构

封面 → 核心结论 → 目标范围 → 进展 → 成果 → 里程碑 → 数据证据 → 风险矩阵 → 资源缺口 → 决策请求 → 行动计划 → 结束页。

## 验收重点

- 日期、负责人和风险等级准确。
- 决策请求明确，不只写“下一步”。
- 资料来源覆盖率完整。
